import ast
from pathlib import Path


APP_PATH = Path(__file__).resolve().parents[1] / "app.py"


def _imported_names_from(module_name: str) -> list[str]:
    tree = ast.parse(APP_PATH.read_text(encoding="utf-8"))
    names: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == module_name:
            for alias in node.names:
                names.append(alias.asname or alias.name)
    return names


def test_official_ai_app_dependencies_are_imported_once():
    names = _imported_names_from("official_ai_resources")
    assert "provider_counts" in names
    assert "resource_has_certificate" in names
    assert "OFFICIAL_AI_STARTER_PATH" in names
    assert len(names) == len(set(names)), "Duplicate official_ai_resources imports create noisy maintenance risk."


def test_progress_imports_do_not_duplicate_names():
    names = _imported_names_from("progress")
    assert len(names) == len(set(names)), "Duplicate progress imports should be cleaned up."


def test_app_uses_shared_starter_path_constant():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "starter_ids = OFFICIAL_AI_STARTER_PATH" in source
    assert '("gumloop_ai_fundamentals", "gumloop_getting_started", "anthropic_academy")' not in source


def test_app_exposes_today_tab_and_daily_training_imports():
    source = APP_PATH.read_text(encoding="utf-8")
    assert '"Today", "Path", "Focus Coach", "Dashboard", "Learn"' in source
    assert "record_daily_mission" in _imported_names_from("progress")
    assert "completed_daily_missions_count" in _imported_names_from("progress")
    assert "from study_plan import DAILY_PLAN" in source
    assert "render_daily_mission_card" in source
    assert "render_focus_blocks" in source
    assert "with path_tab:" in source
    assert "with projects_tab:" in source


def test_app_mentions_30_minute_daily_habit():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "30-minute coding session" in source
    assert "30-minute mission" in source
    assert "Badge shelf" in source
    assert "ADHD-friendly setup" in source
    assert "Projects & capstone checkpoints" in source
    assert "Learning Path: Python basics to capstone" in source
    assert "Graduation checklist" in source


def test_app_imports_focus_and_project_dependencies():
    focus_names = _imported_names_from("focus_coach")
    project_names = _imported_names_from("projects")
    progress_names = _imported_names_from("progress")

    assert "focus_blocks" in focus_names
    assert "recommended_focus_mode" in focus_names
    assert "PROJECTS" in project_names
    assert "recommended_project_id" in project_names
    assert "record_focus_checkin" in progress_names
    assert "record_project_milestone" in progress_names
    assert "add_parking_lot_item" in progress_names


def test_app_escapes_learner_text_before_raw_html_rendering():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "from ui_safety import safe_html_text, truncate_text" in source
    assert "safe_thought = safe_html_text(truncate_text(item.get" in source
    assert "{item.get('thought', '')}</div>" not in source


def test_app_has_low_stimulation_theme_hook_and_import_validation():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "def apply_theme(low_stimulation: bool = False)" in source
    assert "apply_theme(low_stimulation=bool(progress_data.get" in source
    assert "if not isinstance(imported, dict):" in source


def test_progress_download_filename_uses_safe_slug():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "profile_slug" in source
    assert 'file_name=f"ai_code_tutor_progress_{profile_slug(profile_name)}.json"' in source


def test_imported_progress_is_normalized_before_saving():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "normalize_progress_data(imported, LESSON_IDS, profile_name=profile_name)" in source


def test_app_imports_daily_coach_dependencies():
    names = _imported_names_from("daily_coach")
    assert "daily_session_checklist" in names
    assert "daily_session_nudge" in names
    assert "streak_repair_message" in names


def test_today_tab_uses_one_daily_coach_checklist_without_legacy_helpers():
    source = APP_PATH.read_text(encoding="utf-8")
    legacy_names = {
        "today_session_steps",
        "session_readiness_message",
        "weekly_checkpoint_label",
        "checklist_completion_percent",
        "next_tiny_action",
    }
    for name in legacy_names:
        assert name not in source
    assert "daily_session_checklist" in source
    assert "daily_session_nudge" in source
    assert "One-screen checklist" in source
    assert source.count("Save current draft") == 1


def test_app_imports_progress_normalizer_used_by_import_flow():
    names = _imported_names_from("progress")
    assert "normalize_progress_data" in names
    source = APP_PATH.read_text(encoding="utf-8")
    assert "normalize_progress_data(imported, LESSON_IDS, profile_name=profile_name)" in source


def test_app_exposes_v11_daily_coding_gym_ui():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "Today: Daily Coding Gym" in source
    assert "Start Today" in source
    assert "Time I have today" in source
    assert "One-screen checklist" in source
    assert "Proof card" in source
    assert "Mistake notebook" in source
    assert "Review queue" in source
    assert "render_gym_shell" in source
    assert "gym_blocks_for_choice" in source
    assert "build_review_items" in source


def test_v11_keeps_accessible_controls_and_focus_preferences_polish():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "render_timeline_legend" in source
    assert "select_pace_control" in source
    assert "st.pills" in source
    assert "Focus preferences saved." in source
    assert "st.rerun()" in source[source.index("Focus preferences saved."):]
    coding_gym_names = _imported_names_from("coding_gym")
    assert "gym_blocks_for_choice" in coding_gym_names
    assert "record_gym_session" in _imported_names_from("progress")
    assert "add_mistake_card" in _imported_names_from("progress")


def test_v13_stop_resume_and_time_based_lesson_ui_are_present():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "Stop & save for later" in source
    assert "Stopped and saved. When you come back" in source
    assert "Today's lesson based on time" in source
    assert "workout_lesson_options" in source
    assert "Remember {selected_choice.label}" in source
    assert "Mark selected lesson complete when this workout is completed" in source
    assert source.count("record_daily_checklist(progress_data, mission.day, current_state)") == 1


def test_v15_learning_path_and_standalone_checks_are_wired():
    source = APP_PATH.read_text(encoding="utf-8")
    learning_names = _imported_names_from("learning_path")
    standalone_names = _imported_names_from("standalone_check")
    assert "current_milestone_status" in learning_names
    assert "graduation_readiness" in learning_names
    assert "standalone_checks" in standalone_names
    assert "standalone_summary" in standalone_names
    assert "render_milestone_status" in source
    assert "render_standalone_check" in source
    assert "Standalone readiness check" in source
