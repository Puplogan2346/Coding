from __future__ import annotations

import json
import os
from statistics import mean

import streamlit as st

from ai_tutor import ai_is_configured, call_ai_tutor, configured_model, improve_prompt_with_ai
from code_runner import code_runner_enabled, run_python_with_tests
from coding_gym import (
    build_review_items,
    gym_blocks_for_choice,
    gym_completion,
    gym_history_summary,
    gym_motivation_copy,
    gym_progress_label,
    gym_session_history,
    next_gym_action,
    proof_card_summary,
    total_gym_minutes,
    workout_finish_status,
    workout_lesson_options,
    workout_resume_setup,
    workout_resume_summary,
    workout_save_decision,
)
from smooth_workout import (
    current_focus_card,
    daily_use_smoothness_checks,
    focus_completion_sentence,
    mark_focus_step_done,
    resume_safety_report,
)
from curriculum import LESSONS, get_lesson_by_id
from daily_coach import daily_session_checklist, daily_session_nudge, streak_repair_message
from experience import (
    SESSION_LABELS,
    checklist_completion_from_state,
    coach_header_summary,
    daily_timeline,
    effective_energy_for_session,
    merge_step_state,
    mission_is_complete,
    mission_stage_cards,
    next_action_card,
    pace_coach_copy,
    percent_label,
    plan_progress_sentence,
    quick_win_message,
    session_choice_by_label,
    session_index_for_minutes,
    session_minutes_total,
    streak_microcopy,
    timeline_legend_counts,
    today_progress_label,
)
from focus_coach import (
    ADHD_DESIGN_PRINCIPLES,
    ENERGY_LEVELS,
    FOCUS_LEVELS,
    body_double_script,
    focus_blocks,
    focus_checkin_score,
    recommended_focus_mode,
    total_focus_minutes,
)
from gamification import calculate_xp, earned_badges, level_for_xp, level_progress_percent, xp_to_next_level
from learning_path import (
    GRADUATION_PROMISE,
    completed_milestones_count,
    current_milestone_status,
    graduation_readiness,
    learning_outcomes,
    milestone_statuses,
    overall_learning_percent,
    skill_statuses,
)
from private_access import configured_passcode, private_access_status, private_badge_text, verify_passcode
from product_export import backup_zip_bytes, certificate_markdown, learning_transcript_markdown, unwrap_progress_import
from official_ai_resources import (
    OFFICIAL_AI_MILESTONES,
    OFFICIAL_AI_RESOURCES,
    OFFICIAL_AI_STARTER_PATH,
    PROVIDER_ORDER,
    RESOURCE_TYPES,
    STATUS_OPTIONS,
    next_recommended_resource,
    official_resource_stats,
    provider_counts,
    resource_has_certificate,
    resources_for_ids,
)
from projects import (
    PROJECTS,
    completed_project_milestones_count,
    next_project_milestone,
    project_completion_percent,
    project_progress,
    recommended_project_id,
)
from progress import (
    add_mistake_card,
    add_parking_lot_item,
    close_mistake_card,
    close_parking_lot_item,
    daily_checklist_steps,
    completed_daily_missions_count,
    completion_percent,
    load_progress,
    mark_lesson_complete,
    normalize_progress_data,
    profile_slug,
    progress_path_for_profile,
    progress_db_path,
    record_daily_checklist,
    record_daily_mission,
    record_focus_checkin,
    pause_gym_session,
    record_gym_session,
    record_official_ai_resource,
    record_prompt_score,
    record_project_milestone,
    record_quiz_score,
    save_focus_preferences,
    save_note,
    save_progress,
    gym_session_for_day,
    gym_session_is_active,
    gym_session_is_saved,
    start_gym_session,
)
from prompt_lab import improved_prompt_template, score_prompt
from standalone_check import standalone_checks, standalone_summary
from study_plan import DAILY_PLAN, next_mission, plan_completion_percent, review_queue
from ui_safety import safe_html_text, truncate_text


st.set_page_config(
    page_title="AI Code Tutor",
    page_icon="🐍",
    layout="wide",
    initial_sidebar_state="expanded",
)

LESSON_IDS = [lesson.id for lesson in LESSONS]


def h(value: object) -> str:
    """Escape text before inserting it into custom HTML blocks."""
    return safe_html_text(value)


def apply_theme(low_stimulation: bool = False) -> None:
    st.markdown(
        """
<style>
    .block-container {padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1180px;}
    [data-testid="stSidebar"] {border-right: 1px solid rgba(120, 120, 120, .16);}
    h1, h2, h3 {letter-spacing: -0.025em;}
    .hero {
        padding: 2.1rem 2.2rem;
        border-radius: 28px;
        background: linear-gradient(135deg, rgba(53, 111, 255, .18), rgba(106, 214, 185, .16));
        border: 1px solid rgba(120, 120, 120, .18);
        margin-bottom: 1.25rem;
    }
    .hero h1 {font-size: 3rem; margin: 0 0 .3rem 0;}
    .hero p {font-size: 1.08rem; margin: .2rem 0 0 0; color: rgba(49, 51, 63, .78); max-width: 760px;}
    .card {
        border: 1px solid rgba(120, 120, 120, .18);
        border-radius: 22px;
        padding: 1.05rem 1.15rem;
        background: rgba(255, 255, 255, .72);
        box-shadow: 0 14px 36px rgba(0, 0, 0, .045);
        min-height: 118px;
        margin-bottom: .75rem;
    }
    .card h3 {font-size: 1.05rem; margin: 0 0 .3rem 0;}
    .card p {margin: 0; color: rgba(49, 51, 63, .74);}
    .pill {
        display: inline-block;
        padding: .22rem .58rem;
        border-radius: 999px;
        background: rgba(53, 111, 255, .12);
        border: 1px solid rgba(53, 111, 255, .18);
        font-size: .8rem;
        margin-right: .35rem;
        margin-bottom: .35rem;
    }
    .lesson-row {
        padding: .75rem .85rem;
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 16px;
        margin-bottom: .55rem;
        background: rgba(255, 255, 255, .58);
    }
    .small-muted {font-size: .88rem; color: rgba(49, 51, 63, .66);}
    .success-soft {background: rgba(52, 168, 83, .12); border-color: rgba(52, 168, 83, .25);}
    .warning-soft {background: rgba(251, 188, 5, .13); border-color: rgba(251, 188, 5, .28);}
    .danger-soft {background: rgba(234, 67, 53, .10); border-color: rgba(234, 67, 53, .22);}
    .step-card {
        padding: .95rem 1.05rem;
        border-radius: 18px;
        border: 1px solid rgba(120, 120, 120, .15);
        background: rgba(255, 255, 255, .68);
        margin-bottom: .7rem;
    }
    .step-card strong {font-size: 1rem;}
    .step-card span {display: block; color: rgba(49, 51, 63, .70); margin-top: .2rem;}
    .resource-card {
        border: 1px solid rgba(120, 120, 120, .16);
        border-radius: 20px;
        padding: 1rem 1.1rem;
        background: rgba(255, 255, 255, .66);
        margin-bottom: .8rem;
    }
    .resource-card h3 {margin: 0 0 .25rem 0; font-size: 1.06rem;}
    .resource-card p {margin: .25rem 0; color: rgba(49, 51, 63, .74);}
    .resource-meta {font-size: .86rem; color: rgba(49, 51, 63, .68); margin-bottom: .45rem;}
    .track-card {
        padding: .85rem 1rem;
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 16px;
        margin-bottom: .55rem;
        background: rgba(255, 255, 255, .54);
    }
    .mission-card {
        border: 1px solid rgba(53, 111, 255, .20);
        border-radius: 26px;
        padding: 1.2rem 1.25rem;
        background: linear-gradient(135deg, rgba(53, 111, 255, .11), rgba(106, 214, 185, .11));
        margin-bottom: 1rem;
    }
    .mission-card h2 {margin-top: 0;}
    .block-list {
        border-left: 3px solid rgba(53, 111, 255, .35);
        padding-left: .8rem;
        margin-bottom: .65rem;
    }
    .badge-card {
        border: 1px solid rgba(120, 120, 120, .16);
        border-radius: 16px;
        padding: .7rem .8rem;
        margin-bottom: .5rem;
        background: rgba(255, 255, 255, .64);
    }
    .badge-card strong {display: block; margin-bottom: .15rem;}
    .badge-card span {color: rgba(49, 51, 63, .70); font-size: .88rem;}

    .focus-card {
        border: 1px solid rgba(53, 111, 255, .18);
        border-radius: 18px;
        padding: .85rem 1rem;
        background: rgba(53, 111, 255, .065);
        margin-bottom: .55rem;
    }
    .focus-card strong {display: block; margin-bottom: .15rem;}
    .focus-card span {color: rgba(49, 51, 63, .72); font-size: .9rem;}
    .project-card {
        border: 1px solid rgba(120, 120, 120, .16);
        border-radius: 20px;
        padding: 1rem 1.1rem;
        background: rgba(255, 255, 255, .68);
        margin-bottom: .8rem;
    }
    .project-card h3 {margin: 0 0 .25rem 0; font-size: 1.08rem;}
    .project-card p {margin: .25rem 0; color: rgba(49, 51, 63, .74);}
    .parking-item {
        padding: .55rem .7rem;
        border-radius: 14px;
        border: 1px dashed rgba(120, 120, 120, .28);
        margin-bottom: .4rem;
        background: rgba(255,255,255,.52);
    }
    div[data-testid="stMetric"] {
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 18px;
        padding: .8rem .95rem;
        background: rgba(255, 255, 255, .66);
    }
    .skip-link {
        position: absolute;
        left: -999px;
        top: .5rem;
        z-index: 9999;
        padding: .55rem .85rem;
        border-radius: 999px;
        background: #ffffff;
        border: 2px solid rgba(53, 111, 255, .60);
    }
    .skip-link:focus {left: .75rem;}
    .hero-meta {margin-top: .8rem; display: flex; gap: .5rem; flex-wrap: wrap;}
    .hero-stat {
        display: inline-flex;
        align-items: center;
        gap: .3rem;
        padding: .32rem .68rem;
        border-radius: 999px;
        border: 1px solid rgba(53, 111, 255, .16);
        background: rgba(255, 255, 255, .58);
        font-size: .86rem;
    }
    .action-callout {
        padding: 1.05rem 1.15rem;
        border-radius: 24px;
        background: linear-gradient(135deg, rgba(53, 111, 255, .13), rgba(106, 214, 185, .11));
        border: 1px solid rgba(53, 111, 255, .22);
        margin: .85rem 0 1rem 0;
    }
    .action-callout h3 {margin: 0 0 .25rem 0; font-size: 1.25rem;}
    .action-callout p {margin: .25rem 0; color: rgba(49, 51, 63, .74);}
    .mini-card {
        border: 1px solid rgba(120, 120, 120, .14);
        border-radius: 18px;
        padding: .85rem .95rem;
        background: rgba(255, 255, 255, .62);
        min-height: 106px;
        margin-bottom: .75rem;
    }
    .mini-card strong {display: block; margin-bottom: .2rem;}
    .mini-card span {color: rgba(49, 51, 63, .72); font-size: .92rem;}
    .timeline-wrap {
        display: flex;
        flex-wrap: wrap;
        gap: .32rem;
        align-items: center;
        margin: .5rem 0 1rem 0;
    }
    .day-dot {
        width: 1.75rem;
        height: 1.75rem;
        border-radius: 999px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: .74rem;
        border: 1px solid rgba(120, 120, 120, .24);
        background: rgba(255,255,255,.64);
        color: rgba(49, 51, 63, .76);
    }
    .day-dot.complete {background: rgba(52, 168, 83, .16); border-color: rgba(52, 168, 83, .30);}
    .day-dot.current {background: rgba(53, 111, 255, .18); border-color: rgba(53, 111, 255, .42); font-weight: 700;}
    .day-dot.skipped, .day-dot.missed {background: rgba(251, 188, 5, .13); border-color: rgba(251, 188, 5, .32);}
    .coach-toolbar {
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 22px;
        padding: .9rem 1rem;
        background: rgba(255, 255, 255, .60);
        margin-bottom: .85rem;
    }
    .progress-caption {font-size: .9rem; color: rgba(49, 51, 63, .70); margin-top: .15rem;}
    .coach-summary {
        border: 1px solid rgba(53, 111, 255, .22);
        border-radius: 28px;
        padding: 1.15rem 1.25rem;
        background: linear-gradient(135deg, rgba(53, 111, 255, .12), rgba(255, 255, 255, .70));
        margin: .85rem 0 1rem 0;
    }
    .coach-summary h2 {margin: 0 0 .35rem 0; font-size: 1.55rem;}
    .coach-summary p {margin: .25rem 0; color: rgba(49, 51, 63, .76);}
    .coach-strip {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: .55rem;
        margin: .75rem 0 1rem 0;
    }
    .coach-strip-item {
        border: 1px solid rgba(120, 120, 120, .14);
        border-radius: 18px;
        padding: .75rem .8rem;
        background: rgba(255,255,255,.64);
    }
    .coach-strip-item strong {display: block; font-size: .92rem; margin-bottom: .16rem;}
    .coach-strip-item span {font-size: .88rem; color: rgba(49, 51, 63, .70);}
    .timeline-legend {display:flex; flex-wrap:wrap; gap:.4rem; margin: -.35rem 0 .85rem 0;}
    .legend-pill {
        display:inline-flex; align-items:center; gap:.32rem;
        padding:.22rem .52rem; border-radius:999px;
        border:1px solid rgba(120,120,120,.16); background:rgba(255,255,255,.58);
        font-size:.8rem; color:rgba(49,51,63,.72);
    }
    .legend-swatch {width:.68rem; height:.68rem; border-radius:999px; border:1px solid rgba(120,120,120,.24);}
    .legend-swatch.complete {background: rgba(52, 168, 83, .22);}
    .legend-swatch.current {background: rgba(53, 111, 255, .25);}
    .legend-swatch.upcoming {background: rgba(255,255,255,.75);}
    .legend-swatch.skipped, .legend-swatch.missed {background: rgba(251, 188, 5, .18);}
    .done-zone {
        border: 1px solid rgba(52, 168, 83, .24);
        border-radius: 20px;
        padding: .9rem 1rem;
        background: rgba(52, 168, 83, .09);
        margin: .8rem 0;
    }
    .done-zone strong {display:block; margin-bottom:.15rem;}
    .done-zone span {color: rgba(49,51,63,.72);}
    .gym-shell {
        border: 1px solid rgba(53, 111, 255, .22);
        border-radius: 30px;
        padding: 1.15rem 1.25rem;
        background: linear-gradient(135deg, rgba(53, 111, 255, .12), rgba(106, 214, 185, .10));
        margin: .85rem 0 1rem 0;
    }
    .gym-shell h2 {margin: 0 0 .3rem 0; font-size: 1.75rem;}
    .gym-shell p {margin: .22rem 0; color: rgba(49,51,63,.76);}
    .gym-start {
        border: 1px solid rgba(53, 111, 255, .20);
        border-radius: 24px;
        padding: 1rem 1.1rem;
        background: rgba(255,255,255,.68);
        margin: .75rem 0;
    }
    .focus-workout-card {
        border: 2px solid rgba(53, 111, 255, .28);
        border-radius: 30px;
        padding: 1.15rem 1.25rem;
        background: linear-gradient(135deg, rgba(53, 111, 255, .14), rgba(255,255,255,.82));
        margin: .85rem 0 1rem 0;
        box-shadow: 0 18px 40px rgba(0,0,0,.045);
    }
    .focus-workout-card h3 {margin: 0 0 .35rem 0; font-size: 1.45rem;}
    .focus-workout-card p {margin: .28rem 0; color: rgba(49,51,63,.76);}
    .focus-workout-card .next-rep {
        border-left: 4px solid rgba(53,111,255,.42);
        padding: .55rem .75rem;
        background: rgba(255,255,255,.64);
        border-radius: 0 16px 16px 0;
        margin: .8rem 0;
    }
    .smooth-check {
        border: 1px solid rgba(120,120,120,.14);
        border-radius: 16px;
        padding: .65rem .75rem;
        background: rgba(255,255,255,.62);
        margin-bottom: .45rem;
    }
    .smooth-check strong {display:block; margin-bottom:.12rem;}
    .smooth-check span {font-size:.88rem; color:rgba(49,51,63,.70);}
    .resume-box {
        border: 1px solid rgba(251, 188, 5, .30);
        border-radius: 24px;
        padding: 1rem 1.1rem;
        background: rgba(251, 188, 5, .10);
        margin: .75rem 0 1rem 0;
    }
    .resume-box strong {display:block; margin-bottom:.22rem; font-size:1.02rem;}
    .resume-box span {display:block; color:rgba(49,51,63,.72); font-size:.92rem;}
    .gym-block {
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 18px;
        padding: .8rem .9rem;
        background: rgba(255,255,255,.64);
        margin-bottom: .55rem;
    }
    .gym-block strong {display:block; margin-bottom:.15rem;}
    .gym-block span {font-size:.9rem; color:rgba(49,51,63,.72);}
    .gym-block em {display:block; margin-top:.25rem; font-size:.84rem; color:rgba(49,51,63,.62);}
    .proof-card {
        border: 1px solid rgba(52, 168, 83, .25);
        border-radius: 20px;
        padding: .9rem 1rem;
        background: rgba(52,168,83,.08);
        margin: .7rem 0;
    }
    .proof-card strong {display:block; margin-bottom:.2rem;}
    .proof-card span {color:rgba(49,51,63,.72);}
    .lesson-choice-card {
        border: 1px solid rgba(53, 111, 255, .20);
        border-radius: 20px;
        padding: .9rem 1rem;
        background: rgba(53,111,255,.075);
        margin: .7rem 0;
    }
    .lesson-choice-card strong {display:block; margin-bottom:.18rem;}
    .lesson-choice-card span {font-size:.9rem; color:rgba(49,51,63,.72);}
    .review-chip {
        border: 1px solid rgba(120,120,120,.16);
        border-radius: 16px;
        padding: .65rem .75rem;
        margin-bottom:.45rem;
        background:rgba(255,255,255,.60);
    }
    .review-chip strong {display:block; margin-bottom:.12rem;}
    .review-chip span {font-size:.88rem; color:rgba(49,51,63,.70);}

    .milestone-card {
        border: 1px solid rgba(53, 111, 255, .18);
        border-radius: 22px;
        padding: 1rem 1.1rem;
        background: rgba(255, 255, 255, .68);
        margin-bottom: .8rem;
    }
    .milestone-card.complete {border-color: rgba(52, 168, 83, .30); background: rgba(52, 168, 83, .08);}
    .milestone-card.current {border-color: rgba(53, 111, 255, .34); background: rgba(53, 111, 255, .08);}
    .milestone-card h3 {margin: 0 0 .25rem 0; font-size: 1.08rem;}
    .milestone-card p {margin: .25rem 0; color: rgba(49, 51, 63, .74);}
    .requirement-row {
        display: flex;
        justify-content: space-between;
        gap: .75rem;
        align-items: flex-start;
        border-bottom: 1px solid rgba(120, 120, 120, .12);
        padding: .55rem 0;
    }
    .requirement-row:last-child {border-bottom: 0;}
    .requirement-row span {color: rgba(49, 51, 63, .70); font-size: .9rem;}
    .check-row {
        border: 1px solid rgba(120,120,120,.15);
        border-radius: 16px;
        padding: .7rem .8rem;
        margin-bottom: .5rem;
        background: rgba(255,255,255,.62);
    }
    .check-row strong {display:block; margin-bottom:.1rem;}
    .check-row span {font-size:.88rem; color:rgba(49,51,63,.70);}
    .ux-note {
        border-left: 4px solid rgba(53, 111, 255, .36);
        padding: .65rem .85rem;
        background: rgba(53, 111, 255, .06);
        border-radius: 0 14px 14px 0;
        margin: .7rem 0;
    }
    .ux-note p {margin:0; color:rgba(49,51,63,.75);}
    .stButton > button, button[kind="primary"] {
        border-radius: 999px !important;
        min-height: 44px;
        font-weight: 650;
    }
    div[data-testid="stTextInput"] input, div[data-testid="stTextArea"] textarea, div[data-testid="stSelectbox"] {
        border-radius: 14px;
    }
    *:focus-visible {
        outline: 3px solid rgba(53, 111, 255, .55) !important;
        outline-offset: 2px !important;
    }
    @media (max-width: 760px) {
        .block-container {padding-left: .9rem; padding-right: .9rem; padding-top: 1rem;}
        .hero {padding: 1.25rem 1.1rem; border-radius: 22px;}
        .hero h1 {font-size: 2.15rem;}
        .hero p {font-size: 1rem;}
        .card, .mini-card, .mission-card, .action-callout, .coach-summary {min-height: 0; border-radius: 18px;}
        .coach-strip {grid-template-columns: 1fr;}
        .day-dot {width: 1.55rem; height: 1.55rem; font-size: .68rem;}
    }
</style>
""".strip(),
        unsafe_allow_html=True,
    )
    if low_stimulation:
        st.markdown(
            """
<style>
    .hero, .mission-card, .action-callout, .coach-summary {background: rgba(255, 255, 255, .88) !important;}
    .card, .step-card, .resource-card, .project-card, .focus-card, .mini-card, div[data-testid="stMetric"] {
        box-shadow: none !important;
    }
    .pill, .hero-stat, .day-dot {background: rgba(120, 120, 120, .08) !important;}
    .day-dot.current {border-width: 2px !important;}
</style>
""".strip(),
            unsafe_allow_html=True,
        )


def first_incomplete_lesson_id(progress_data: dict) -> str:
    completed = set(progress_data.get("completed_lessons", []))
    for lesson_item in LESSONS:
        if lesson_item.id not in completed:
            return lesson_item.id
    return LESSONS[-1].id


def get_quiz_average(progress_data: dict) -> float:
    scores = progress_data.get("quiz_scores", {}).values()
    percentages = [item.get("percent", 0) for item in scores]
    return round(mean(percentages), 1) if percentages else 0.0


def get_best_prompt_score(progress_data: dict) -> int:
    scores = [item.get("score", 0) for item in progress_data.get("prompt_scores", [])]
    return max(scores) if scores else 0


def render_score_badge(score: int, total: int) -> None:
    percent = round((score / total) * 100) if total else 0
    if percent >= 80:
        st.success(f"Score: {score}/{total} ({percent}%). Strong work.")
    elif percent >= 60:
        st.warning(f"Score: {score}/{total} ({percent}%). Review the misses and try again.")
    else:
        st.error(f"Score: {score}/{total} ({percent}%). Revisit the lesson, then retake it.")


def render_card(title: str, body: str, tone: str = "") -> None:
    tone_class = f" {tone}" if tone else ""
    safe_title = safe_html_text(title)
    safe_body = safe_html_text(body)
    st.markdown(
        f"""
<div class="card{tone_class}">
    <h3>{safe_title}</h3>
    <p>{safe_body}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_status_pills(lesson_level: str, minutes: int, is_complete: bool) -> None:
    status = "Complete" if is_complete else "In progress"
    st.markdown(
        f"""
<span class="pill">{h(lesson_level)}</span>
<span class="pill">{h(minutes)} min</span>
<span class="pill">{h(status)}</span>
""".strip(),
        unsafe_allow_html=True,
    )


def render_step(number: int, title: str, body: str) -> None:
    safe_title = safe_html_text(title)
    safe_body = safe_html_text(body)
    st.markdown(
        f"""
<div class="step-card">
    <strong>{number}. {safe_title}</strong>
    <span>{safe_body}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_mini_card(title: str, body: str) -> None:
    st.markdown(
        f"""
<div class="mini-card">
    <strong>{h(title)}</strong>
    <span>{h(body)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_action_callout(action) -> None:
    st.markdown(
        f"""
<div class="action-callout">
    <h3>{h(action.headline)}</h3>
    <p>{h(action.instruction)}</p>
    <p><strong>Proof:</strong> {h(action.proof)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_daily_timeline(days) -> None:
    dots = []
    for day in days:
        dots.append(
            f'<span class="day-dot {h(day.status)}" title="{h(day.label)}" aria-label="{h(day.label)}">{h(day.day)}</span>'
        )
    st.markdown(f"<div class='timeline-wrap'>{''.join(dots)}</div>", unsafe_allow_html=True)


def render_level_progress(xp: int) -> None:
    st.progress(level_progress_percent(xp))
    remaining = xp_to_next_level(xp)
    if remaining:
        st.caption(f"{remaining} XP to the next level.")
    else:
        st.caption("Top starter level reached. Keep building projects and proof notes.")


def render_coach_summary(headline: str, subline: str, support: str) -> None:
    st.markdown(
        f"""
<div class="coach-summary">
    <h2>{h(headline)}</h2>
    <p><strong>{h(subline)}</strong></p>
    <p>{h(support)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_coach_strip(items: list[tuple[str, str]]) -> None:
    rendered = []
    for title, body in items:
        rendered.append(
            f"<div class='coach-strip-item'><strong>{h(title)}</strong><span>{h(body)}</span></div>"
        )
    st.markdown(f"<div class='coach-strip'>{''.join(rendered)}</div>", unsafe_allow_html=True)


def render_timeline_legend(days) -> None:
    counts = timeline_legend_counts(days)
    labels = (
        ("complete", "Done"),
        ("current", "Today"),
        ("upcoming", "Later"),
        ("skipped", "Skipped"),
        ("missed", "Unfinished"),
    )
    rendered = []
    for status, label in labels:
        if counts.get(status, 0) or status in {"complete", "current", "upcoming"}:
            rendered.append(
                f"<span class='legend-pill'><span class='legend-swatch {h(status)}'></span>{h(label)}: {h(counts.get(status, 0))}</span>"
            )
    st.markdown(f"<div class='timeline-legend'>{''.join(rendered)}</div>", unsafe_allow_html=True)


def render_done_zone(checklist_completion: float, mission_complete_now: bool) -> None:
    if mission_complete_now:
        title = "Done zone: saved"
        body = "Today is already logged. A tiny review is optional; stopping is allowed."
    elif checklist_completion >= 1:
        title = "Done zone: lock it in"
        body = "Your checklist is complete. Save the mission reflection so the streak, XP, and proof note all update."
    else:
        title = "Done zone: not yet"
        body = "Only save the mission after you have one proof note. The checklist can be tiny on rescue days."
    st.markdown(
        f"""
<div class="done-zone">
    <strong>{h(title)}</strong>
    <span>{h(body)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_gym_shell(mission, action, completion: float, pace_label: str, total_minutes: int, saved: bool) -> None:
    saved_text = "Saved" if saved else "Not saved yet"
    st.markdown(
        f"""
<div class="gym-shell">
    <h2>Daily Coding Gym · Day {h(mission.day)}</h2>
    <p><strong>{h(mission.title)}</strong> — {h(mission.focus)}</p>
    <p>{h(action.headline)}: {h(action.body)}</p>
    <div class="hero-meta">
        <span class="hero-stat">Pace: {h(pace_label)}</span>
        <span class="hero-stat">Time: {h(total_minutes)} min</span>
        <span class="hero-stat">Progress: {h(percent_label(completion))}</span>
        <span class="hero-stat">Status: {h(saved_text)}</span>
    </div>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_resume_banner(summary, lesson_title: str) -> None:
    st.markdown(
        f"""
<div class="resume-box">
    <strong>{h(summary.headline)}</strong>
    <span>{h(summary.body)}</span>
    <div class="hero-meta">
        <span class="hero-stat">Saved pace: {h(summary.pace)}</span>
        <span class="hero-stat">Lesson: {h(lesson_title)}</span>
        <span class="hero-stat">Saved progress: {h(summary.checked_blocks)}/{h(summary.total_blocks)} blocks</span>
        <span class="hero-stat">Status: {h(summary.status)}</span>
    </div>
    <span><b>Proof draft:</b> {h(summary.proof_preview)}<br><b>Next review:</b> {h(summary.next_review)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_gym_block(block, done: bool) -> None:
    status = "Done" if done else "Open"
    st.markdown(
        f"""
<div class="gym-block">
    <strong>{h(status)} · {h(block.label)} · {h(block.minutes)} min</strong>
    <span>{h(block.action)}<br><b>Proof:</b> {h(block.proof)}</span>
    <em>{h(block.why)}</em>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_focus_workout_card(card) -> None:
    st.markdown(
        f"""
<div class="focus-workout-card">
    <h3>{h(card.headline)}</h3>
    <p><strong>{h(card.nudge)}</strong></p>
    <div class="hero-meta">
        <span class="hero-stat">Step: {h(card.step_number)}/{h(card.total_steps)}</span>
        <span class="hero-stat">Time box: {h(card.minutes)} min</span>
        <span class="hero-stat">Workout: {h(percent_label(card.completion))}</span>
    </div>
    <div class="next-rep">
        <strong>Do this now:</strong> {h(card.action)}<br>
        <strong>Proof to save:</strong> {h(card.proof)}
    </div>
    <p>{h(card.why)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_smoothness_check(check) -> None:
    status_class = "success-soft" if check.status == "Pass" else "warning-soft"
    st.markdown(
        f"""
<div class="smooth-check {h(status_class)}">
    <strong>{h(check.status)} · {h(check.name)}</strong>
    <span>{h(check.detail)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_review_item(item) -> None:
    try:
        lesson_title = get_lesson_by_id(item.lesson_id).title
    except Exception:
        lesson_title = item.lesson_id
    st.markdown(
        f"""
<div class="review-chip">
    <strong>{h(lesson_title)} · {h(item.intensity)}</strong>
    <span>{h(item.reason)} — {h(item.action)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_gym_history_item(item) -> None:
    st.markdown(
        f"""
<div class="review-chip">
    <strong>Day {h(item.day)} · {h(item.status)} · {h(item.pace)}</strong>
    <span>{h(item.minutes)} minutes · {h(item.proof_preview)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )




def render_milestone_status(status, is_current: bool = False) -> None:
    tone = "complete" if status.status == "Complete" else "current" if is_current else ""
    evidence = " · ".join(status.evidence)
    st.markdown(
        f"""
<div class="milestone-card {h(tone)}">
    <h3>{h(status.milestone.title)} · {h(percent_label(status.percent))}</h3>
    <p><strong>{h(status.status)}</strong> — {h(status.milestone.goal)}</p>
    <p><b>Proof goal:</b> {h(status.milestone.proof)}</p>
    <p><b>Evidence:</b> {h(evidence)}</p>
    <p><b>Next action:</b> {h(status.next_action)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_graduation_requirement(req) -> None:
    label = "Done" if req.complete else "Open"
    st.markdown(
        f"""
<div class="requirement-row">
    <div><strong>{h(label)} · {h(req.title)}</strong><br><span>{h(req.proof)}</span></div>
    <div><strong>{h(req.current)}/{h(req.target)}</strong></div>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_skill_status(status) -> None:
    next_piece = "Complete" if status.next_lesson_id is None else f"Next lesson: {status.next_lesson_id}"
    st.markdown(
        f"""
<div class="review-chip">
    <strong>{h(status.skill.title)} · {h(percent_label(status.percent))}</strong>
    <span>{h(status.skill.description)}<br><b>Practice:</b> {h(status.skill.practice_goal)}<br><b>{h(next_piece)}</b></span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_standalone_check(check) -> None:
    tone = "success-soft" if check.status == "Pass" else "warning-soft" if check.status in {"Warning", "Optional"} else "danger-soft"
    st.markdown(
        f"""
<div class="check-row {h(tone)}">
    <strong>{h(check.status)} · {h(check.title)}</strong>
    <span>{h(check.detail)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )

def render_proof_preview(card) -> None:
    st.markdown(
        f"""
<div class="proof-card">
    <strong>{h(card.title)}</strong>
    <span>{h(card.summary)}<br><b>Next review:</b> {h(card.next_review)}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def lesson_option_label(lesson_id: str, suggestion_by_id: dict[str, object]) -> str:
    lesson_item = get_lesson_by_id(lesson_id)
    suggestion = suggestion_by_id.get(lesson_id)
    if suggestion is None:
        return f"{lesson_item.title} - any-time pick"
    return f"{lesson_item.title} - {suggestion.label}"


def render_lesson_choice_card(lesson_id: str, reason: str) -> None:
    lesson_item = get_lesson_by_id(lesson_id)
    st.markdown(
        f"""
<div class="lesson-choice-card">
    <strong>Today's lesson: {h(lesson_item.title)}</strong>
    <span>{h(reason)}<br>Estimated lesson time: {h(lesson_item.time_minutes)} minutes.</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def open_mistake_cards(progress_data: dict) -> list[tuple[int, dict]]:
    return [
        (index, card)
        for index, card in enumerate(progress_data.get("mistake_cards", []) or [])
        if card.get("status", "Open") == "Open"
    ]


def select_pace_control(label: str, options, index: int, key: str, help_text: str):
    """Use Streamlit pills when available, otherwise keep the radio fallback."""
    if hasattr(st, "pills"):
        return st.pills(
            label,
            options,
            default=options[index],
            key=key,
            help=help_text,
            selection_mode="single",
            width="stretch",
            required=True,
        )
    return st.radio(label, options, index=index, horizontal=True, key=key, help=help_text)


def render_time_blocks(blocks) -> None:
    for block in blocks:
        st.markdown(
            f"""
<div class="block-list">
    <strong>{h(block.label)} - {h(block.minutes)} min</strong><br>
    <span class="small-muted">{h(block.instruction)}</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )


def render_focus_blocks(blocks) -> None:
    for block in blocks:
        st.markdown(
            f"""
<div class="focus-card">
    <strong>{h(block.label)} - {h(block.minutes)} min</strong>
    <span>{h(block.instruction)}<br><em>{h(block.why_it_helps)}</em></span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )


def render_project_summary(project, progress_data: dict) -> None:
    completion = int(project_completion_percent(progress_data, project.id) * 100)
    milestone = next_project_milestone(progress_data, project.id)
    st.markdown(
        f"""
<div class="project-card">
    <h3>{h(project.title)}</h3>
    <p><strong>{h(project.level)}</strong> · about {h(project.minutes)} min total · {h(completion)}% complete</p>
    <p>{h(project.description)}</p>
    <p><strong>Next milestone:</strong> {h(milestone.title)}</p>
    <p><strong>Skills:</strong> {h(', '.join(project.skills))}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def open_parking_lot_items(progress_data: dict) -> list[tuple[int, dict]]:
    return [
        (index, item)
        for index, item in enumerate(progress_data.get("parking_lot", []) or [])
        if item.get("status", "Open") == "Open"
    ]


def render_badge_shelf(progress_data: dict) -> None:
    badges = earned_badges(progress_data, len(LESSONS))
    if not badges:
        st.info("No badges yet. Complete your first mission or lesson to unlock one.")
        return
    for badge in badges:
        st.markdown(
            f"""
<div class="badge-card">
    <strong>{h(badge.title)}</strong>
    <span>{h(badge.description)}</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )


def render_daily_mission_card(mission) -> None:
    lesson_text = "Open practice" if mission.lesson_id is None else get_lesson_by_id(mission.lesson_id).title
    st.markdown(
        f"""
<div class="mission-card">
    <h2>Day {h(mission.day)}: {h(mission.title)}</h2>
    <p><strong>Focus:</strong> {h(mission.focus)} | <strong>Time:</strong> {h(mission.total_minutes)} minutes | <strong>Lesson:</strong> {h(lesson_text)}</p>
    <p><strong>Fun challenge:</strong> {h(mission.fun_challenge)}</p>
    <p><strong>Proof of understanding:</strong> {h(mission.proof)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_official_resource_summary(resource) -> None:
    st.markdown(
        f"""
<div class="resource-card">
    <h3>{h(resource.provider)}: {h(resource.title)}</h3>
    <div class="resource-meta">{h(resource.resource_type)} | {h(resource.level)} | {h(resource.time_commitment)}</div>
    <p>{h(resource.summary)}</p>
    <p><strong>Credential:</strong> {h(resource.certificate)}</p>
    <p><strong>Use it when:</strong> {h(resource.recommended_when)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def official_resource_status(progress_data: dict, resource_id: str) -> str:
    saved = progress_data.get("official_ai_status", {}).get(resource_id, "Not started")
    return saved if saved in STATUS_OPTIONS else "Not started"


def official_resource_note(progress_data: dict, resource_id: str) -> str:
    return progress_data.get("official_ai_notes", {}).get(resource_id, "")


def render_official_resource(resource, progress_data: dict, progress_path) -> None:
    statuses = progress_data.setdefault("official_ai_status", {})
    notes = progress_data.setdefault("official_ai_notes", {})
    current_status = statuses.get(resource.id, "Not started")
    if current_status not in STATUS_OPTIONS:
        current_status = "Not started"

    with st.container():
        st.markdown(
            f"""
<div class="lesson-row">
    <strong>{h(resource.title)}</strong><br>
    <span class="small-muted">{h(resource.provider)} · {h(resource.resource_type)} · {h(resource.level)} · {h(resource.time_commitment)}</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )
        st.write(resource.summary)
        st.caption(f"Why it matters: {resource.why_it_matters}")
        st.caption(f"Certificate/credential: {resource.certificate}")
        st.caption(f"Recommended timing: {resource.recommended_when}")
        st.markdown("Tags: " + " ".join(f"`{tag}`" for tag in resource.tags))

        status_col, note_col = st.columns([0.8, 1.2])
        with status_col:
            new_status = st.selectbox(
                "Status",
                STATUS_OPTIONS,
                index=STATUS_OPTIONS.index(current_status),
                key=f"official_status_{resource.id}",
            )
            st.markdown(f"[Open official resource]({resource.url})")
        with note_col:
            note = st.text_area(
                "Private note",
                value=notes.get(resource.id, ""),
                key=f"official_note_{resource.id}",
                height=88,
                placeholder="Example: finish this after lesson 4, or add certificate link here.",
            )

        if st.button("Save this resource", key=f"save_official_{resource.id}"):
            record_official_ai_resource(progress_data, resource.id, new_status, note)
            save_progress(progress_data, progress_path)
            st.success("Official resource progress saved.")


def safe_json(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True)


def streamlit_secrets_mapping() -> dict:
    try:
        return dict(st.secrets)
    except Exception:
        return {}


_private_status = private_access_status(os.environ, streamlit_secrets_mapping())
_private_passcode, _private_passcode_source = configured_passcode(os.environ, streamlit_secrets_mapping())
if _private_status.required:
    if not _private_status.configured:
        st.error("Private mode is enabled, but no private passcode is configured.")
        st.info("Set APP_PRIVATE_PASSCODE as an environment variable or Streamlit secret, then restart the app.")
        st.stop()
    if not st.session_state.get("private_access_ok", False):
        st.markdown("# AI Code Tutor")
        st.caption("Private daily coding gym. Enter your access code to continue.")
        entered_passcode = st.text_input("Private access code", type="password")
        if st.button("Unlock private app", type="primary"):
            if verify_passcode(entered_passcode, _private_passcode):
                st.session_state.private_access_ok = True
                st.success("Unlocked.")
                st.rerun()
            else:
                st.error("That access code did not match.")
        st.stop()


with st.sidebar:
    st.header("Your learning space")
    st.caption(private_badge_text(_private_status, unlocked=bool(st.session_state.get("private_access_ok", not _private_status.required))))
    profile_name = st.text_input(
        "Learner profile",
        value=st.session_state.get("profile_name", "guest"),
        help="Use a name like your first name or study group name. It creates a separate progress file.",
    ).strip() or "guest"

    if st.session_state.get("active_profile") != profile_name:
        st.session_state.active_profile = profile_name
        st.session_state.profile_name = profile_name
        st.session_state.ai_messages = []
        st.session_state.selected_lesson_id = ""

    st.caption(f"Profile: `{profile_name}`")
    progress_path = progress_path_for_profile(profile_name)
    progress_data = load_progress(LESSON_IDS, progress_path, profile_name=profile_name)
    apply_theme(low_stimulation=bool(progress_data.get("focus_preferences", {}).get("low_stimulation_mode", False)))

    if (
        not st.session_state.get("selected_lesson_id")
        or st.session_state.selected_lesson_id not in LESSON_IDS
    ):
        st.session_state.selected_lesson_id = first_incomplete_lesson_id(progress_data)

    completed_count = len(progress_data.get("completed_lessons", []))
    completion = completion_percent(progress_data, len(LESSONS))

    st.subheader("Progress")
    st.progress(completion)
    st.write(f"{completed_count} of {len(LESSONS)} lessons complete")
    daily_completion = plan_completion_percent(progress_data)
    st.progress(daily_completion)
    st.write(f"{completed_daily_missions_count(progress_data)} of {len(DAILY_PLAN)} daily missions complete")

    labels = [f"{index + 1}. {lesson_item.title}" for index, lesson_item in enumerate(LESSONS)]
    label_by_id = {lesson_item.id: labels[index] for index, lesson_item in enumerate(LESSONS)}
    id_by_label = {label: lesson_item.id for label, lesson_item in zip(labels, LESSONS)}
    current_label = label_by_id.get(st.session_state.selected_lesson_id, labels[0])

    selected_label = st.selectbox(
        "Choose a lesson",
        labels,
        index=labels.index(current_label),
    )
    st.session_state.selected_lesson_id = id_by_label[selected_label]

    st.divider()
    st.subheader("Study mode")
    st.radio(
        "Session focus",
        ["Learn", "Practice", "Review", "Build"],
        horizontal=True,
        key="study_focus",
        help="This guides the dashboard and daily mission suggestions.",
    )

    st.divider()
    st.subheader("AI status")
    if ai_is_configured():
        st.success(f"Connected: {configured_model()}")
    else:
        st.warning("Not connected yet")
        st.caption("Set OPENAI_API_KEY to enable the AI tutor.")

    st.subheader("Code runner")
    if code_runner_enabled():
        st.warning("Enabled for local use")
    else:
        st.info("Off for safe sharing")
        st.caption("Keep ALLOW_CODE_RUNNER=false on public deployments.")

    st.divider()
    with st.expander("Progress tools"):
        st.download_button(
            "Download my progress JSON",
            data=safe_json(progress_data),
            file_name=f"ai_code_tutor_progress_{profile_slug(profile_name)}.json",
            mime="application/json",
        )
        st.download_button(
            "Download private backup pack",
            data=backup_zip_bytes(profile_name, profile_slug(profile_name), progress_data, LESSONS, DAILY_PLAN),
            file_name=f"ai_code_tutor_backup_{profile_slug(profile_name)}.zip",
            mime="application/zip",
        )
        st.download_button(
            "Download learning transcript",
            data=learning_transcript_markdown(profile_name, progress_data, LESSONS, DAILY_PLAN),
            file_name=f"learning_transcript_{profile_slug(profile_name)}.md",
            mime="text/markdown",
        )
        uploaded_progress = st.file_uploader("Import progress JSON or backup JSON", type=["json"])
        if uploaded_progress is not None and st.button("Import progress"):
            try:
                imported_payload = json.loads(uploaded_progress.getvalue().decode("utf-8"))
                imported = unwrap_progress_import(imported_payload)
                if not isinstance(imported, dict):
                    st.error("That file was valid JSON, but it was not a progress object or AI Code Tutor backup.")
                else:
                    imported = normalize_progress_data(imported, LESSON_IDS, profile_name=profile_name)
                    save_progress(imported, progress_path)
                    st.success("Progress imported and normalized for the current app version.")
                    st.rerun()
            except (UnicodeDecodeError, json.JSONDecodeError):
                st.error("That file was not valid JSON.")

        confirm_reset = st.checkbox("I understand this deletes this profile's progress")
        if confirm_reset and st.button("Reset this profile"):
            if progress_path.exists():
                progress_path.unlink()
            st.session_state.ai_messages = []
            st.rerun()

lesson = get_lesson_by_id(st.session_state.selected_lesson_id)
completed_lessons = set(progress_data.get("completed_lessons", []))
lesson_complete = lesson.id in completed_lessons
next_lesson = get_lesson_by_id(first_incomplete_lesson_id(progress_data))
hero_mission = next_mission(progress_data)
hero_xp = calculate_xp(progress_data)
hero_streak = int(progress_data.get("study_streak", 0) or 0)

st.markdown(
    f"""
<a class="skip-link" href="#today-30-minute-coding-session">Skip to today's session</a>
<div class="hero">
    <h1>AI Code Tutor</h1>
    <p>A private, ADHD-friendly 30-minutes-a-day training app for learning Python, practicing prompts, building projects, and growing into AI workflows.</p>
    <div class="hero-meta">
        <span class="hero-stat">Today: Day {h(hero_mission.day)} - {h(hero_mission.title)}</span>
        <span class="hero-stat">Next lesson: {h(next_lesson.title)}</span>
        <span class="hero-stat">Streak: {h(hero_streak)} day{'s' if hero_streak != 1 else ''}</span>
        <span class="hero-stat">XP: {h(hero_xp)}</span>
    </div>
</div>
""".strip(),
    unsafe_allow_html=True,
)

feature_cols = st.columns(6)
with feature_cols[0]:
    render_card("30-day plan", "Daily 30-minute missions with review days, tiny wins, and capstone prep.")
with feature_cols[1]:
    render_card("ADHD-friendly", "Tiny starts, parking lot, rescue mode, focus check-ins, streaks, XP, and badges.")
with feature_cols[2]:
    render_card("Milestones", "A visible path from Python starting line to capstone graduation proof.")
with feature_cols[3]:
    render_card("Prompt Lab", "Score prompts with a rubric and rewrite them for stronger AI results.")
with feature_cols[4]:
    render_card("Official AI track", "Claude, Gumloop, OpenAI, Google, Microsoft, AWS, Hugging Face, and NVIDIA resources.")
with feature_cols[5]:
    render_card("Private-ready", "GitHub-private workflow, Docker, CI tests, secrets examples, and safe sharing defaults.")

(
    today_tab,
    path_tab,
    focus_tab,
    dashboard_tab,
    lesson_tab,
    quiz_tab,
    code_tab,
    projects_tab,
    prompt_tab,
    official_ai_tab,
    ai_tab,
    notes_tab,
    deploy_tab,
) = st.tabs(["Today", "Path", "Focus Coach", "Dashboard", "Learn", "Quiz", "Code Lab", "Projects", "Prompt Lab", "AI Certs", "AI Tutor", "Notes", "Deploy"])

with today_tab:
    mission = next_mission(progress_data)
    st.header("Today: Daily Coding Gym")
    st.caption("A 30-minute coding session with one path: warm up, learn, do reps, use AI carefully, save proof, stop.")

    timeline_days = daily_timeline(progress_data, len(DAILY_PLAN))
    with st.expander("30-day path", expanded=False):
        st.caption(plan_progress_sentence(progress_data))
        render_daily_timeline(timeline_days)
        render_timeline_legend(timeline_days)

    today_milestone = current_milestone_status(progress_data)
    render_card(
        f"Current learning milestone: {today_milestone.milestone.title}",
        f"{percent_label(today_milestone.percent)} done. Goal: {today_milestone.milestone.goal} Next: {today_milestone.next_action}",
        "success-soft" if today_milestone.status == "Complete" else "",
    )

    existing_gym_session = gym_session_for_day(progress_data, mission.day)
    gym_saved = gym_session_is_saved(progress_data, mission.day)
    gym_active = gym_session_is_active(progress_data, mission.day)
    preferred_minutes = (progress_data.get("focus_preferences", {}) or {}).get("default_minutes", 30)
    resume_setup = workout_resume_setup(existing_gym_session, preferred_minutes, LESSON_IDS)
    saved_pace = resume_setup.pace_label if resume_setup.locked else None
    saved_lesson_id = resume_setup.lesson_id
    default_pace_index = SESSION_LABELS.index(resume_setup.pace_label)
    setup_locked = bool(resume_setup.locked and (gym_active or gym_saved))

    toolbar_cols = st.columns([1.25, 0.8, 0.8])
    with toolbar_cols[0]:
        if setup_locked:
            session_pace = saved_pace or SESSION_LABELS[default_pace_index]
            st.selectbox(
                "Time I have today",
                SESSION_LABELS,
                index=SESSION_LABELS.index(session_pace),
                key=f"today_session_pace_locked_{mission.day}",
                disabled=True,
                help="This workout was already started, so the app keeps the saved pace for a clean resume.",
            )
            st.caption("Resume mode: pace is locked so your saved checklist still matches the workout.")
        else:
            session_pace = select_pace_control(
                "Time I have today",
                SESSION_LABELS,
                index=default_pace_index,
                key=f"today_session_pace_{mission.day}",
                help_text="Choose rescue when starting feels hard. Rescue mode still counts.",
            ) or SESSION_LABELS[default_pace_index]
            saved_default_label = SESSION_LABELS[default_pace_index]
            st.caption(f"Time I have today: choose 10, 30, or 45 minutes. Saved default: {saved_default_label}. Use Remember or the checkbox below to make a new default.")
    with toolbar_cols[1]:
        today_energy = st.selectbox("Energy", ENERGY_LEVELS, index=1, key=f"today_energy_{mission.day}")
    with toolbar_cols[2]:
        today_focus = st.selectbox("Focus", FOCUS_LEVELS, index=1, key=f"today_focus_{mission.day}")

    selected_choice = session_choice_by_label(session_pace)
    if setup_locked:
        st.caption(f"Resuming saved workout: {selected_choice.label}. The lesson and checklist stay locked until you save or skip this session.")
    remember_on_start = False
    if not setup_locked:
        remember_on_start = st.checkbox(
            "Make this workout length my default for future days",
            value=False,
            key=f"remember_pace_on_start_{mission.day}",
            help="This saves your selected 10/30/45 minute length as the default for future sessions when you start today's workout.",
        )
    if not setup_locked and selected_choice.minutes != int(preferred_minutes or 30):
        preference_cols = st.columns([0.7, 1.4])
        with preference_cols[0]:
            if st.button(f"Remember {selected_choice.label}", key=f"remember_pace_{mission.day}"):
                save_focus_preferences(progress_data, {"default_minutes": selected_choice.minutes})
                save_progress(progress_data, progress_path)
                st.success(f"Default workout saved as {selected_choice.label}.")
                st.rerun()
        with preference_cols[1]:
            st.caption(
                "This only changes your default for future days. Today's started workouts keep their saved pace so you can resume cleanly."
            )

    review_lesson_ids_for_time = [item.lesson_id for item in build_review_items(progress_data, LESSON_IDS, max_items=5)]
    lesson_options = workout_lesson_options(
        progress_data,
        LESSONS,
        mission,
        selected_choice.minutes,
        review_lesson_ids=review_lesson_ids_for_time or review_queue(progress_data, LESSON_IDS),
        current_lesson_id=saved_lesson_id if setup_locked else None,
    )
    if not lesson_options:
        active_lesson_id = mission.lesson_id or first_incomplete_lesson_id(progress_data)
        active_lesson_reason = "safe fallback"
    else:
        option_labels = [option.label for option in lesson_options]
        option_by_label = {option.label: option for option in lesson_options}
        default_lesson_label = option_labels[0]
        if saved_lesson_id:
            for option in lesson_options:
                if option.lesson_id == saved_lesson_id:
                    default_lesson_label = option.label
                    break
        lesson_choice_key = f"today_lesson_choice_{mission.day}_{selected_choice.minutes}"
        if setup_locked:
            selected_lesson_label = st.selectbox(
                "Today's lesson based on time",
                option_labels,
                index=option_labels.index(default_lesson_label),
                key=f"{lesson_choice_key}_locked",
                disabled=True,
                help="This workout already has a saved lesson so you can continue where you stopped.",
            )
            st.caption("Resume mode: lesson is locked to the one saved with this workout.")
        else:
            selected_lesson_label = st.selectbox(
                "Today's lesson based on time",
                option_labels,
                index=option_labels.index(default_lesson_label),
                key=lesson_choice_key,
                help="Short sessions suggest review or a tiny next step. Longer sessions suggest the full lesson or stretch work.",
            )
        active_option = option_by_label[selected_lesson_label]
        active_lesson_id = active_option.lesson_id
        active_lesson_reason = active_option.reason
    active_lesson = get_lesson_by_id(active_lesson_id)
    st.caption(f"Lesson for the time you have today: {active_lesson.title}. Why it fits: {active_lesson_reason} for a {selected_choice.minutes}-minute workout.")

    if not setup_locked:
        with st.expander("Preview how time changes the lesson", expanded=False):
            st.caption("This lets you change today's lesson before you start, based on whether you have 10, 30, or 45 minutes.")
            preview_cols = st.columns(3)
            for col, minutes, pace_label in zip(preview_cols, (10, 30, 45), SESSION_LABELS):
                preview_options = workout_lesson_options(
                    progress_data,
                    LESSONS,
                    mission,
                    minutes,
                    review_lesson_ids=review_lesson_ids_for_time or review_queue(progress_data, LESSON_IDS),
                )
                preview_option = preview_options[0] if preview_options else None
                if preview_option:
                    preview_lesson = get_lesson_by_id(preview_option.lesson_id)
                    preview_body = f"{preview_lesson.title}. Reason: {preview_option.reason}."
                else:
                    preview_body = "Use the current daily mission as a safe fallback."
                with col:
                    render_card(pace_label, preview_body)
            st.caption("After you press Start Today, the app locks the selected time and lesson so Stop & save for later can resume cleanly.")

    resume_summary = workout_resume_summary(progress_data, mission.day)
    if resume_summary and not gym_saved:
        render_resume_banner(resume_summary, active_lesson.title)

    proof_key = f"gym_proof_{mission.day}"
    review_key = f"gym_next_review_{mission.day}"
    gym_blocks = gym_blocks_for_choice(selected_choice)

    if setup_locked and gym_active and not gym_saved:
        with st.expander("Time changed since you paused?", expanded=False):
            st.caption("Use this only when you truly need to resize the saved workout. The app will keep your proof draft and compatible checked reps.")
            convert_pace = st.selectbox(
                "Change this saved workout to",
                SESSION_LABELS,
                index=SESSION_LABELS.index(selected_choice.label),
                key=f"convert_pace_{mission.day}",
            )
            convert_choice = session_choice_by_label(convert_pace)
            convert_options = workout_lesson_options(
                progress_data,
                LESSONS,
                mission,
                convert_choice.minutes,
                review_lesson_ids=review_lesson_ids_for_time or review_queue(progress_data, LESSON_IDS),
                current_lesson_id=active_lesson_id,
            )
            convert_labels = [option.label for option in convert_options]
            if convert_labels:
                convert_label = st.selectbox("Lesson for the new time", convert_labels, key=f"convert_lesson_{mission.day}_{convert_choice.minutes}")
                convert_option = {option.label: option for option in convert_options}[convert_label]
                if st.button("Convert saved workout", key=f"convert_workout_{mission.day}"):
                    converted_blocks = gym_blocks_for_choice(convert_choice)
                    old_state = existing_gym_session.get("step_state", {}) or {}
                    converted_state = {block.id: bool(old_state.get(block.id, False)) for block in converted_blocks}
                    pause_gym_session(
                        progress_data,
                        mission.day,
                        pace=convert_choice.label,
                        minutes=total_gym_minutes(converted_blocks),
                        lesson_id=convert_option.lesson_id,
                        step_state=converted_state,
                        proof_note=str(st.session_state.get(proof_key, existing_gym_session.get("proof_note", ""))),
                        next_review=str(st.session_state.get(review_key, existing_gym_session.get("next_review", ""))),
                    )
                    save_progress(progress_data, progress_path)
                    st.success("Saved workout resized. It will resume with the new time and lesson.")
                    st.rerun()
            else:
                st.info("No lesson option found for that time. Keep the current saved workout.")

    saved_steps = daily_checklist_steps(progress_data, mission.day)
    saved_steps.update({str(key): bool(value) for key, value in (existing_gym_session.get("step_state", {}) or {}).items()})
    visible_steps = merge_step_state(saved_steps, st.session_state, mission.day, gym_blocks)
    gym_percent = gym_completion(visible_steps, gym_blocks)
    gym_action = next_gym_action(mission.title, visible_steps, gym_blocks, gym_saved)
    if proof_key not in st.session_state and existing_gym_session.get("proof_note"):
        st.session_state[proof_key] = existing_gym_session.get("proof_note", "")
    if review_key not in st.session_state and existing_gym_session.get("next_review"):
        st.session_state[review_key] = existing_gym_session.get("next_review", "")
    proof_note = st.session_state.get(proof_key, "")

    render_gym_shell(
        mission,
        gym_action,
        gym_percent,
        selected_choice.label,
        total_gym_minutes(gym_blocks),
        gym_saved,
    )
    st.progress(gym_percent)
    st.caption(gym_motivation_copy(gym_percent, selected_choice.label, gym_saved))

    start_key = f"gym_started_{mission.day}"
    workout_started = bool(st.session_state.get(start_key, False) or gym_percent > 0 or gym_saved or gym_active)
    if gym_active and not gym_saved:
        st.info("Resuming a workout you already started. Continue with the next open block, or save it as in progress.")
    if not workout_started:
        st.markdown(
            """
<div class="gym-start">
    <strong>Open app → press Start Today → follow one block at a time → save proof → done.</strong><br>
    <span class="small-muted">No browsing required. The rest of the app is available only when you need it.</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )
        if st.button("Start Today", type="primary", key=f"start_today_{mission.day}"):
            st.session_state[start_key] = True
            if remember_on_start:
                save_focus_preferences(progress_data, {"default_minutes": selected_choice.minutes})
            start_gym_session(
                progress_data,
                mission.day,
                pace=selected_choice.label,
                minutes=total_gym_minutes(gym_blocks),
                lesson_id=active_lesson_id,
                step_state=visible_steps,
            )
            save_progress(progress_data, progress_path)
            st.rerun()
        with st.expander("Preview today's workout", expanded=False):
            for block in gym_blocks:
                render_gym_block(block, False)
    else:
        left_today, right_today = st.columns([1.12, 1])
        with left_today:
            st.subheader("Focus Mode: one rep at a time")
            st.caption("The smooth path is one visible rep, one action button, then save. The full One-screen checklist is still below if you want manual control.")
            focus_card = current_focus_card(visible_steps, gym_blocks, session_saved=gym_saved)
            render_focus_workout_card(focus_card)
            st.caption(focus_completion_sentence(focus_card))

            focus_cols = st.columns([1, 1])
            with focus_cols[0]:
                if not gym_saved and not focus_card.is_complete and st.button("Mark this rep done & save", type="primary", key=f"focus_done_{mission.day}_{focus_card.block_id}"):
                    current_state = {block.id: bool(st.session_state.get(f"coach_step_{mission.day}_{block.id}", visible_steps.get(block.id, False))) for block in gym_blocks}
                    current_state = mark_focus_step_done(current_state, gym_blocks)
                    pause_gym_session(
                        progress_data,
                        mission.day,
                        pace=selected_choice.label,
                        minutes=total_gym_minutes(gym_blocks),
                        lesson_id=active_lesson_id,
                        step_state=current_state,
                        proof_note=str(st.session_state.get(proof_key, "")),
                        next_review=str(st.session_state.get(review_key, "")),
                    )
                    save_progress(progress_data, progress_path)
                    st.success("Rep saved. Continue when you are ready, or stop here and come back later.")
                    st.rerun()
            with focus_cols[1]:
                if st.button("Save current draft", key=f"save_coach_steps_{mission.day}"):
                    current_state = {block.id: bool(st.session_state.get(f"coach_step_{mission.day}_{block.id}", visible_steps.get(block.id, False))) for block in gym_blocks}
                    pause_gym_session(
                        progress_data,
                        mission.day,
                        pace=selected_choice.label,
                        minutes=total_gym_minutes(gym_blocks),
                        lesson_id=active_lesson_id,
                        step_state=current_state,
                        proof_note=str(st.session_state.get(proof_key, "")),
                        next_review=str(st.session_state.get(review_key, "")),
                    )
                    save_progress(progress_data, progress_path)
                    st.success("Draft saved. You can close the app and continue later from this exact workout.")
                    st.rerun()

            with st.expander("Full One-screen checklist", expanded=False):
                st.caption("Manual backup view. Use this when you want to check multiple blocks at once.")
                for block in gym_blocks:
                    current_value = bool(visible_steps.get(block.id, False))
                    st.checkbox(
                        f"{block.minutes}m - {block.label}",
                        value=current_value,
                        key=f"coach_step_{mission.day}_{block.id}",
                        help=f"{block.action} Proof: {block.proof}",
                    )
                    render_gym_block(block, current_value)

            st.subheader("Today's lesson link")
            render_card(
                active_lesson.title,
                f"Matched to your {selected_choice.minutes}-minute workout: {active_lesson_reason}. Do not over-study; one clear idea is enough.",
            )
            if st.button("Open selected lesson", type="primary"):
                st.session_state.selected_lesson_id = active_lesson_id
                st.rerun()

            with st.expander("Full mission recipe", expanded=False):
                render_daily_mission_card(mission)
                render_time_blocks(mission.blocks)

        with right_today:
            st.subheader("Proof card")
            st.caption("Close the workout with one small artifact so tomorrow knows where to start.")
            proof_note = st.text_area(
                "Today I learned, fixed, or noticed...",
                key=proof_key,
                height=95,
                placeholder="Example: I learned that return gives a value back, while print only displays it.",
            )
            next_review_text = st.text_input(
                "Tomorrow, review this tiny thing",
                key=review_key,
                placeholder="Example: function return values",
            )
            finish_status, finish_message = workout_finish_status(gym_percent, proof_note, gym_saved)
            st.metric("Finish status", finish_status)
            st.caption(finish_message)
            render_proof_preview(proof_card_summary(mission.day, mission.title, proof_note, next_review_text))

            if st.button("Stop & save for later", key=f"pause_gym_{mission.day}"):
                current_state = {block.id: bool(st.session_state.get(f"coach_step_{mission.day}_{block.id}", False)) for block in gym_blocks}
                pause_gym_session(
                    progress_data,
                    mission.day,
                    pace=selected_choice.label,
                    minutes=total_gym_minutes(gym_blocks),
                    lesson_id=active_lesson_id,
                    step_state=current_state,
                    proof_note=proof_note,
                    next_review=next_review_text,
                )
                save_progress(progress_data, progress_path)
                st.success("Stopped and saved. When you come back, Today will resume this exact time, lesson, checklist, proof draft, and review note.")
                st.rerun()

            with st.form(f"save_gym_session_{mission.day}"):
                mood = st.selectbox("How did the workout feel?", ["Easy", "Good", "Stuck but learning", "Hard", "Fun"], key=f"gym_mood_{mission.day}")
                mission_status = st.selectbox("Mission status", ["Completed", "In progress", "Skipped"], key=f"gym_status_{mission.day}")
                mark_selected_lesson = st.checkbox(
                    "Mark selected lesson complete when this workout is completed",
                    value=selected_choice.minutes >= 30,
                    key=f"mark_workout_lesson_complete_{mission.day}",
                    help="Rescue sessions can save the habit without pretending a full lesson is done.",
                )
                save_gym = st.form_submit_button("Save proof card")
            if save_gym:
                current_state = {block.id: bool(st.session_state.get(f"coach_step_{mission.day}_{block.id}", False)) for block in gym_blocks}
                current_completion = gym_completion(current_state, gym_blocks)
                save_decision = workout_save_decision(current_completion, proof_note, mission_status)
                if not save_decision.ok:
                    st.warning(save_decision.message)
                else:
                    record_daily_checklist(progress_data, mission.day, current_state)
                    record_gym_session(
                        progress_data,
                        mission.day,
                        pace=selected_choice.label,
                        status=save_decision.gym_status,
                        proof_note=proof_note,
                        next_review=next_review_text,
                        minutes=total_gym_minutes(gym_blocks),
                        lesson_id=active_lesson_id,
                        step_state=current_state,
                    )
                    record_daily_mission(progress_data, mission.day, status=save_decision.mission_status, mood=mood, reflection=proof_note)
                    if save_decision.mission_status == "Completed" and mark_selected_lesson and active_lesson_id:
                        mark_lesson_complete(progress_data, active_lesson_id)
                    save_progress(progress_data, progress_path)
                    st.success(save_decision.message)
                    st.rerun()

            st.subheader("Review queue")
            review_items = build_review_items(progress_data, LESSON_IDS)
            if review_items:
                for item in review_items:
                    render_review_item(item)
            else:
                st.info("No weak spots logged yet. After a quiz miss or bug, add one mistake card.")

            with st.expander("Mistake notebook", expanded=True):
                st.caption("Turn errors into tomorrow's warm-up instead of forgetting them.")
                concept = st.text_input("Concept", key=f"mistake_concept_{mission.day}", placeholder="Example: if statements")
                mistake = st.text_area("Mistake or confusion", key=f"mistake_text_{mission.day}", height=70, placeholder="Example: I forgot the colon after if.")
                fix = st.text_area("Correct pattern or reminder", key=f"mistake_fix_{mission.day}", height=70, placeholder="Example: if condition: then indent the next line.")
                if st.button("Add mistake card", key=f"add_mistake_{mission.day}"):
                    if add_mistake_card(progress_data, concept, mistake, fix, lesson_id=active_lesson_id):
                        save_progress(progress_data, progress_path)
                        st.success("Mistake card saved for review.")
                        st.rerun()
                    else:
                        st.warning("Write either a mistake or a fix first.")

                for index, card in open_mistake_cards(progress_data)[-3:]:
                    st.markdown(
                        f"""
<div class="review-chip">
    <strong>{h(card.get('concept', 'Review'))}</strong>
    <span>{h(truncate_text(card.get('mistake', ''), 120))}<br><b>Fix:</b> {h(truncate_text(card.get('fix', ''), 120))}</span>
</div>
""".strip(),
                        unsafe_allow_html=True,
                    )
                    if st.button("Close mistake card", key=f"close_mistake_{index}"):
                        close_mistake_card(progress_data, index)
                        save_progress(progress_data, progress_path)
                        st.rerun()

            st.subheader("ADHD-friendly setup")
            render_done_zone(gym_percent, gym_saved)
            mode = recommended_focus_mode(today_energy, selected_choice.minutes)
            st.caption(f"Recommended focus mode: {mode.title}")
            with st.expander("Show focus blocks", expanded=False):
                render_focus_blocks(focus_blocks(mode.minutes, today_energy))

            quick_thought = st.text_input("Parking lot thought", key=f"today_parking_{mission.day}", placeholder="Example: research laptops later")
            if st.button("Park thought", key=f"park_today_{mission.day}"):
                if add_parking_lot_item(progress_data, quick_thought, lesson_id=active_lesson_id, source="Today"):
                    save_progress(progress_data, progress_path)
                    st.success("Parked. Back to the next rep.")
                    st.rerun()
                else:
                    st.warning("Write a thought first.")

    gym_metrics = st.columns(4)
    xp = calculate_xp(progress_data)
    gym_metrics[0].metric("Workout", gym_progress_label(visible_steps, gym_blocks), percent_label(gym_percent))
    gym_metrics[1].metric("Daily missions", f"{completed_daily_missions_count(progress_data)}/{len(DAILY_PLAN)}")
    gym_metrics[2].metric("Streak", f"{progress_data.get('study_streak', 0)} days")
    gym_metrics[3].metric("XP", xp, level_for_xp(xp).split(" - ")[-1])

    with st.expander("Daily-use smoothness check", expanded=False):
        st.caption("Private QA for the daily habit loop: default time, stop/resume, one-rep focus mode, and proof habit.")
        for check in daily_use_smoothness_checks(progress_data, mission.day, gym_blocks, preferred_minutes):
            render_smoothness_check(check)
        resume_report = resume_safety_report(existing_gym_session, gym_blocks)
        if resume_report.can_resume:
            st.caption(f"Resume check: {resume_report.saved_blocks} block(s) saved for {resume_report.saved_pace}; lesson {resume_report.saved_lesson_id or 'not locked'}.")

    with st.expander("Recent gym history", expanded=False):
        st.caption(gym_history_summary(progress_data))
        history_items = gym_session_history(progress_data, limit=5)
        if history_items:
            for history_item in history_items:
                render_gym_history_item(history_item)
        else:
            st.info("No history yet. Save your first proof card to start the log.")

    if mission.official_resource_ids:
        with st.expander("Official AI side quest", expanded=False):
            for resource in resources_for_ids(mission.official_resource_ids):
                st.markdown(f"- [{resource.provider}: {resource.title}]({resource.url})")

    with st.expander("Badge shelf", expanded=False):
        render_badge_shelf(progress_data)


with path_tab:
    st.header("Learning Path: Python basics to capstone")
    st.caption("This is the finish line: milestones, proof, and graduation requirements for learning Python and general coding basics.")

    path_metrics = st.columns(4)
    ready = graduation_readiness(progress_data, total_lessons=len(LESSONS))
    current_status = current_milestone_status(progress_data)
    path_metrics[0].metric("Learning progress", percent_label(overall_learning_percent(progress_data)))
    path_metrics[1].metric("Milestones", f"{completed_milestones_count(progress_data)}/{len(milestone_statuses(progress_data))}")
    path_metrics[2].metric("Graduation", ready.status, percent_label(ready.percent))
    path_metrics[3].metric("Current milestone", current_status.milestone.title.split(" - ")[-1])

    render_coach_summary(
        "Goal: learn the Python basics by building proof",
        "A lesson only counts when you can explain it, practice it, and save evidence.",
        GRADUATION_PROMISE,
    )
    st.progress(ready.percent)
    st.caption(ready.summary)

    left_path, right_path = st.columns([1.25, 1])
    with left_path:
        st.subheader("Milestone map")
        statuses = milestone_statuses(progress_data)
        for status in statuses:
            render_milestone_status(status, is_current=status.milestone.id == current_status.milestone.id)

    with right_path:
        st.subheader("Graduation checklist")
        st.caption("These requirements make the app feel like a complete course instead of random practice.")
        for req in ready.requirements:
            render_graduation_requirement(req)
        st.info(f"Next graduation action: {ready.next_action}")

        with st.expander("What you should know by the end", expanded=True):
            for outcome in learning_outcomes():
                st.write(f"- {outcome}")

        with st.expander("Skill map", expanded=True):
            st.caption("Each skill unlocks when the related lesson is complete. Use this when you want to see what the daily gym is actually teaching.")
            for skill_status in skill_statuses(progress_data):
                render_skill_status(skill_status)

        with st.expander("Graduation proof downloads", expanded=True):
            st.caption("These exports make the app feel complete: a private transcript, certificate preview, and backup pack you can keep outside the app.")
            st.download_button(
                "Download certificate preview",
                data=certificate_markdown(profile_name, progress_data, LESSONS),
                file_name=f"ai_code_tutor_certificate_{profile_slug(profile_name)}.md",
                mime="text/markdown",
                key="download_certificate_path",
            )
            st.download_button(
                "Download full transcript",
                data=learning_transcript_markdown(profile_name, progress_data, LESSONS, DAILY_PLAN),
                file_name=f"ai_code_tutor_transcript_{profile_slug(profile_name)}.md",
                mime="text/markdown",
                key="download_transcript_path",
            )
            st.download_button(
                "Download backup pack",
                data=backup_zip_bytes(profile_name, profile_slug(profile_name), progress_data, LESSONS, DAILY_PLAN),
                file_name=f"ai_code_tutor_backup_{profile_slug(profile_name)}.zip",
                mime="application/zip",
                key="download_backup_path",
            )

        with st.expander("Capstone proof idea", expanded=False):
            st.write(
                "A good final proof is a tiny app or script you can explain in 60 seconds: what problem it solves, "
                "what inputs it uses, what output it gives, one bug you fixed, and one test or checklist that proves it works."
            )
            st.code(
                """Capstone demo script
1. This app/script helps with: ______
2. User input: ______
3. Python concepts used: variables, functions, conditionals, lists/dicts, tests
4. Bug I fixed: ______
5. Next improvement: ______""",
                language="text",
            )



with focus_tab:
    st.header("Focus Coach: ADHD-friendly coding sessions")
    st.write(
        "This section turns coding into small, visible, low-pressure actions. "
        "It is not medical advice; it is a study-design layer for focus, memory, and momentum."
    )

    pref = progress_data.get("focus_preferences", {})
    pref_cols = st.columns(5)
    with pref_cols[0]:
        default_minutes = st.selectbox("Default session", [10, 30, 45], index=[10, 30, 45].index(int(pref.get("default_minutes", 30))), format_func=lambda x: f"{x} min")
    with pref_cols[1]:
        adhd_mode = st.checkbox("ADHD-friendly mode", value=bool(pref.get("adhd_friendly_mode", True)))
    with pref_cols[2]:
        low_stim = st.checkbox("Low-stimulation UI", value=bool(pref.get("low_stimulation_mode", False)))
    with pref_cols[3]:
        break_reminders = st.checkbox("Break reminders", value=bool(pref.get("break_reminders", True)))
    with pref_cols[4]:
        reward_style = st.selectbox("Reward style", ["Tiny wins", "Badges", "Quiet progress"], index=["Tiny wins", "Badges", "Quiet progress"].index(pref.get("reward_style", "Tiny wins") if pref.get("reward_style", "Tiny wins") in ["Tiny wins", "Badges", "Quiet progress"] else "Tiny wins"))

    if st.button("Save focus preferences"):
        save_focus_preferences(
            progress_data,
            {
                "default_minutes": default_minutes,
                "adhd_friendly_mode": adhd_mode,
                "low_stimulation_mode": low_stim,
                "break_reminders": break_reminders,
                "reward_style": reward_style,
            },
        )
        save_progress(progress_data, progress_path)
        st.success("Focus preferences saved.")
        st.rerun()

    coach_cols = st.columns([1.15, 1])
    with coach_cols[0]:
        st.subheader("Build your next session")
        energy = st.selectbox("Energy right now", ENERGY_LEVELS, index=1, key="focus_tab_energy")
        available_minutes = st.slider("Minutes available", 10, 45, int(pref.get("default_minutes", 30)), step=5)
        mode = recommended_focus_mode(energy, available_minutes)
        blocks = focus_blocks(mode.minutes, energy)
        st.info(f"Recommended: {mode.title} - {mode.summary}")
        st.caption(f"This plan totals {total_focus_minutes(blocks)} minutes.")
        render_focus_blocks(blocks)

        with st.expander("Body-double script"):
            for line in body_double_script(next_mission(progress_data).title):
                st.write(f"- {line}")

    with coach_cols[1]:
        st.subheader("Parking lot")
        st.caption("Put distracting ideas here so you do not have to chase them mid-session.")
        thought = st.text_input("Distracting thought or side quest", key="focus_parking_lot_input")
        if st.button("Park this thought"):
            if add_parking_lot_item(progress_data, thought, lesson_id=lesson.id, source="Focus Coach"):
                save_progress(progress_data, progress_path)
                st.success("Parked. Return to the next tiny action.")
                st.rerun()
            else:
                st.warning("Write a thought first, even a messy one.")

        open_items = open_parking_lot_items(progress_data)
        if not open_items:
            st.info("Parking lot is empty.")
        for index, item in open_items[-6:]:
            safe_thought = safe_html_text(truncate_text(item.get("thought", ""), 300))
            st.markdown(f"<div class='parking-item'>{safe_thought}</div>", unsafe_allow_html=True)
            if st.button("Close", key=f"close_parking_{index}"):
                close_parking_lot_item(progress_data, index)
                save_progress(progress_data, progress_path)
                st.rerun()

        st.subheader("Focus check-in")
        focus_level = st.selectbox("Focus level", FOCUS_LEVELS, index=1, key="focus_tab_level")
        blockers = st.text_area("What might pull you away?", height=80, key="focus_tab_blockers")
        win = st.text_area("What tiny win would count today?", height=80, key="focus_tab_win")
        if st.button("Save focus check-in"):
            record_focus_checkin(progress_data, energy, focus_level, blockers, win)
            save_progress(progress_data, progress_path)
            st.success(f"Check-in saved. Focus score: {focus_checkin_score(energy, focus_level)}/6.")

    st.subheader("Design rules used in this app")
    for principle in ADHD_DESIGN_PRINCIPLES:
        st.write(f"- {principle}")

with dashboard_tab:
    if completed_count == 0:
        st.success("Welcome. This profile is brand new, so start with Lesson 1 and use the checklist below.")

    with st.expander("Start here: your first 10 minutes", expanded=completed_count == 0):
        intro_cols = st.columns(4)
        with intro_cols[0]:
            render_step(1, "Read", "Open the Learn tab and read the current lesson once without memorizing.")
        with intro_cols[1]:
            render_step(2, "Check", "Take the quiz. Misses are useful because they tell you what to review.")
        with intro_cols[2]:
            render_step(3, "Practice", "Try Code Lab from the starter code before viewing the sample solution.")
        with intro_cols[3]:
            render_step(4, "Prompt", "Use Prompt Lab to ask for help with context, constraints, and verification.")

    official_stats = official_resource_stats(progress_data)
    metric_cols = st.columns(6)
    metric_cols[0].metric("Lessons complete", f"{completed_count}/{len(LESSONS)}")
    metric_cols[1].metric("Daily missions", f"{completed_daily_missions_count(progress_data)}/{len(DAILY_PLAN)}")
    metric_cols[2].metric("Study streak", f"{progress_data.get('study_streak', 0)} days")
    metric_cols[3].metric("Quiz average", f"{get_quiz_average(progress_data)}%")
    metric_cols[4].metric("Best prompt score", f"{get_best_prompt_score(progress_data)}/10")
    metric_cols[5].metric("AI resources done", f"{official_stats['completed']}/{official_stats['total']}")

    left, right = st.columns([1.25, 1])
    with left:
        st.subheader("Recommended next step")
        current_mission = next_mission(progress_data)
        render_card(
            f"Day {current_mission.day}: {current_mission.title}",
            f"30-minute mission. Focus: {current_mission.focus}. Proof: {current_mission.proof}",
            "success-soft" if current_mission.lesson_id == lesson.id else "",
        )
        render_card(
            next_lesson.title,
            f"Next incomplete lesson. Estimated lesson time: {next_lesson.time_minutes} minutes. Focus: {st.session_state.get('study_focus', 'Learn')}.",
        )
        if st.button("Jump to recommended lesson", type="primary"):
            st.session_state.selected_lesson_id = next_lesson.id
            st.rerun()

        st.subheader("Curriculum map")
        for index, item in enumerate(LESSONS, start=1):
            status = "✅ Complete" if item.id in completed_lessons else "⬜ Not complete"
            score = progress_data.get("quiz_scores", {}).get(item.id)
            score_text = f"Quiz: {score['percent']}%" if score else "Quiz: not taken"
            st.markdown(
                f"""
<div class="lesson-row">
    <strong>{index}. {item.title}</strong><br>
    <span class="small-muted">{item.level} · {item.time_minutes} min · {status} · {score_text}</span>
</div>
""".strip(),
                unsafe_allow_html=True,
            )

    with right:
        st.subheader("How to use this app")
        st.markdown(
            """
1. Start in the Today tab and follow the 30-minute mission.
2. Read, quiz, code, then reflect before moving on.
3. Use review days to revisit older lessons from memory.
4. Use Prompt Lab to ask AI for hints, tests, and examples.
5. Save a tiny win each day so the app becomes your learning journal.
""".strip()
        )
        st.subheader("Current level")
        xp = calculate_xp(progress_data)
        render_card(level_for_xp(xp), f"{xp} XP earned from lessons, quizzes, prompts, daily missions, and AI resources.")
        render_level_progress(xp)
        st.caption(streak_microcopy(int(progress_data.get("study_streak", 0) or 0), int(progress_data.get("longest_streak", 0) or 0)))
        with st.expander("Unlocked badges", expanded=False):
            render_badge_shelf(progress_data)

        ai_stats = official_resource_stats(progress_data)
        st.subheader("Official AI track")
        render_card(
            "External learning progress",
            (
                f"{ai_stats['started']} started, {ai_stats['completed']} completed, "
                f"{ai_stats['certificate_options']} certificate/credential options across "
                f"{ai_stats['total']} curated official resources."
            ),
        )
        st.info("While the GitHub repo is private, you can still run tests through GitHub Actions. Do not add API keys to code files.")

with lesson_tab:
    st.header(lesson.title)
    render_status_pills(lesson.level, lesson.time_minutes, lesson_complete)
    st.info("30-minute habit tip: read for 10 minutes, code for 10 minutes, quiz or review for 5 minutes, then write a 5-minute reflection.")

    st.subheader("Objectives")
    for objective in lesson.objectives:
        st.write(f"- {objective}")

    st.subheader("Lesson")
    st.markdown(lesson.explanation)

    st.subheader("Key terms")
    st.write(" ".join(f"`{term}`" for term in lesson.key_terms))

    st.info(f"Prompt skill: {lesson.prompt_skill}")

    action_cols = st.columns([1, 1.2])
    with action_cols[0]:
        if lesson_complete:
            st.success("You marked this lesson complete.")
        elif st.button("Mark lesson complete", type="primary"):
            mark_lesson_complete(progress_data, lesson.id)
            save_progress(progress_data, progress_path)
            st.success("Lesson marked complete.")
            st.rerun()
    with action_cols[1]:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI to explain this lesson in simpler words",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            prompt = (
                f"Explain the lesson '{lesson.title}' in beginner-friendly language. "
                "Use a tiny Python example and one check-in question."
            )
            st.write(call_ai_tutor([{"role": "user", "content": prompt}], lesson.title, lesson.level))
        if not ai_ready:
            st.caption("AI buttons are disabled until OPENAI_API_KEY is configured. The rest of the app works without AI.")

with quiz_tab:
    st.header(f"Quiz: {lesson.title}")
    st.write("Answer all questions, then submit. You can retake quizzes anytime.")

    with st.form(key=f"quiz_form_{lesson.id}"):
        selected_answers = []
        for index, question in enumerate(lesson.quiz, start=1):
            selected = st.selectbox(
                f"{index}. {question.prompt}",
                ["Choose an answer"] + question.options,
                key=f"quiz_{lesson.id}_{index}",
            )
            selected_answers.append(selected)

        submitted = st.form_submit_button("Submit quiz")

    if submitted:
        if any(answer == "Choose an answer" for answer in selected_answers):
            st.warning("Please answer every question before submitting.")
        else:
            score = 0
            details = []
            for selected, question in zip(selected_answers, lesson.quiz):
                is_correct = selected == question.answer
                score += int(is_correct)
                details.append((question, selected, is_correct))

            record_quiz_score(progress_data, lesson.id, score, len(lesson.quiz))
            save_progress(progress_data, progress_path)
            render_score_badge(score, len(lesson.quiz))

            for question, selected, is_correct in details:
                if is_correct:
                    st.success(f"Correct: {question.prompt}")
                else:
                    st.error(f"Missed: {question.prompt}")
                    st.write(f"Your answer: {selected}")
                    st.write(f"Correct answer: {question.answer}")
                st.caption(question.explanation)

    existing_score = progress_data.get("quiz_scores", {}).get(lesson.id)
    if existing_score:
        st.divider()
        st.write(
            f"Last saved score for this lesson: **{existing_score['score']}/{existing_score['total']}** "
            f"({existing_score['percent']}%)."
        )

with code_tab:
    st.header(f"Code Lab: {lesson.title}")
    challenge = lesson.challenge
    st.write(challenge.prompt)
    st.caption("Try for 8-10 focused minutes before opening hints. The goal is practice, not perfection.")

    with st.expander("Hints"):
        for hint in challenge.hints:
            st.write(f"- {hint}")

    user_code = st.text_area(
        "Your code",
        value=challenge.starter_code,
        height=280,
        key=f"code_{lesson.id}",
    )

    with st.expander("View tests"):
        st.code(challenge.tests, language="python")

    runner_on = code_runner_enabled()
    if not runner_on:
        st.info(
            "The code runner is off. To run tests locally, start the app with "
            "ALLOW_CODE_RUNNER=true. Keep it off for public deployments."
        )
    else:
        st.warning(
            "Local runner is enabled. This is for your own machine only, not a secure public sandbox."
        )
        if st.button("Run lesson tests", type="primary"):
            result = run_python_with_tests(user_code, challenge.tests)
            if result.ok:
                st.success("Tests passed.")
            else:
                st.error("Tests failed.")
            if result.stdout:
                st.subheader("Output")
                st.code(result.stdout)
            if result.stderr:
                st.subheader("Errors")
                st.code(result.stderr)

    col_a, col_b = st.columns(2)
    with col_a:
        with st.expander("Show sample solution"):
            st.code(challenge.sample_solution, language="python")
    with col_b:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI for a hint on my code",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            prompt = (
                "Give me one helpful hint for this coding challenge without giving the full solution.\n\n"
                f"Challenge: {challenge.prompt}\n\n"
                f"My code:\n```python\n{user_code}\n```"
            )
            response = call_ai_tutor(
                [{"role": "user", "content": prompt}],
                lesson_title=lesson.title,
                lesson_level=lesson.level,
            )
            st.write(response)
        if not ai_ready:
            st.caption("Connect the AI tutor to get code hints. Until then, use the built-in hints and sample solution.")


with projects_tab:
    st.header("Projects & capstone checkpoints")
    st.write(
        "Projects make the lessons feel real. Each track is broken into tiny checkpoints so you can build without getting overwhelmed."
    )

    project_metric_cols = st.columns(4)
    project_metric_cols[0].metric("Project tracks", len(PROJECTS))
    project_metric_cols[1].metric("Milestones done", completed_project_milestones_count(progress_data))
    project_metric_cols[2].metric("Recommended", next(project.title for project in PROJECTS if project.id == recommended_project_id(progress_data)))
    project_metric_cols[3].metric("Capstone", f"{int(project_completion_percent(progress_data, 'personal_ai_code_tutor') * 100)}%")

    recommended = next(project for project in PROJECTS if project.id == recommended_project_id(progress_data))
    render_card(
        "Recommended project",
        f"{recommended.title}: {recommended.description} Next checkpoint: {next_project_milestone(progress_data, recommended.id).title}.",
        "success-soft",
    )

    project_labels = [f"{project.title} ({project.level})" for project in PROJECTS]
    selected_project_label = st.selectbox("Choose a project track", project_labels)
    selected_project = PROJECTS[project_labels.index(selected_project_label)]
    render_project_summary(selected_project, progress_data)
    st.progress(project_completion_percent(progress_data, selected_project.id))

    st.subheader("Milestones")
    saved_milestones = project_progress(progress_data, selected_project.id)
    for milestone in selected_project.milestones:
        with st.expander(f"{milestone.title} - {saved_milestones.get(milestone.id, {}).get('status', 'Not started')}", expanded=saved_milestones.get(milestone.id, {}).get("status") in {None, "Not started", "In progress"}):
            st.write(milestone.proof)
            current = saved_milestones.get(milestone.id, {})
            status_options = ["Not started", "In progress", "Completed", "Skipped"]
            current_status = current.get("status", "Not started") if current.get("status", "Not started") in status_options else "Not started"
            new_status = st.selectbox(
                "Status",
                status_options,
                index=status_options.index(current_status),
                key=f"project_status_{selected_project.id}_{milestone.id}",
            )
            new_note = st.text_area(
                "Proof note",
                value=current.get("note", ""),
                key=f"project_note_{selected_project.id}_{milestone.id}",
                height=80,
                placeholder="Example: I wrote the score function and tested 3/3 answers.",
            )
            if st.button("Save milestone", key=f"save_project_{selected_project.id}_{milestone.id}"):
                record_project_milestone(progress_data, selected_project.id, milestone.id, new_status, new_note)
                save_progress(progress_data, progress_path)
                st.success("Project milestone saved.")
                st.rerun()

    st.subheader("All project tracks")
    for project in PROJECTS:
        render_project_summary(project, progress_data)

with prompt_tab:
    st.header("Prompt Lab")
    st.write("Practice writing better prompts for coding, learning, debugging, and AI app building.")

    prompt_text = st.text_area(
        "Write or paste a prompt",
        value=improved_prompt_template("Python functions"),
        height=240,
        key="prompt_lab_text",
    )

    score_col, ai_col = st.columns(2)
    with score_col:
        if st.button("Score prompt", type="primary"):
            result = score_prompt(prompt_text)
            record_prompt_score(progress_data, result.score, prompt_text)
            save_progress(progress_data, progress_path)
            st.metric("Prompt score", f"{result.score}/{result.max_score}")
            st.progress(result.score / result.max_score)
            st.write(result.summary)
            for criterion in result.criteria:
                if criterion.passed:
                    st.success(f"{criterion.name}: +{criterion.points} - {criterion.feedback}")
                else:
                    st.warning(f"{criterion.name}: {criterion.feedback}")
    with ai_col:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI to improve this prompt",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            improved = improve_prompt_with_ai(prompt_text, lesson_title=lesson.title)
            st.subheader("AI feedback")
            st.write(improved)
        if not ai_ready:
            st.caption("The built-in rubric works offline. AI rewriting turns on after you add OPENAI_API_KEY.")

    with st.expander("Prompt formula"):
        st.markdown(
            """
Use this formula:

```text
Role: Who should the AI act as?
Task: What exact job should it do?
Context: What does it need to know about you, the code, or the situation?
Constraints: What should it avoid or follow?
Example/Input: What code, error, sample input, or desired output can you provide?
Output format: How should the answer be structured?
Verification: How can the answer be checked?
```
""".strip()
        )

with official_ai_tab:
    st.header("Official AI Learning & Certifications")
    st.write(
        "Use this hub to track official provider lessons, docs, cohorts, and certifications while you learn Python. "
        "The app links out to official pages and saves your status here; it does not copy or republish their course content."
    )
    st.caption(
        "Verify prices, exam requirements, dates, and availability on the official provider page before enrolling or paying."
    )

    stats = official_resource_stats(progress_data)
    counts = provider_counts()
    stat_cols = st.columns(4)
    stat_cols[0].metric("Official resources", stats["total"])
    stat_cols[1].metric("Started", stats["started"])
    stat_cols[2].metric("Completed", stats["completed"])
    stat_cols[3].metric("Cert/certificate options", stats["certificate_options"])

    next_resource = next_recommended_resource(progress_data)
    if next_resource:
        render_card(
            "Recommended next AI step",
            f"{next_resource.provider}: {next_resource.title}. {next_resource.recommended_when}",
        )
        st.markdown(f"[Open recommended official page]({next_resource.url})")
    else:
        render_card(
            "Official AI track complete",
            "All curated official AI resources are marked Completed or Skipped. Add a new target or revisit your notes.",
            "success-soft",
        )

    st.subheader("Best starter path")
    starter_ids = OFFICIAL_AI_STARTER_PATH
    starter_cols = st.columns(3)
    for col, resource in zip(starter_cols, resources_for_ids(starter_ids)):
        with col:
            render_official_resource_summary(resource)
            st.markdown(f"[Open official page]({resource.url})")

    with st.expander("Suggested milestone tracks", expanded=True):
        for milestone in OFFICIAL_AI_MILESTONES:
            st.markdown(
                f"""
<div class="track-card">
    <strong>{milestone['title']}</strong><br>
    <span class="small-muted">{milestone['goal']}</span>
</div>
""".strip(),
                unsafe_allow_html=True,
            )
            for resource in resources_for_ids(milestone["resource_ids"]):
                status = official_resource_status(progress_data, resource.id)
                st.write(f"- **{resource.provider}: {resource.title}** - {status}")

    st.subheader("Browse and track official resources")
    filter_cols = st.columns([1, 1, 1])
    with filter_cols[0]:
        provider_filter = st.selectbox("Provider", ["All"] + list(PROVIDER_ORDER))
    with filter_cols[1]:
        type_filter = st.selectbox("Resource type", ["All"] + list(RESOURCE_TYPES))
    with filter_cols[2]:
        credential_only = st.checkbox("Show cert/certificate options only")

    filtered_resources = []
    for resource in OFFICIAL_AI_RESOURCES:
        if provider_filter != "All" and resource.provider != provider_filter:
            continue
        if type_filter != "All" and resource.resource_type != type_filter:
            continue
        if credential_only and not resource_has_certificate(resource):
            continue
        filtered_resources.append(resource)

    st.caption(f"Showing {len(filtered_resources)} resources. Provider counts: " + ", ".join(
        f"{provider}: {count}" for provider, count in counts.items()
    ))

    for resource in filtered_resources:
        status = official_resource_status(progress_data, resource.id)
        note = official_resource_note(progress_data, resource.id)
        expanded = resource.provider == "Gumloop" or status in {"Queued", "In progress"}
        with st.expander(f"{resource.provider}: {resource.title} ({status})", expanded=expanded):
            render_official_resource_summary(resource)
            st.markdown("**Skills:** " + ", ".join(f"`{tag}`" for tag in resource.tags))
            st.markdown(f"**Why it matters:** {resource.why_it_matters}")
            st.markdown(f"[Open official page]({resource.url})")

            status_index = STATUS_OPTIONS.index(status) if status in STATUS_OPTIONS else 0
            new_status = st.selectbox(
                "Status",
                STATUS_OPTIONS,
                index=status_index,
                key=f"official_status_{resource.id}",
            )
            new_note = st.text_area(
                "Private note for this resource",
                value=note,
                height=90,
                key=f"official_note_{resource.id}",
                placeholder="Example: Finish lessons 1-2 this week, then build one Gumloop workflow.",
            )
            if st.button("Save resource progress", key=f"save_official_{resource.id}"):
                record_official_ai_resource(progress_data, resource.id, new_status, new_note)
                save_progress(progress_data, progress_path)
                st.success("Official AI resource progress saved.")

    with st.expander("Prompt template for course or certificate prep"):
        st.code(
            """Role: You are my AI certification study coach.
Goal: Help me prepare for [provider/resource] while I learn Python.
Context: I am a beginner. I have completed lesson [number] in my Python app.
Official resource: [paste the official lesson/certification link]
Task: Create a 7-day study plan with daily tasks, practice questions, and one mini-project.
Constraints: Do not invent exam rules. Tell me what I must verify on the official page.
Output format: table with Day, Focus, Practice, Proof of Understanding.""",
            language="text",
        )

with ai_tab:
    st.header("AI Tutor")
    st.write("Ask about the current lesson, your code, debugging, project ideas, or prompt quality.")

    ai_ready = ai_is_configured()
    if not ai_ready:
        st.info("AI is optional. Add OPENAI_API_KEY to enable live tutor responses. The chat input is disabled until then.")

    if st.button("Clear chat"):
        st.session_state.ai_messages = []
        st.rerun()

    if "ai_messages" not in st.session_state or not st.session_state.ai_messages:
        st.session_state.ai_messages = [
            {
                "role": "assistant",
                "content": (
                    f"Hi. I can help with {lesson.title}. Ask me for a hint, an explanation, "
                    "a practice question, or help improving a prompt."
                ),
            }
        ]

    for message in st.session_state.ai_messages:
        role = message.get("role", "assistant")
        with st.chat_message(role):
            st.write(message.get("content", ""))

    chat_prompt = st.chat_input("Ask your tutor", disabled=not ai_ready)
    if chat_prompt:
        st.session_state.ai_messages.append({"role": "user", "content": chat_prompt})
        tutor_response = call_ai_tutor(
            st.session_state.ai_messages,
            lesson_title=lesson.title,
            lesson_level=lesson.level,
        )
        st.session_state.ai_messages.append({"role": "assistant", "content": tutor_response})
        st.rerun()

with notes_tab:
    st.header(f"Notes: {lesson.title}")
    current_note = progress_data.get("notes", {}).get(lesson.id, "")
    note_text = st.text_area(
        "Write your own notes, questions, and reflections",
        value=current_note,
        height=320,
        key=f"notes_{lesson.id}",
    )
    if st.button("Save notes"):
        save_note(progress_data, lesson.id, note_text)
        save_progress(progress_data, progress_path)
        st.success("Notes saved.")

with deploy_tab:
    st.header("Make it shareable")
    st.write(
        "This package is set up for Streamlit Community Cloud, Docker-based hosting, and Render-style Python services."
    )

    render_card(
        "Public-safe default",
        "The code runner is off unless ALLOW_CODE_RUNNER=true. Keep it off when other people can use the app.",
        "warning-soft",
    )

    st.subheader("Private GitHub checklist")
    st.markdown(
        "Keep the repository visibility set to **Private** while you are building. "
        "Only deploy or make public after the app has authentication, safer progress storage, and a production code-runner plan."
    )
    st.code(
        """git init
git add .
git commit -m "Initial private AI Code Tutor app"
git branch -M main
git remote add origin git@github.com:YOUR-USERNAME/ai-code-tutor.git
git push -u origin main""",
        language="bash",
    )

    st.subheader("Standalone readiness check")
    st.caption(f"SQLite backup store: `{progress_db_path()}`")
    checks = standalone_checks(app_dir=".", data_dir=progress_path.parent)
    st.caption(standalone_summary(checks))
    for check in checks:
        render_standalone_check(check)

    st.subheader("Deployment checklist")
    st.checkbox("Create the GitHub repository with visibility set to Private", value=False)
    st.checkbox("Add OPENAI_API_KEY as a platform secret, not inside code", value=False)
    st.checkbox("Set ALLOW_CODE_RUNNER=false for public deployments", value=True)
    st.checkbox("Review official AI resource links before sharing publicly", value=True)
    st.checkbox("Run pytest before sharing the link", value=True)
    st.checkbox("Complete the new-user 30-day flow smoke test after big changes", value=True)

    st.subheader("Useful commands")
    st.code(
        """# Local
pip install -r requirements.txt
streamlit run app.py

# Tests
pytest -q

# Docker
docker build -t ai-code-tutor .
docker run -p 8501:8501 --env-file .env ai-code-tutor""",
        language="bash",
    )

    st.subheader("Test on iPhone Simulator through Xcode")
    st.write(
        "Run the Streamlit app locally, open Xcode's iOS Simulator, and load the app in Simulator Safari. "
        "The package also includes a simple SwiftUI WKWebView wrapper in `ios_wrapper/`."
    )
    st.code(
        """streamlit run app.py --server.address 0.0.0.0 --server.port 8501
# Then open http://localhost:8501 in iOS Simulator Safari.""",
        language="bash",
    )
    st.info("See README_DEPLOY.md and XCODE_IOS_TESTING.md for the full step-by-step guides.")

st.divider()
st.caption(
    f"Progress for profile `{profile_name}` is saved at `{progress_path}`. "
    "For a serious multi-user app, replace file storage with a database and add authentication."
)
