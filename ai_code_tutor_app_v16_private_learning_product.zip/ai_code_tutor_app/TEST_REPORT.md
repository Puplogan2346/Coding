# Test Report

## Latest run: v16 private learning product

Commands run from the final working folder:

```text
python -m compileall -q .
python -m pytest -q
```

Result:

```text
117 passed in 3.93s
```

## What is covered

- Curriculum lesson and quiz structure.
- Progress normalization, safe imports, lesson completion, streaks, focus preferences, and pause/resume storage.
- Daily Coding Gym start, stop, resume, completion, proof cards, and mistake cards.
- Preferred workout length and time-based lesson recommendations for 10/30/45 minute sessions.
- Learning path, milestone map, graduation checklist, and standalone readiness checks.
- Private access gate helpers.
- SQLite progress snapshot storage.
- Private backup pack, learning transcript, and certificate preview exports.
- Official AI resource tracker.
- Prompt Lab scoring.
- Optional code runner guardrails.
- App import smoke test with fake Streamlit to catch missing imports/name errors.

## Fresh private-product QA simulation

```text
profile: Private Learner QA
preferred_minutes: 10
time_fit_10: 01-python-mindset / touch today's lesson
time_fit_30: 01-python-mindset / today's plan
time_fit_45: 01-python-mindset / today's full lesson
resume_headline: Resume where you stopped: 1/3 blocks done
resume_pace: 10 min rescue
resume_lesson: 01-python-mindset
resume_proof: I started with print and paused safely.
saved_status: Saved
daily_status: Completed
plan_completion: 0.033
current_milestone: m1-python-start
graduation: Building
xp: 40
level: Level 1 - New Coder
badges: daily_gym
backup_files: README.txt, graduation_certificate.md, learning_transcript.md, progress_backup.json
transcript_has_proof: True
```

## Not run in this environment

- Real Streamlit browser-click session.
- Xcode/iOS Simulator preview.
- Live OpenAI API call.
- Hosted private deployment smoke test.

Those require a local machine or deployed environment. The app includes docs and setup files for each.
