# AI Code Tutor

A deploy-ready Streamlit app for learning Python, improving prompts, and practicing AI-assisted coding.

## What is included

- 12 beginner-to-intermediate Python lessons
- Quizzes with saved scores
- Coding challenges with starter code, hints, tests, and sample solutions
- Prompt Lab with a scoring rubric
- Optional OpenAI-powered AI Tutor
- Learner profiles so multiple people can use separate progress files
- Progress export/import
- Streamlit Community Cloud entrypoint
- Dockerfile and docker-compose setup
- Render-style deployment blueprint
- GitHub Actions test workflow
- Private GitHub setup guide
- New-user journey smoke test and report
- Pytest coverage for curriculum, progress, prompt scoring, and code runner behavior

## Keep private while building

Use a private GitHub repository until the app is fully usable. See `PRIVATE_GITHUB_SETUP.md` for the exact setup commands. The important rule: never commit `.env`, `.streamlit/secrets.toml`, API keys, or learner progress files.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

On Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

## Enable the AI Tutor

The app works without AI. To enable live AI help, set an API key.

Environment variable option:

```bash
export OPENAI_API_KEY="your_api_key_here"
export OPENAI_MODEL="gpt-5.5"
streamlit run app.py
```

Streamlit secrets option:

```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Then edit `.streamlit/secrets.toml` and add your real key.

Never commit `.streamlit/secrets.toml`, `.env`, or any API key.

## Public sharing safety

The included code runner is useful for your own computer, but it is not a secure sandbox for public users.

For public deployment, keep this setting:

```bash
ALLOW_CODE_RUNNER=false
```

To enable local lesson tests only on your own machine:

```bash
ALLOW_CODE_RUNNER=true streamlit run app.py
```

## Run tests

```bash
pytest -q
```

## Run with Docker

```bash
cp .env.example .env
# edit .env if you want AI features

docker build -t ai-code-tutor .
docker run -p 8501:8501 --env-file .env ai-code-tutor
```

Or use Docker Compose:

```bash
docker compose up --build
```

Then open `http://localhost:8501`.

## Project structure

```text
app.py                         Main Streamlit app
streamlit_app.py               Streamlit Community Cloud wrapper
curriculum.py                  Lessons, quizzes, coding challenges
ai_tutor.py                    OpenAI API helper functions
prompt_lab.py                  Prompt scoring rubric
progress.py                    Learner profile and progress storage
code_runner.py                 Optional local code runner
requirements.txt               Runtime and test dependencies
pyproject.toml                 Project metadata and pytest config
Dockerfile                     Container deployment
render.yaml                    Render-style deployment blueprint
docker-compose.yml             Local container workflow
README_DEPLOY.md               Step-by-step sharing/deployment guide
PRIVATE_GITHUB_SETUP.md        Private repo setup and safety checklist
NEW_USER_TEST_REPORT.md        Fresh learner smoke-test notes
.github/workflows/tests.yml    CI tests for GitHub
.streamlit/config.toml         Streamlit runtime config
.streamlit/secrets.toml.example Example secrets file
```

## Suggested next upgrades

1. Replace file-based progress with SQLite, Supabase, Postgres, or Firebase.
2. Add authentication so every learner has a private account.
3. Add spaced repetition review cards.
4. Generate custom quizzes from missed questions.
5. Add a lesson editor for creating new curriculum items.
6. Add a true sandboxed code runner for public deployments.
7. Add analytics for lesson completion and quiz improvement.
