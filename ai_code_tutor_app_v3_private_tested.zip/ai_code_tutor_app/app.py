from __future__ import annotations

import json
import os
from statistics import mean

import streamlit as st

from ai_tutor import ai_is_configured, call_ai_tutor, configured_model, improve_prompt_with_ai
from code_runner import code_runner_enabled, run_python_with_tests
from curriculum import LESSONS, get_lesson_by_id
from progress import (
    completion_percent,
    lessons_remaining,
    load_progress,
    mark_lesson_complete,
    progress_path_for_profile,
    record_prompt_score,
    record_quiz_score,
    save_note,
    save_progress,
)
from prompt_lab import improved_prompt_template, score_prompt


st.set_page_config(
    page_title="AI Code Tutor",
    page_icon="🐍",
    layout="wide",
    initial_sidebar_state="expanded",
)

LESSON_IDS = [lesson.id for lesson in LESSONS]


def apply_theme() -> None:
    st.markdown(
        """
<style>
    .block-container {padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1180px;}
    [data-testid="stSidebar"] {border-right: 1px solid rgba(120, 120, 120, .16);}
    h1, h2, h3 {letter-spacing: -0.025em;}
    .hero {
        padding: 2.1rem 2.2rem;
        border-radius: 28px;
        background: linear-gradient(135deg, rgba(53, 111, 255, .18), rgba(106, 214, 185, .16));
        border: 1px solid rgba(120, 120, 120, .18);
        margin-bottom: 1.25rem;
    }
    .hero h1 {font-size: 3rem; margin: 0 0 .3rem 0;}
    .hero p {font-size: 1.08rem; margin: .2rem 0 0 0; color: rgba(49, 51, 63, .78); max-width: 760px;}
    .card {
        border: 1px solid rgba(120, 120, 120, .18);
        border-radius: 22px;
        padding: 1.05rem 1.15rem;
        background: rgba(255, 255, 255, .72);
        box-shadow: 0 14px 36px rgba(0, 0, 0, .045);
        min-height: 118px;
        margin-bottom: .75rem;
    }
    .card h3 {font-size: 1.05rem; margin: 0 0 .3rem 0;}
    .card p {margin: 0; color: rgba(49, 51, 63, .74);}
    .pill {
        display: inline-block;
        padding: .22rem .58rem;
        border-radius: 999px;
        background: rgba(53, 111, 255, .12);
        border: 1px solid rgba(53, 111, 255, .18);
        font-size: .8rem;
        margin-right: .35rem;
        margin-bottom: .35rem;
    }
    .lesson-row {
        padding: .75rem .85rem;
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 16px;
        margin-bottom: .55rem;
        background: rgba(255, 255, 255, .58);
    }
    .small-muted {font-size: .88rem; color: rgba(49, 51, 63, .66);}
    .success-soft {background: rgba(52, 168, 83, .12); border-color: rgba(52, 168, 83, .25);}
    .warning-soft {background: rgba(251, 188, 5, .13); border-color: rgba(251, 188, 5, .28);}
    .danger-soft {background: rgba(234, 67, 53, .10); border-color: rgba(234, 67, 53, .22);}
    .step-card {
        padding: .95rem 1.05rem;
        border-radius: 18px;
        border: 1px solid rgba(120, 120, 120, .15);
        background: rgba(255, 255, 255, .68);
        margin-bottom: .7rem;
    }
    .step-card strong {font-size: 1rem;}
    .step-card span {display: block; color: rgba(49, 51, 63, .70); margin-top: .2rem;}
    div[data-testid="stMetric"] {
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 18px;
        padding: .8rem .95rem;
        background: rgba(255, 255, 255, .66);
    }
</style>
""".strip(),
        unsafe_allow_html=True,
    )


def first_incomplete_lesson_id(progress_data: dict) -> str:
    completed = set(progress_data.get("completed_lessons", []))
    for lesson_item in LESSONS:
        if lesson_item.id not in completed:
            return lesson_item.id
    return LESSONS[-1].id


def get_quiz_average(progress_data: dict) -> float:
    scores = progress_data.get("quiz_scores", {}).values()
    percentages = [item.get("percent", 0) for item in scores]
    return round(mean(percentages), 1) if percentages else 0.0


def get_best_prompt_score(progress_data: dict) -> int:
    scores = [item.get("score", 0) for item in progress_data.get("prompt_scores", [])]
    return max(scores) if scores else 0


def render_score_badge(score: int, total: int) -> None:
    percent = round((score / total) * 100) if total else 0
    if percent >= 80:
        st.success(f"Score: {score}/{total} ({percent}%). Strong work.")
    elif percent >= 60:
        st.warning(f"Score: {score}/{total} ({percent}%). Review the misses and try again.")
    else:
        st.error(f"Score: {score}/{total} ({percent}%). Revisit the lesson, then retake it.")


def render_card(title: str, body: str, tone: str = "") -> None:
    tone_class = f" {tone}" if tone else ""
    st.markdown(
        f"""
<div class="card{tone_class}">
    <h3>{title}</h3>
    <p>{body}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_status_pills(lesson_level: str, minutes: int, is_complete: bool) -> None:
    status = "Complete" if is_complete else "In progress"
    st.markdown(
        f"""
<span class="pill">{lesson_level}</span>
<span class="pill">{minutes} min</span>
<span class="pill">{status}</span>
""".strip(),
        unsafe_allow_html=True,
    )


def render_step(number: int, title: str, body: str) -> None:
    st.markdown(
        f"""
<div class="step-card">
    <strong>{number}. {title}</strong>
    <span>{body}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def safe_json(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True)


apply_theme()

with st.sidebar:
    st.header("Your learning space")
    profile_name = st.text_input(
        "Learner profile",
        value=st.session_state.get("profile_name", "guest"),
        help="Use a name like your first name or study group name. It creates a separate progress file.",
    ).strip() or "guest"

    if st.session_state.get("active_profile") != profile_name:
        st.session_state.active_profile = profile_name
        st.session_state.profile_name = profile_name
        st.session_state.ai_messages = []
        st.session_state.selected_lesson_id = ""

    st.caption(f"Profile: `{profile_name}`")
    progress_path = progress_path_for_profile(profile_name)
    progress_data = load_progress(LESSON_IDS, progress_path, profile_name=profile_name)

    if (
        not st.session_state.get("selected_lesson_id")
        or st.session_state.selected_lesson_id not in LESSON_IDS
    ):
        st.session_state.selected_lesson_id = first_incomplete_lesson_id(progress_data)

    completed_count = len(progress_data.get("completed_lessons", []))
    completion = completion_percent(progress_data, len(LESSONS))

    st.subheader("Progress")
    st.progress(completion)
    st.write(f"{completed_count} of {len(LESSONS)} lessons complete")

    labels = [f"{index + 1}. {lesson_item.title}" for index, lesson_item in enumerate(LESSONS)]
    label_by_id = {lesson_item.id: labels[index] for index, lesson_item in enumerate(LESSONS)}
    id_by_label = {label: lesson_item.id for label, lesson_item in zip(labels, LESSONS)}
    current_label = label_by_id.get(st.session_state.selected_lesson_id, labels[0])

    selected_label = st.selectbox(
        "Choose a lesson",
        labels,
        index=labels.index(current_label),
    )
    st.session_state.selected_lesson_id = id_by_label[selected_label]

    st.divider()
    st.subheader("Study mode")
    st.radio(
        "Session focus",
        ["Learn", "Practice", "Review", "Build"],
        horizontal=True,
        key="study_focus",
        help="This only guides the dashboard recommendations for now.",
    )

    st.divider()
    st.subheader("AI status")
    if ai_is_configured():
        st.success(f"Connected: {configured_model()}")
    else:
        st.warning("Not connected yet")
        st.caption("Set OPENAI_API_KEY to enable the AI tutor.")

    st.subheader("Code runner")
    if code_runner_enabled():
        st.warning("Enabled for local use")
    else:
        st.info("Off for safe sharing")
        st.caption("Keep ALLOW_CODE_RUNNER=false on public deployments.")

    st.divider()
    with st.expander("Progress tools"):
        st.download_button(
            "Download my progress",
            data=safe_json(progress_data),
            file_name=f"ai_code_tutor_progress_{profile_name}.json",
            mime="application/json",
        )
        uploaded_progress = st.file_uploader("Import progress JSON", type=["json"])
        if uploaded_progress is not None and st.button("Import progress"):
            try:
                imported = json.loads(uploaded_progress.getvalue().decode("utf-8"))
                imported["profile_name"] = profile_name
                save_progress(imported, progress_path)
                st.success("Progress imported.")
                st.rerun()
            except (UnicodeDecodeError, json.JSONDecodeError):
                st.error("That file was not valid JSON.")

        confirm_reset = st.checkbox("I understand this deletes this profile's progress")
        if confirm_reset and st.button("Reset this profile"):
            if progress_path.exists():
                progress_path.unlink()
            st.session_state.ai_messages = []
            st.rerun()

lesson = get_lesson_by_id(st.session_state.selected_lesson_id)
completed_lessons = set(progress_data.get("completed_lessons", []))
lesson_complete = lesson.id in completed_lessons
next_lesson = get_lesson_by_id(first_incomplete_lesson_id(progress_data))

st.markdown(
    f"""
<div class="hero">
    <h1>AI Code Tutor</h1>
    <p>Learn Python step by step, practice with tests, build better prompts, and use an AI tutor when you are ready.</p>
</div>
""".strip(),
    unsafe_allow_html=True,
)

feature_cols = st.columns(4)
with feature_cols[0]:
    render_card("Guided path", "12 lessons from absolute beginner to intermediate projects.")
with feature_cols[1]:
    render_card("Practice loops", "Quizzes, coding challenges, hints, tests, and notes.")
with feature_cols[2]:
    render_card("Prompt Lab", "Score prompts with a rubric and rewrite them for stronger AI results.")
with feature_cols[3]:
    render_card("Private-ready", "GitHub-private workflow, Docker, CI tests, secrets examples, and safe sharing defaults.")

(
    dashboard_tab,
    lesson_tab,
    quiz_tab,
    code_tab,
    prompt_tab,
    ai_tab,
    notes_tab,
    deploy_tab,
) = st.tabs(["Dashboard", "Learn", "Quiz", "Code Lab", "Prompt Lab", "AI Tutor", "Notes", "Deploy"])

with dashboard_tab:
    if completed_count == 0:
        st.success("Welcome. This profile is brand new, so start with Lesson 1 and use the checklist below.")

    with st.expander("Start here: your first 10 minutes", expanded=completed_count == 0):
        intro_cols = st.columns(4)
        with intro_cols[0]:
            render_step(1, "Read", "Open the Learn tab and read the current lesson once without memorizing.")
        with intro_cols[1]:
            render_step(2, "Check", "Take the quiz. Misses are useful because they tell you what to review.")
        with intro_cols[2]:
            render_step(3, "Practice", "Try Code Lab from the starter code before viewing the sample solution.")
        with intro_cols[3]:
            render_step(4, "Prompt", "Use Prompt Lab to ask for help with context, constraints, and verification.")

    metric_cols = st.columns(4)
    metric_cols[0].metric("Lessons complete", f"{completed_count}/{len(LESSONS)}")
    metric_cols[1].metric("Lessons left", lessons_remaining(progress_data, len(LESSONS)))
    metric_cols[2].metric("Quiz average", f"{get_quiz_average(progress_data)}%")
    metric_cols[3].metric("Best prompt score", f"{get_best_prompt_score(progress_data)}/10")

    left, right = st.columns([1.25, 1])
    with left:
        st.subheader("Recommended next step")
        render_card(
            next_lesson.title,
            f"Estimated time: {next_lesson.time_minutes} minutes. Focus: {st.session_state.get('study_focus', 'Learn')}.",
            "success-soft" if next_lesson.id == lesson.id else "",
        )
        if st.button("Jump to recommended lesson", type="primary"):
            st.session_state.selected_lesson_id = next_lesson.id
            st.rerun()

        st.subheader("Curriculum map")
        for index, item in enumerate(LESSONS, start=1):
            status = "✅ Complete" if item.id in completed_lessons else "⬜ Not complete"
            score = progress_data.get("quiz_scores", {}).get(item.id)
            score_text = f"Quiz: {score['percent']}%" if score else "Quiz: not taken"
            st.markdown(
                f"""
<div class="lesson-row">
    <strong>{index}. {item.title}</strong><br>
    <span class="small-muted">{item.level} · {item.time_minutes} min · {status} · {score_text}</span>
</div>
""".strip(),
                unsafe_allow_html=True,
            )

    with right:
        st.subheader("How to use this app")
        st.markdown(
            """
1. Read the lesson and mark it complete.
2. Take the quiz until you can explain every answer.
3. Try the Code Lab challenge before opening the solution.
4. Use Prompt Lab to practice asking AI for better help.
5. Ask the AI Tutor for hints, not just answers.
""".strip()
        )
        st.info("While the GitHub repo is private, you can still run tests through GitHub Actions. Do not add API keys to code files.")

with lesson_tab:
    st.header(lesson.title)
    render_status_pills(lesson.level, lesson.time_minutes, lesson_complete)

    st.subheader("Objectives")
    for objective in lesson.objectives:
        st.write(f"- {objective}")

    st.subheader("Lesson")
    st.markdown(lesson.explanation)

    st.subheader("Key terms")
    st.write(" ".join(f"`{term}`" for term in lesson.key_terms))

    st.info(f"Prompt skill: {lesson.prompt_skill}")

    action_cols = st.columns([1, 1.2])
    with action_cols[0]:
        if lesson_complete:
            st.success("You marked this lesson complete.")
        elif st.button("Mark lesson complete", type="primary"):
            mark_lesson_complete(progress_data, lesson.id)
            save_progress(progress_data, progress_path)
            st.success("Lesson marked complete.")
            st.rerun()
    with action_cols[1]:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI to explain this lesson in simpler words",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            prompt = (
                f"Explain the lesson '{lesson.title}' in beginner-friendly language. "
                "Use a tiny Python example and one check-in question."
            )
            st.write(call_ai_tutor([{"role": "user", "content": prompt}], lesson.title, lesson.level))
        if not ai_ready:
            st.caption("AI buttons are disabled until OPENAI_API_KEY is configured. The rest of the app works without AI.")

with quiz_tab:
    st.header(f"Quiz: {lesson.title}")
    st.write("Answer all questions, then submit. You can retake quizzes anytime.")

    with st.form(key=f"quiz_form_{lesson.id}"):
        selected_answers = []
        for index, question in enumerate(lesson.quiz, start=1):
            selected = st.selectbox(
                f"{index}. {question.prompt}",
                ["Choose an answer"] + question.options,
                key=f"quiz_{lesson.id}_{index}",
            )
            selected_answers.append(selected)

        submitted = st.form_submit_button("Submit quiz")

    if submitted:
        if any(answer == "Choose an answer" for answer in selected_answers):
            st.warning("Please answer every question before submitting.")
        else:
            score = 0
            details = []
            for selected, question in zip(selected_answers, lesson.quiz):
                is_correct = selected == question.answer
                score += int(is_correct)
                details.append((question, selected, is_correct))

            record_quiz_score(progress_data, lesson.id, score, len(lesson.quiz))
            save_progress(progress_data, progress_path)
            render_score_badge(score, len(lesson.quiz))

            for question, selected, is_correct in details:
                if is_correct:
                    st.success(f"Correct: {question.prompt}")
                else:
                    st.error(f"Missed: {question.prompt}")
                    st.write(f"Your answer: {selected}")
                    st.write(f"Correct answer: {question.answer}")
                st.caption(question.explanation)

    existing_score = progress_data.get("quiz_scores", {}).get(lesson.id)
    if existing_score:
        st.divider()
        st.write(
            f"Last saved score for this lesson: **{existing_score['score']}/{existing_score['total']}** "
            f"({existing_score['percent']}%)."
        )

with code_tab:
    st.header(f"Code Lab: {lesson.title}")
    challenge = lesson.challenge
    st.write(challenge.prompt)

    with st.expander("Hints"):
        for hint in challenge.hints:
            st.write(f"- {hint}")

    user_code = st.text_area(
        "Your code",
        value=challenge.starter_code,
        height=280,
        key=f"code_{lesson.id}",
    )

    with st.expander("View tests"):
        st.code(challenge.tests, language="python")

    runner_on = code_runner_enabled()
    if not runner_on:
        st.info(
            "The code runner is off. To run tests locally, start the app with "
            "ALLOW_CODE_RUNNER=true. Keep it off for public deployments."
        )
    else:
        st.warning(
            "Local runner is enabled. This is for your own machine only, not a secure public sandbox."
        )
        if st.button("Run lesson tests", type="primary"):
            result = run_python_with_tests(user_code, challenge.tests)
            if result.ok:
                st.success("Tests passed.")
            else:
                st.error("Tests failed.")
            if result.stdout:
                st.subheader("Output")
                st.code(result.stdout)
            if result.stderr:
                st.subheader("Errors")
                st.code(result.stderr)

    col_a, col_b = st.columns(2)
    with col_a:
        with st.expander("Show sample solution"):
            st.code(challenge.sample_solution, language="python")
    with col_b:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI for a hint on my code",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            prompt = (
                "Give me one helpful hint for this coding challenge without giving the full solution.\n\n"
                f"Challenge: {challenge.prompt}\n\n"
                f"My code:\n```python\n{user_code}\n```"
            )
            response = call_ai_tutor(
                [{"role": "user", "content": prompt}],
                lesson_title=lesson.title,
                lesson_level=lesson.level,
            )
            st.write(response)
        if not ai_ready:
            st.caption("Connect the AI tutor to get code hints. Until then, use the built-in hints and sample solution.")

with prompt_tab:
    st.header("Prompt Lab")
    st.write("Practice writing better prompts for coding, learning, debugging, and AI app building.")

    prompt_text = st.text_area(
        "Write or paste a prompt",
        value=improved_prompt_template("Python functions"),
        height=240,
        key="prompt_lab_text",
    )

    score_col, ai_col = st.columns(2)
    with score_col:
        if st.button("Score prompt", type="primary"):
            result = score_prompt(prompt_text)
            record_prompt_score(progress_data, result.score, prompt_text)
            save_progress(progress_data, progress_path)
            st.metric("Prompt score", f"{result.score}/{result.max_score}")
            st.progress(result.score / result.max_score)
            st.write(result.summary)
            for criterion in result.criteria:
                if criterion.passed:
                    st.success(f"{criterion.name}: +{criterion.points} - {criterion.feedback}")
                else:
                    st.warning(f"{criterion.name}: {criterion.feedback}")
    with ai_col:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI to improve this prompt",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            improved = improve_prompt_with_ai(prompt_text, lesson_title=lesson.title)
            st.subheader("AI feedback")
            st.write(improved)
        if not ai_ready:
            st.caption("The built-in rubric works offline. AI rewriting turns on after you add OPENAI_API_KEY.")

    with st.expander("Prompt formula"):
        st.markdown(
            """
Use this formula:

```text
Role: Who should the AI act as?
Task: What exact job should it do?
Context: What does it need to know about you, the code, or the situation?
Constraints: What should it avoid or follow?
Example/Input: What code, error, sample input, or desired output can you provide?
Output format: How should the answer be structured?
Verification: How can the answer be checked?
```
""".strip()
        )

with ai_tab:
    st.header("AI Tutor")
    st.write("Ask about the current lesson, your code, debugging, project ideas, or prompt quality.")

    ai_ready = ai_is_configured()
    if not ai_ready:
        st.info("AI is optional. Add OPENAI_API_KEY to enable live tutor responses. The chat input is disabled until then.")

    if st.button("Clear chat"):
        st.session_state.ai_messages = []
        st.rerun()

    if "ai_messages" not in st.session_state or not st.session_state.ai_messages:
        st.session_state.ai_messages = [
            {
                "role": "assistant",
                "content": (
                    f"Hi. I can help with {lesson.title}. Ask me for a hint, an explanation, "
                    "a practice question, or help improving a prompt."
                ),
            }
        ]

    for message in st.session_state.ai_messages:
        role = message.get("role", "assistant")
        with st.chat_message(role):
            st.write(message.get("content", ""))

    chat_prompt = st.chat_input("Ask your tutor", disabled=not ai_ready)
    if chat_prompt:
        st.session_state.ai_messages.append({"role": "user", "content": chat_prompt})
        tutor_response = call_ai_tutor(
            st.session_state.ai_messages,
            lesson_title=lesson.title,
            lesson_level=lesson.level,
        )
        st.session_state.ai_messages.append({"role": "assistant", "content": tutor_response})
        st.rerun()

with notes_tab:
    st.header(f"Notes: {lesson.title}")
    current_note = progress_data.get("notes", {}).get(lesson.id, "")
    note_text = st.text_area(
        "Write your own notes, questions, and reflections",
        value=current_note,
        height=320,
        key=f"notes_{lesson.id}",
    )
    if st.button("Save notes"):
        save_note(progress_data, lesson.id, note_text)
        save_progress(progress_data, progress_path)
        st.success("Notes saved.")

with deploy_tab:
    st.header("Make it shareable")
    st.write(
        "This package is set up for Streamlit Community Cloud, Docker-based hosting, and Render-style Python services."
    )

    render_card(
        "Public-safe default",
        "The code runner is off unless ALLOW_CODE_RUNNER=true. Keep it off when other people can use the app.",
        "warning-soft",
    )

    st.subheader("Private GitHub checklist")
    st.markdown(
        "Keep the repository visibility set to **Private** while you are building. "
        "Only deploy or make public after the app has authentication, safer progress storage, and a production code-runner plan."
    )
    st.code(
        """git init
git add .
git commit -m "Initial private AI Code Tutor app"
git branch -M main
git remote add origin git@github.com:YOUR-USERNAME/ai-code-tutor.git
git push -u origin main""",
        language="bash",
    )

    st.subheader("Deployment checklist")
    st.checkbox("Create the GitHub repository with visibility set to Private", value=False)
    st.checkbox("Add OPENAI_API_KEY as a platform secret, not inside code", value=False)
    st.checkbox("Set ALLOW_CODE_RUNNER=false for public deployments", value=True)
    st.checkbox("Run pytest before sharing the link", value=True)

    st.subheader("Useful commands")
    st.code(
        """# Local
pip install -r requirements.txt
streamlit run app.py

# Tests
pytest -q

# Docker
docker build -t ai-code-tutor .
docker run -p 8501:8501 --env-file .env ai-code-tutor""",
        language="bash",
    )

    st.info("See README_DEPLOY.md for the full step-by-step deployment guide.")

st.divider()
st.caption(
    f"Progress for profile `{profile_name}` is saved at `{progress_path}`. "
    "For a serious multi-user app, replace file storage with a database and add authentication."
)
