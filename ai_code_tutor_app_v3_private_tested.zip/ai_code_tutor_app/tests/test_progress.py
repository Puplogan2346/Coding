import json

from progress import (
    completion_percent,
    default_progress,
    load_progress,
    mark_lesson_complete,
    profile_slug,
    progress_path_for_profile,
    record_prompt_score,
    record_quiz_score,
    save_note,
    save_progress,
)


def test_profile_slug_is_safe():
    assert profile_slug("Ava Learns Python!") == "ava-learns-python"
    assert profile_slug("   ") == "guest"
    assert profile_slug("x" * 100) == "x" * 48


def test_progress_path_uses_safe_slug():
    path = progress_path_for_profile("Ava Learns Python!")
    assert path.name == "progress_ava-learns-python.json"


def test_default_progress_includes_notes_for_lessons():
    data = default_progress(["one", "two"], profile_name="Ava")
    assert data["profile_name"] == "Ava"
    assert data["notes"] == {"one": "", "two": ""}


def test_progress_save_and_load_roundtrip(tmp_path):
    path = tmp_path / "progress.json"
    data = default_progress(["one", "two"], profile_name="Ava")
    mark_lesson_complete(data, "one")
    record_quiz_score(data, "one", score=2, total=3)
    save_note(data, "one", "Remember f-strings")
    record_prompt_score(data, 8, "Please explain Python lists with examples and tests.")
    save_progress(data, path)

    loaded = load_progress(["one", "two"], path, profile_name="Ava")
    assert loaded["completed_lessons"] == ["one"]
    assert loaded["quiz_scores"]["one"]["percent"] == 66.7
    assert loaded["notes"]["one"] == "Remember f-strings"
    assert loaded["prompt_scores"][0]["score"] == 8
    assert completion_percent(loaded, 2) == 0.5


def test_load_progress_migrates_lesson_ids(tmp_path):
    path = tmp_path / "progress.json"
    path.write_text(
        json.dumps(
            {
                "completed_lessons": ["old", "new"],
                "quiz_scores": {"old": {"percent": 100}, "new": {"percent": 90}},
                "notes": {"old": "remove"},
            }
        ),
        encoding="utf-8",
    )
    loaded = load_progress(["new"], path, profile_name="Ava")
    assert loaded["completed_lessons"] == ["new"]
    assert list(loaded["quiz_scores"].keys()) == ["new"]
    assert "new" in loaded["notes"]
