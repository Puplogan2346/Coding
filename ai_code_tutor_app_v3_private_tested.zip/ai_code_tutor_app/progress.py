from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable

DATA_DIR = Path(os.getenv("APP_DATA_DIR", "data"))
PROGRESS_FILE = DATA_DIR / "progress_guest.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def profile_slug(profile_name: str | None) -> str:
    """Return a filesystem-safe learner profile slug."""
    cleaned = (profile_name or "guest").strip().lower()
    cleaned = re.sub(r"[^a-z0-9_-]+", "-", cleaned)
    cleaned = cleaned.strip("-_")
    return cleaned[:48] or "guest"


def progress_path_for_profile(profile_name: str | None) -> Path:
    return DATA_DIR / f"progress_{profile_slug(profile_name)}.json"


def default_progress(lesson_ids: Iterable[str], profile_name: str = "guest") -> Dict[str, Any]:
    lesson_ids = list(lesson_ids)
    return {
        "created_at": _now(),
        "updated_at": _now(),
        "profile_name": profile_name or "guest",
        "completed_lessons": [],
        "quiz_scores": {},
        "notes": {lesson_id: "" for lesson_id in lesson_ids},
        "prompt_scores": [],
        "study_streak": 0,
        "last_session_date": "",
    }


def load_progress(
    lesson_ids: Iterable[str],
    path: Path = PROGRESS_FILE,
    profile_name: str = "guest",
) -> Dict[str, Any]:
    lesson_ids = list(lesson_ids)
    if not path.exists():
        return default_progress(lesson_ids, profile_name=profile_name)

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default_progress(lesson_ids, profile_name=profile_name)

    base = default_progress(lesson_ids, profile_name=profile_name)
    base.update(data)
    base["profile_name"] = profile_name or base.get("profile_name", "guest")

    # Keep progress compatible when lessons are added, removed, or renamed.
    valid_ids = set(lesson_ids)
    base["completed_lessons"] = [
        lesson_id for lesson_id in base.get("completed_lessons", []) if lesson_id in valid_ids
    ]

    base.setdefault("notes", {})
    for lesson_id in lesson_ids:
        base["notes"].setdefault(lesson_id, "")

    base["quiz_scores"] = {
        lesson_id: score
        for lesson_id, score in base.get("quiz_scores", {}).items()
        if lesson_id in valid_ids
    }
    base.setdefault("prompt_scores", [])
    base.setdefault("study_streak", 0)
    base.setdefault("last_session_date", "")
    return base


def save_progress(data: Dict[str, Any], path: Path = PROGRESS_FILE) -> None:
    data["updated_at"] = _now()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def mark_lesson_complete(data: Dict[str, Any], lesson_id: str) -> None:
    completed = data.setdefault("completed_lessons", [])
    if lesson_id not in completed:
        completed.append(lesson_id)


def record_quiz_score(data: Dict[str, Any], lesson_id: str, score: int, total: int) -> None:
    data.setdefault("quiz_scores", {})[lesson_id] = {
        "score": score,
        "total": total,
        "percent": round((score / total) * 100, 1) if total else 0,
        "taken_at": _now(),
    }


def save_note(data: Dict[str, Any], lesson_id: str, note: str) -> None:
    data.setdefault("notes", {})[lesson_id] = note


def record_prompt_score(data: Dict[str, Any], score: int, prompt: str) -> None:
    data.setdefault("prompt_scores", []).append(
        {
            "score": score,
            "prompt_preview": prompt[:160],
            "created_at": _now(),
        }
    )


def completion_percent(data: Dict[str, Any], total_lessons: int) -> float:
    if total_lessons <= 0:
        return 0.0
    return round(len(data.get("completed_lessons", [])) / total_lessons, 3)


def lessons_remaining(data: Dict[str, Any], total_lessons: int) -> int:
    return max(total_lessons - len(data.get("completed_lessons", [])), 0)
