# Test Report

Date: 2026-05-28

## Automated tests

Command:

```bash
python -m pytest -q
```

Result:

```text
16 passed in 1.97s
```

Coverage areas:

- Curriculum structure and lesson IDs
- Quiz answer validity
- All sample coding challenge solutions against their tests
- Progress save/load roundtrip
- Progress migration when lesson IDs change
- Learner profile slug safety
- Prompt scoring rubric behavior
- Code runner success, failure, and timeout behavior
- AI tutor message sanitization
- Brand-new learner first-use journey

## Compile check

Command:

```bash
python -m compileall .
```

Result: completed successfully.

## New-user smoke test

A fresh profile called `New User Smoke Test` was simulated from zero progress through the first lesson loop.

Result:

```text
initial completion: 0.0
initial lessons remaining: 12
notes created: 12
first lesson: Python mindset: commands, output, and mistakes
completion after one lesson: 0.083
lessons remaining after one lesson: 11
quiz percent: 100.0
code lab sample solution passed: true
prompt score: 10/10
```

## Manual app launch note

A live Streamlit server smoke test was attempted in this container, but the container did not have `streamlit` installed and package installation could not reach PyPI from this environment. The app code was still syntax-compiled, and the logic that powers the new-user flow was tested directly. In a normal local or GitHub Actions environment, `pip install -r requirements.txt` will install Streamlit before running or deploying the app.
