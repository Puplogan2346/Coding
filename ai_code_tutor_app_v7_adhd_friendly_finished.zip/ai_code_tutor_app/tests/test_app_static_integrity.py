import ast
from pathlib import Path


APP_PATH = Path(__file__).resolve().parents[1] / "app.py"


def _imported_names_from(module_name: str) -> list[str]:
    tree = ast.parse(APP_PATH.read_text(encoding="utf-8"))
    names: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == module_name:
            for alias in node.names:
                names.append(alias.asname or alias.name)
    return names


def test_official_ai_app_dependencies_are_imported_once():
    names = _imported_names_from("official_ai_resources")
    assert "provider_counts" in names
    assert "resource_has_certificate" in names
    assert "OFFICIAL_AI_STARTER_PATH" in names
    assert len(names) == len(set(names)), "Duplicate official_ai_resources imports create noisy maintenance risk."


def test_progress_imports_do_not_duplicate_names():
    names = _imported_names_from("progress")
    assert len(names) == len(set(names)), "Duplicate progress imports should be cleaned up."


def test_app_uses_shared_starter_path_constant():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "starter_ids = OFFICIAL_AI_STARTER_PATH" in source
    assert '("gumloop_ai_fundamentals", "gumloop_getting_started", "anthropic_academy")' not in source


def test_app_exposes_today_tab_and_daily_training_imports():
    source = APP_PATH.read_text(encoding="utf-8")
    assert '"Today", "Focus Coach", "Dashboard", "Learn"' in source
    assert "record_daily_mission" in _imported_names_from("progress")
    assert "completed_daily_missions_count" in _imported_names_from("progress")
    assert "from study_plan import DAILY_PLAN" in source
    assert "render_daily_mission_card" in source
    assert "render_focus_blocks" in source
    assert "with projects_tab:" in source


def test_app_mentions_30_minute_daily_habit():
    source = APP_PATH.read_text(encoding="utf-8")
    assert "30-minute coding session" in source
    assert "30-minute mission" in source
    assert "Badge shelf" in source
    assert "ADHD-friendly setup" in source
    assert "Projects & capstone checkpoints" in source


def test_app_imports_focus_and_project_dependencies():
    focus_names = _imported_names_from("focus_coach")
    project_names = _imported_names_from("projects")
    progress_names = _imported_names_from("progress")

    assert "focus_blocks" in focus_names
    assert "recommended_focus_mode" in focus_names
    assert "PROJECTS" in project_names
    assert "recommended_project_id" in project_names
    assert "record_focus_checkin" in progress_names
    assert "record_project_milestone" in progress_names
    assert "add_parking_lot_item" in progress_names
