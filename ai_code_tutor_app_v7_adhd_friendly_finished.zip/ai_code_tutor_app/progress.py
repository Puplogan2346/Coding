from __future__ import annotations

import json
import os
import re
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable

DATA_DIR = Path(os.getenv("APP_DATA_DIR", "data"))
PROGRESS_FILE = DATA_DIR / "progress_guest.json"

DEFAULT_FOCUS_PREFERENCES: dict[str, Any] = {
    "default_minutes": 30,
    "adhd_friendly_mode": True,
    "low_stimulation_mode": False,
    "break_reminders": True,
    "reward_style": "Tiny wins",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def profile_slug(profile_name: str | None) -> str:
    """Return a filesystem-safe learner profile slug."""
    cleaned = (profile_name or "guest").strip().lower()
    cleaned = re.sub(r"[^a-z0-9_-]+", "-", cleaned)
    cleaned = cleaned.strip("-_")
    return cleaned[:48] or "guest"


def progress_path_for_profile(profile_name: str | None) -> Path:
    return DATA_DIR / f"progress_{profile_slug(profile_name)}.json"


def default_progress(lesson_ids: Iterable[str], profile_name: str = "guest") -> Dict[str, Any]:
    lesson_ids = list(lesson_ids)
    return {
        "created_at": _now(),
        "updated_at": _now(),
        "profile_name": profile_name or "guest",
        "completed_lessons": [],
        "quiz_scores": {},
        "notes": {lesson_id: "" for lesson_id in lesson_ids},
        "prompt_scores": [],
        "official_ai_status": {},
        "official_ai_notes": {},
        "daily_missions": {},
        "daily_reflections": [],
        "lesson_completed_at": {},
        "study_streak": 0,
        "longest_streak": 0,
        "last_session_date": "",
        "focus_preferences": dict(DEFAULT_FOCUS_PREFERENCES),
        "focus_checkins": [],
        "parking_lot": [],
        "project_milestones": {},
    }


def load_progress(
    lesson_ids: Iterable[str],
    path: Path = PROGRESS_FILE,
    profile_name: str = "guest",
) -> Dict[str, Any]:
    lesson_ids = list(lesson_ids)
    if not path.exists():
        return default_progress(lesson_ids, profile_name=profile_name)

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default_progress(lesson_ids, profile_name=profile_name)

    base = default_progress(lesson_ids, profile_name=profile_name)
    base.update(data)
    base["profile_name"] = profile_name or base.get("profile_name", "guest")

    # Keep progress compatible when lessons are added, removed, or renamed.
    valid_ids = set(lesson_ids)
    base["completed_lessons"] = [
        lesson_id for lesson_id in base.get("completed_lessons", []) if lesson_id in valid_ids
    ]

    base.setdefault("notes", {})
    for lesson_id in lesson_ids:
        base["notes"].setdefault(lesson_id, "")

    base["quiz_scores"] = {
        lesson_id: score
        for lesson_id, score in base.get("quiz_scores", {}).items()
        if lesson_id in valid_ids
    }
    base.setdefault("prompt_scores", [])
    base.setdefault("official_ai_status", {})
    base.setdefault("official_ai_notes", {})
    base.setdefault("daily_missions", {})
    base.setdefault("daily_reflections", [])
    base.setdefault("lesson_completed_at", {})
    base["lesson_completed_at"] = {
        lesson_id: completed_at
        for lesson_id, completed_at in base.get("lesson_completed_at", {}).items()
        if lesson_id in valid_ids
    }
    base.setdefault("study_streak", 0)
    base.setdefault("longest_streak", max(int(base.get("study_streak", 0) or 0), 0))
    base.setdefault("last_session_date", "")

    preferences = dict(DEFAULT_FOCUS_PREFERENCES)
    preferences.update(base.get("focus_preferences", {}) or {})
    base["focus_preferences"] = preferences
    base.setdefault("focus_checkins", [])
    base.setdefault("parking_lot", [])
    base.setdefault("project_milestones", {})
    return base


def save_progress(data: Dict[str, Any], path: Path = PROGRESS_FILE) -> None:
    data["updated_at"] = _now()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def mark_lesson_complete(data: Dict[str, Any], lesson_id: str) -> None:
    completed = data.setdefault("completed_lessons", [])
    if lesson_id not in completed:
        completed.append(lesson_id)
    data.setdefault("lesson_completed_at", {}).setdefault(lesson_id, _now())


def record_quiz_score(data: Dict[str, Any], lesson_id: str, score: int, total: int) -> None:
    data.setdefault("quiz_scores", {})[lesson_id] = {
        "score": score,
        "total": total,
        "percent": round((score / total) * 100, 1) if total else 0,
        "taken_at": _now(),
    }


def save_note(data: Dict[str, Any], lesson_id: str, note: str) -> None:
    data.setdefault("notes", {})[lesson_id] = note


def record_prompt_score(data: Dict[str, Any], score: int, prompt: str) -> None:
    data.setdefault("prompt_scores", []).append(
        {
            "score": score,
            "prompt_preview": prompt[:160],
            "created_at": _now(),
        }
    )


def record_official_ai_resource(
    data: Dict[str, Any],
    resource_id: str,
    status: str,
    note: str = "",
) -> None:
    """Track progress on an external official AI learning resource."""
    allowed_statuses = {"Not started", "Queued", "In progress", "Completed", "Skipped"}
    clean_status = status if status in allowed_statuses else "Not started"
    data.setdefault("official_ai_status", {})[resource_id] = clean_status
    data.setdefault("official_ai_notes", {})[resource_id] = note


def official_ai_completed_count(data: Dict[str, Any]) -> int:
    statuses = data.get("official_ai_status", {}) or {}
    return sum(1 for status in statuses.values() if status == "Completed")


def completion_percent(data: Dict[str, Any], total_lessons: int) -> float:
    if total_lessons <= 0:
        return 0.0
    return round(len(data.get("completed_lessons", [])) / total_lessons, 3)


def lessons_remaining(data: Dict[str, Any], total_lessons: int) -> int:
    return max(total_lessons - len(data.get("completed_lessons", [])), 0)


def _parse_date(value: str) -> date | None:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def update_study_streak(data: Dict[str, Any], session_date: date | None = None) -> None:
    """Update a simple daily streak counter. Multiple sessions on the same day are idempotent."""
    today = session_date or datetime.now(timezone.utc).date()
    today_text = today.isoformat()
    previous = _parse_date(str(data.get("last_session_date", "")))

    if previous == today:
        data.setdefault("study_streak", 1)
    elif previous == today - timedelta(days=1):
        data["study_streak"] = int(data.get("study_streak", 0) or 0) + 1
    else:
        data["study_streak"] = 1

    data["last_session_date"] = today_text
    data["longest_streak"] = max(
        int(data.get("longest_streak", 0) or 0),
        int(data.get("study_streak", 0) or 0),
    )


def record_daily_mission(
    data: Dict[str, Any],
    day: int,
    status: str = "Completed",
    mood: str = "Good",
    reflection: str = "",
    session_date: date | None = None,
) -> None:
    """Save progress for a 30-minute daily mission."""
    allowed_statuses = {"Not started", "In progress", "Completed", "Skipped"}
    clean_status = status if status in allowed_statuses else "Completed"
    day_key = str(day)
    data.setdefault("daily_missions", {})[day_key] = {
        "day": day,
        "status": clean_status,
        "mood": mood,
        "reflection": reflection,
        "updated_at": _now(),
    }
    data.setdefault("daily_reflections", []).append(
        {
            "day": day,
            "status": clean_status,
            "mood": mood,
            "reflection": reflection[:500],
            "created_at": _now(),
        }
    )
    if clean_status == "Completed":
        update_study_streak(data, session_date=session_date)


def completed_daily_missions_count(data: Dict[str, Any]) -> int:
    return sum(
        1
        for item in (data.get("daily_missions", {}) or {}).values()
        if item.get("status") == "Completed"
    )


def save_focus_preferences(data: Dict[str, Any], preferences: Dict[str, Any]) -> None:
    """Save learner focus preferences without losing new default keys."""
    clean = dict(DEFAULT_FOCUS_PREFERENCES)
    clean.update(data.get("focus_preferences", {}) or {})
    for key in DEFAULT_FOCUS_PREFERENCES:
        if key in preferences:
            clean[key] = preferences[key]
    data["focus_preferences"] = clean


def record_focus_checkin(
    data: Dict[str, Any],
    energy: str,
    focus_level: str,
    blockers: str = "",
    win: str = "",
    session_date: date | None = None,
) -> None:
    checkin_date = (session_date or datetime.now(timezone.utc).date()).isoformat()
    data.setdefault("focus_checkins", []).append(
        {
            "energy": energy,
            "focus_level": focus_level,
            "blockers": blockers[:500],
            "win": win[:500],
            "date": checkin_date,
            "created_at": _now(),
        }
    )


def add_parking_lot_item(
    data: Dict[str, Any],
    thought: str,
    lesson_id: str = "",
    source: str = "Today",
) -> bool:
    clean = thought.strip()
    if not clean:
        return False
    data.setdefault("parking_lot", []).append(
        {
            "thought": clean[:300],
            "lesson_id": lesson_id,
            "source": source,
            "status": "Open",
            "created_at": _now(),
        }
    )
    return True


def close_parking_lot_item(data: Dict[str, Any], index: int) -> bool:
    items = data.setdefault("parking_lot", [])
    if index < 0 or index >= len(items):
        return False
    items[index]["status"] = "Closed"
    items[index]["closed_at"] = _now()
    return True


def record_project_milestone(
    data: Dict[str, Any],
    project_id: str,
    milestone_id: str,
    status: str = "In progress",
    note: str = "",
) -> None:
    allowed_statuses = {"Not started", "In progress", "Completed", "Skipped"}
    clean_status = status if status in allowed_statuses else "In progress"
    project = data.setdefault("project_milestones", {}).setdefault(project_id, {})
    project[milestone_id] = {
        "status": clean_status,
        "note": note[:500],
        "updated_at": _now(),
    }
