# Product Roadmap

## Version 0.2: current package

- Better dashboard and visual layout
- Learner profiles
- Progress export/import
- Deployment tab inside the app
- Docker, Render, and Streamlit Cloud files
- Expanded automated tests
- Official AI lessons and certification tracker

## Version 0.3: better learning loop

- Quiz review queue based on missed questions
- AI-generated practice questions from weak topics
- Lesson completion badges
- Daily/weekly study goals
- Official AI resource reminders and link review dates
- Better note organization

## Version 0.4: real multi-user app

- Authentication
- Database-backed progress
- Admin dashboard
- Class/group pages
- Private user data

## Version 0.5: production AI features

- AI-generated hints that reference exact lesson objectives
- Prompt coach with rubric history
- Project builder mode
- AI lesson editor
- Usage limits and cost controls

## Version 1.0: public launch

- Real code sandbox
- Payments or invite-only access if needed
- Analytics dashboard
- Accessibility polish
- Custom domain
