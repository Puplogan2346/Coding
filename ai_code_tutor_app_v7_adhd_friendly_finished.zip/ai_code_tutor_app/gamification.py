from __future__ import annotations

from dataclasses import dataclass

from projects import completed_project_milestones_count


@dataclass(frozen=True)
class Badge:
    id: str
    title: str
    description: str


BADGES: tuple[Badge, ...] = (
    Badge("first_step", "First Step", "Completed your first Python lesson."),
    Badge("quiz_starter", "Quiz Starter", "Finished your first quiz."),
    Badge("focus_reset", "Focus Reset", "Used the Focus Coach or saved a focus check-in."),
    Badge("code_runner", "Code Explorer", "Completed three lessons or more."),
    Badge("prompt_builder", "Prompt Builder", "Scored 8 or higher in Prompt Lab."),
    Badge("project_starter", "Project Starter", "Completed your first project milestone."),
    Badge("week_one", "Week One", "Completed seven daily missions."),
    Badge("halfway", "Halfway There", "Completed fifteen daily missions."),
    Badge("python_foundation", "Python Foundation", "Completed all core Python lessons."),
    Badge("ai_track", "AI Track Starter", "Started an official AI resource."),
    Badge("capstone_ready", "Capstone Ready", "Completed the 30-day mission plan."),
    Badge("capstone_shipper", "Capstone Shipper", "Completed five or more project milestones."),
)


def calculate_xp(progress_data: dict) -> int:
    lesson_xp = 50 * len(progress_data.get("completed_lessons", []) or [])
    quiz_xp = 0
    for score in (progress_data.get("quiz_scores", {}) or {}).values():
        quiz_xp += int(round(score.get("percent", 0) / 10))
    prompt_xp = sum(int(item.get("score", 0)) for item in progress_data.get("prompt_scores", []) or [])
    mission_xp = 25 * sum(
        1
        for item in (progress_data.get("daily_missions", {}) or {}).values()
        if item.get("status") == "Completed"
    )
    official_xp = 20 * sum(
        1
        for status in (progress_data.get("official_ai_status", {}) or {}).values()
        if status in {"Queued", "In progress", "Completed"}
    )
    focus_xp = min(5 * len(progress_data.get("focus_checkins", []) or []), 100)
    project_xp = 30 * completed_project_milestones_count(progress_data)
    return lesson_xp + quiz_xp + prompt_xp + mission_xp + official_xp + focus_xp + project_xp


def level_for_xp(xp: int) -> str:
    if xp >= 2100:
        return "Level 7 - Learning App Builder"
    if xp >= 1800:
        return "Level 6 - Capstone Builder"
    if xp >= 1200:
        return "Level 5 - AI App Maker"
    if xp >= 800:
        return "Level 4 - Project Builder"
    if xp >= 450:
        return "Level 3 - Python Explorer"
    if xp >= 150:
        return "Level 2 - Habit Builder"
    return "Level 1 - New Coder"


def earned_badges(progress_data: dict, total_lessons: int) -> list[Badge]:
    completed_lessons = progress_data.get("completed_lessons", []) or []
    quiz_scores = progress_data.get("quiz_scores", {}) or {}
    prompt_scores = progress_data.get("prompt_scores", []) or []
    daily_missions = progress_data.get("daily_missions", {}) or {}
    official_status = progress_data.get("official_ai_status", {}) or {}
    completed_missions = sum(1 for item in daily_missions.values() if item.get("status") == "Completed")
    project_milestones = completed_project_milestones_count(progress_data)

    earned_ids: set[str] = set()
    if completed_lessons:
        earned_ids.add("first_step")
    if quiz_scores:
        earned_ids.add("quiz_starter")
    if progress_data.get("focus_checkins"):
        earned_ids.add("focus_reset")
    if len(completed_lessons) >= 3:
        earned_ids.add("code_runner")
    if any(item.get("score", 0) >= 8 for item in prompt_scores):
        earned_ids.add("prompt_builder")
    if project_milestones >= 1:
        earned_ids.add("project_starter")
    if completed_missions >= 7:
        earned_ids.add("week_one")
    if completed_missions >= 15:
        earned_ids.add("halfway")
    if len(completed_lessons) >= total_lessons:
        earned_ids.add("python_foundation")
    if any(status in {"Queued", "In progress", "Completed"} for status in official_status.values()):
        earned_ids.add("ai_track")
    if completed_missions >= 30:
        earned_ids.add("capstone_ready")
    if project_milestones >= 5:
        earned_ids.add("capstone_shipper")

    return [badge for badge in BADGES if badge.id in earned_ids]
