# AI Code Tutor

A private, deploy-ready Streamlit training app for learning Python in 30 minutes a day, improving prompts, practicing AI-assisted coding, and tracking official AI learning paths.


### Official AI Lessons & Certifications

The app now includes an **AI Certs** tab that tracks official learning resources from Anthropic/Claude, Gumloop, OpenAI, Google Cloud/Gemini, Microsoft/Azure AI, AWS, Hugging Face, and NVIDIA. It links to the official provider pages, lets each learner save status and private notes, and separates course/certification tracking from the core Python curriculum. See `OFFICIAL_AI_RESOURCES.md` for the curated list and maintenance notes.

## What is included

- New **Today** tab with a 30-day, 30-minutes-a-day training plan
- New **Focus Coach** tab with ADHD-friendly rescue mode, parking lot, body-double scripts, and focus check-ins
- New **Projects** tab with tiny project tracks and capstone milestones
- Daily missions with warm-up, learning, practice, reflection, review queue, and fun challenge
- Streaks, XP levels, badge shelf, focus check-ins, project XP, and end-of-session reflections
- 12 beginner-to-intermediate Python lessons
- Quizzes with saved scores
- Coding challenges with starter code, hints, tests, and sample solutions
- Prompt Lab with a scoring rubric
- Optional OpenAI-powered AI Tutor
- Learner profiles so multiple people can use separate progress files
- Progress export/import
- New-user habit loop designed for short daily sessions instead of cramming
- Xcode/iPhone Simulator testing guide plus a simple SwiftUI WebView wrapper
- Streamlit Community Cloud entrypoint
- Dockerfile and docker-compose setup
- Render-style deployment blueprint
- GitHub Actions test workflow
- Private GitHub setup guide
- New-user journey smoke test and report
- Official AI lessons/certifications tracker with private notes
- Recommended next AI-resource card for Gumloop, Claude/Anthropic, OpenAI, and later credential paths
- Pytest coverage for curriculum, progress, prompt scoring, code runner behavior, app static checks, and official AI resource tracking
- Bug-fix and QA report in `BUG_FIXES_AND_IMPROVEMENTS.md`

## Keep private while building

Use a private GitHub repository until the app is fully usable. See `PRIVATE_GITHUB_SETUP.md` for the exact setup commands. The important rule: never commit `.env`, `.streamlit/secrets.toml`, API keys, or learner progress files.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

On Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

## Enable the AI Tutor

The app works without AI. To enable live AI help, set an API key.

Environment variable option:

```bash
export OPENAI_API_KEY="your_api_key_here"
export OPENAI_MODEL="gpt-5.5"
streamlit run app.py
```

Streamlit secrets option:

```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Then edit `.streamlit/secrets.toml` and add your real key.

Never commit `.streamlit/secrets.toml`, `.env`, or any API key.

## Public sharing safety

The included code runner is useful for your own computer, but it is not a secure sandbox for public users.

For public deployment, keep this setting:

```bash
ALLOW_CODE_RUNNER=false
```

To enable local lesson tests only on your own machine:

```bash
ALLOW_CODE_RUNNER=true streamlit run app.py
```

## Test in Xcode / iPhone Simulator

This is a Streamlit web app, so Xcode is optional. To preview the mobile experience, run the app locally and open it in iOS Simulator Safari. The package also includes a simple SwiftUI WebView wrapper in `ios_wrapper/`. See `XCODE_IOS_TESTING.md`.

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Then open `http://localhost:8501` in iOS Simulator Safari.

## Run tests

```bash
pytest -q
```

## Run with Docker

```bash
cp .env.example .env
# edit .env if you want AI features

docker build -t ai-code-tutor .
docker run -p 8501:8501 --env-file .env ai-code-tutor
```

Or use Docker Compose:

```bash
docker compose up --build
```

Then open `http://localhost:8501`.

## Project structure

```text
app.py                         Main Streamlit app
streamlit_app.py               Streamlit Community Cloud wrapper
curriculum.py                  Lessons, quizzes, coding challenges
ai_tutor.py                    OpenAI API helper functions
prompt_lab.py                  Prompt scoring rubric
study_plan.py                  30-day daily mission plan and review queue
focus_coach.py                 ADHD-friendly focus sessions and rescue mode
projects.py                    Project tracks and capstone checkpoints
gamification.py                XP, levels, and badges
official_ai_resources.py       Official AI lessons/certifications catalog
progress.py                    Learner profile, streak, mission, and progress storage
code_runner.py                 Optional local code runner
requirements.txt               Runtime and test dependencies
pyproject.toml                 Project metadata and pytest config
Dockerfile                     Container deployment
render.yaml                    Render-style deployment blueprint
docker-compose.yml             Local container workflow
README_DEPLOY.md               Step-by-step sharing/deployment guide
PRIVATE_GITHUB_SETUP.md        Private repo setup and safety checklist
NEW_USER_TEST_REPORT.md        Fresh learner smoke-test notes
OFFICIAL_AI_RESOURCES.md       Official AI resource tracker notes
NEW_USER_OFFICIAL_AI_TEST_REPORT.md Official AI tracker smoke test
BUG_FIXES_AND_IMPROVEMENTS.md v5 bug-fix and QA notes
V6_OPTIMIZATION_REPORT.md      Finished-app optimization and QA notes
V7_FINISHED_TRAINING_APP_REPORT.md Finished app, focus, project, and Xcode QA notes
THIRTY_DAY_TRAINING_PLAN.md    Human-readable daily learning plan
ADHD_FRIENDLY_DESIGN.md        ADHD-friendly UX/design notes
XCODE_IOS_TESTING.md           iPhone Simulator and SwiftUI wrapper guide
ios_wrapper/                   Optional SwiftUI WKWebView wrapper files
.github/workflows/tests.yml    CI tests for GitHub
.streamlit/config.toml         Streamlit runtime config
.streamlit/secrets.toml.example Example secrets file
```

## Suggested next upgrades

1. Replace file-based progress with SQLite, Supabase, Postgres, or Firebase.
2. Add authentication so every learner has a private account.
3. Replace the simple review queue with real spaced-repetition cards.
4. Generate custom quizzes from missed questions.
5. Add a lesson editor for creating new curriculum items.
6. Add a true sandboxed code runner for public deployments.
7. Add analytics for lesson completion and quiz improvement.
