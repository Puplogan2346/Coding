from __future__ import annotations

import json
import os
from statistics import mean

import streamlit as st

from ai_tutor import ai_is_configured, call_ai_tutor, configured_model, improve_prompt_with_ai
from code_runner import code_runner_enabled, run_python_with_tests
from curriculum import LESSONS, get_lesson_by_id
from focus_coach import (
    ADHD_DESIGN_PRINCIPLES,
    ENERGY_LEVELS,
    FOCUS_LEVELS,
    body_double_script,
    focus_blocks,
    focus_checkin_score,
    recommended_focus_mode,
    total_focus_minutes,
)
from gamification import calculate_xp, earned_badges, level_for_xp
from official_ai_resources import (
    OFFICIAL_AI_MILESTONES,
    OFFICIAL_AI_RESOURCES,
    OFFICIAL_AI_STARTER_PATH,
    PROVIDER_ORDER,
    RESOURCE_TYPES,
    STATUS_OPTIONS,
    next_recommended_resource,
    official_resource_stats,
    provider_counts,
    resource_has_certificate,
    resources_for_ids,
)
from projects import (
    PROJECTS,
    completed_project_milestones_count,
    next_project_milestone,
    project_completion_percent,
    project_progress,
    recommended_project_id,
)
from progress import (
    add_parking_lot_item,
    close_parking_lot_item,
    completed_daily_missions_count,
    completion_percent,
    lessons_remaining,
    load_progress,
    mark_lesson_complete,
    progress_path_for_profile,
    record_daily_mission,
    record_focus_checkin,
    record_official_ai_resource,
    record_prompt_score,
    record_project_milestone,
    record_quiz_score,
    save_focus_preferences,
    save_note,
    save_progress,
)
from prompt_lab import improved_prompt_template, score_prompt
from study_plan import DAILY_PLAN, next_mission, plan_completion_percent, review_queue


st.set_page_config(
    page_title="AI Code Tutor",
    page_icon="🐍",
    layout="wide",
    initial_sidebar_state="expanded",
)

LESSON_IDS = [lesson.id for lesson in LESSONS]


def apply_theme() -> None:
    st.markdown(
        """
<style>
    .block-container {padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1180px;}
    [data-testid="stSidebar"] {border-right: 1px solid rgba(120, 120, 120, .16);}
    h1, h2, h3 {letter-spacing: -0.025em;}
    .hero {
        padding: 2.1rem 2.2rem;
        border-radius: 28px;
        background: linear-gradient(135deg, rgba(53, 111, 255, .18), rgba(106, 214, 185, .16));
        border: 1px solid rgba(120, 120, 120, .18);
        margin-bottom: 1.25rem;
    }
    .hero h1 {font-size: 3rem; margin: 0 0 .3rem 0;}
    .hero p {font-size: 1.08rem; margin: .2rem 0 0 0; color: rgba(49, 51, 63, .78); max-width: 760px;}
    .card {
        border: 1px solid rgba(120, 120, 120, .18);
        border-radius: 22px;
        padding: 1.05rem 1.15rem;
        background: rgba(255, 255, 255, .72);
        box-shadow: 0 14px 36px rgba(0, 0, 0, .045);
        min-height: 118px;
        margin-bottom: .75rem;
    }
    .card h3 {font-size: 1.05rem; margin: 0 0 .3rem 0;}
    .card p {margin: 0; color: rgba(49, 51, 63, .74);}
    .pill {
        display: inline-block;
        padding: .22rem .58rem;
        border-radius: 999px;
        background: rgba(53, 111, 255, .12);
        border: 1px solid rgba(53, 111, 255, .18);
        font-size: .8rem;
        margin-right: .35rem;
        margin-bottom: .35rem;
    }
    .lesson-row {
        padding: .75rem .85rem;
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 16px;
        margin-bottom: .55rem;
        background: rgba(255, 255, 255, .58);
    }
    .small-muted {font-size: .88rem; color: rgba(49, 51, 63, .66);}
    .success-soft {background: rgba(52, 168, 83, .12); border-color: rgba(52, 168, 83, .25);}
    .warning-soft {background: rgba(251, 188, 5, .13); border-color: rgba(251, 188, 5, .28);}
    .danger-soft {background: rgba(234, 67, 53, .10); border-color: rgba(234, 67, 53, .22);}
    .step-card {
        padding: .95rem 1.05rem;
        border-radius: 18px;
        border: 1px solid rgba(120, 120, 120, .15);
        background: rgba(255, 255, 255, .68);
        margin-bottom: .7rem;
    }
    .step-card strong {font-size: 1rem;}
    .step-card span {display: block; color: rgba(49, 51, 63, .70); margin-top: .2rem;}
    .resource-card {
        border: 1px solid rgba(120, 120, 120, .16);
        border-radius: 20px;
        padding: 1rem 1.1rem;
        background: rgba(255, 255, 255, .66);
        margin-bottom: .8rem;
    }
    .resource-card h3 {margin: 0 0 .25rem 0; font-size: 1.06rem;}
    .resource-card p {margin: .25rem 0; color: rgba(49, 51, 63, .74);}
    .resource-meta {font-size: .86rem; color: rgba(49, 51, 63, .68); margin-bottom: .45rem;}
    .track-card {
        padding: .85rem 1rem;
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 16px;
        margin-bottom: .55rem;
        background: rgba(255, 255, 255, .54);
    }
    .mission-card {
        border: 1px solid rgba(53, 111, 255, .20);
        border-radius: 26px;
        padding: 1.2rem 1.25rem;
        background: linear-gradient(135deg, rgba(53, 111, 255, .11), rgba(106, 214, 185, .11));
        margin-bottom: 1rem;
    }
    .mission-card h2 {margin-top: 0;}
    .block-list {
        border-left: 3px solid rgba(53, 111, 255, .35);
        padding-left: .8rem;
        margin-bottom: .65rem;
    }
    .badge-card {
        border: 1px solid rgba(120, 120, 120, .16);
        border-radius: 16px;
        padding: .7rem .8rem;
        margin-bottom: .5rem;
        background: rgba(255, 255, 255, .64);
    }
    .badge-card strong {display: block; margin-bottom: .15rem;}
    .badge-card span {color: rgba(49, 51, 63, .70); font-size: .88rem;}

    .focus-card {
        border: 1px solid rgba(53, 111, 255, .18);
        border-radius: 18px;
        padding: .85rem 1rem;
        background: rgba(53, 111, 255, .065);
        margin-bottom: .55rem;
    }
    .focus-card strong {display: block; margin-bottom: .15rem;}
    .focus-card span {color: rgba(49, 51, 63, .72); font-size: .9rem;}
    .project-card {
        border: 1px solid rgba(120, 120, 120, .16);
        border-radius: 20px;
        padding: 1rem 1.1rem;
        background: rgba(255, 255, 255, .68);
        margin-bottom: .8rem;
    }
    .project-card h3 {margin: 0 0 .25rem 0; font-size: 1.08rem;}
    .project-card p {margin: .25rem 0; color: rgba(49, 51, 63, .74);}
    .parking-item {
        padding: .55rem .7rem;
        border-radius: 14px;
        border: 1px dashed rgba(120, 120, 120, .28);
        margin-bottom: .4rem;
        background: rgba(255,255,255,.52);
    }
    div[data-testid="stMetric"] {
        border: 1px solid rgba(120, 120, 120, .15);
        border-radius: 18px;
        padding: .8rem .95rem;
        background: rgba(255, 255, 255, .66);
    }
</style>
""".strip(),
        unsafe_allow_html=True,
    )


def first_incomplete_lesson_id(progress_data: dict) -> str:
    completed = set(progress_data.get("completed_lessons", []))
    for lesson_item in LESSONS:
        if lesson_item.id not in completed:
            return lesson_item.id
    return LESSONS[-1].id


def get_quiz_average(progress_data: dict) -> float:
    scores = progress_data.get("quiz_scores", {}).values()
    percentages = [item.get("percent", 0) for item in scores]
    return round(mean(percentages), 1) if percentages else 0.0


def get_best_prompt_score(progress_data: dict) -> int:
    scores = [item.get("score", 0) for item in progress_data.get("prompt_scores", [])]
    return max(scores) if scores else 0


def render_score_badge(score: int, total: int) -> None:
    percent = round((score / total) * 100) if total else 0
    if percent >= 80:
        st.success(f"Score: {score}/{total} ({percent}%). Strong work.")
    elif percent >= 60:
        st.warning(f"Score: {score}/{total} ({percent}%). Review the misses and try again.")
    else:
        st.error(f"Score: {score}/{total} ({percent}%). Revisit the lesson, then retake it.")


def render_card(title: str, body: str, tone: str = "") -> None:
    tone_class = f" {tone}" if tone else ""
    st.markdown(
        f"""
<div class="card{tone_class}">
    <h3>{title}</h3>
    <p>{body}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_status_pills(lesson_level: str, minutes: int, is_complete: bool) -> None:
    status = "Complete" if is_complete else "In progress"
    st.markdown(
        f"""
<span class="pill">{lesson_level}</span>
<span class="pill">{minutes} min</span>
<span class="pill">{status}</span>
""".strip(),
        unsafe_allow_html=True,
    )


def render_step(number: int, title: str, body: str) -> None:
    st.markdown(
        f"""
<div class="step-card">
    <strong>{number}. {title}</strong>
    <span>{body}</span>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_time_blocks(blocks) -> None:
    for block in blocks:
        st.markdown(
            f"""
<div class="block-list">
    <strong>{block.label} - {block.minutes} min</strong><br>
    <span class="small-muted">{block.instruction}</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )


def render_focus_blocks(blocks) -> None:
    for block in blocks:
        st.markdown(
            f"""
<div class="focus-card">
    <strong>{block.label} - {block.minutes} min</strong>
    <span>{block.instruction}<br><em>{block.why_it_helps}</em></span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )


def render_project_summary(project, progress_data: dict) -> None:
    completion = int(project_completion_percent(progress_data, project.id) * 100)
    milestone = next_project_milestone(progress_data, project.id)
    st.markdown(
        f"""
<div class="project-card">
    <h3>{project.title}</h3>
    <p><strong>{project.level}</strong> · about {project.minutes} min total · {completion}% complete</p>
    <p>{project.description}</p>
    <p><strong>Next milestone:</strong> {milestone.title}</p>
    <p><strong>Skills:</strong> {', '.join(project.skills)}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def open_parking_lot_items(progress_data: dict) -> list[tuple[int, dict]]:
    return [
        (index, item)
        for index, item in enumerate(progress_data.get("parking_lot", []) or [])
        if item.get("status", "Open") == "Open"
    ]


def render_badge_shelf(progress_data: dict) -> None:
    badges = earned_badges(progress_data, len(LESSONS))
    if not badges:
        st.info("No badges yet. Complete your first mission or lesson to unlock one.")
        return
    for badge in badges:
        st.markdown(
            f"""
<div class="badge-card">
    <strong>{badge.title}</strong>
    <span>{badge.description}</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )


def render_daily_mission_card(mission) -> None:
    lesson_text = "Open practice" if mission.lesson_id is None else get_lesson_by_id(mission.lesson_id).title
    st.markdown(
        f"""
<div class="mission-card">
    <h2>Day {mission.day}: {mission.title}</h2>
    <p><strong>Focus:</strong> {mission.focus} | <strong>Time:</strong> {mission.total_minutes} minutes | <strong>Lesson:</strong> {lesson_text}</p>
    <p><strong>Fun challenge:</strong> {mission.fun_challenge}</p>
    <p><strong>Proof of understanding:</strong> {mission.proof}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def render_official_resource_summary(resource) -> None:
    st.markdown(
        f"""
<div class="resource-card">
    <h3>{resource.provider}: {resource.title}</h3>
    <div class="resource-meta">{resource.resource_type} | {resource.level} | {resource.time_commitment}</div>
    <p>{resource.summary}</p>
    <p><strong>Credential:</strong> {resource.certificate}</p>
    <p><strong>Use it when:</strong> {resource.recommended_when}</p>
</div>
""".strip(),
        unsafe_allow_html=True,
    )


def official_resource_status(progress_data: dict, resource_id: str) -> str:
    saved = progress_data.get("official_ai_status", {}).get(resource_id, "Not started")
    return saved if saved in STATUS_OPTIONS else "Not started"


def official_resource_note(progress_data: dict, resource_id: str) -> str:
    return progress_data.get("official_ai_notes", {}).get(resource_id, "")


def render_official_resource(resource, progress_data: dict, progress_path) -> None:
    statuses = progress_data.setdefault("official_ai_status", {})
    notes = progress_data.setdefault("official_ai_notes", {})
    current_status = statuses.get(resource.id, "Not started")
    if current_status not in STATUS_OPTIONS:
        current_status = "Not started"

    with st.container():
        st.markdown(
            f"""
<div class="lesson-row">
    <strong>{resource.title}</strong><br>
    <span class="small-muted">{resource.provider} · {resource.resource_type} · {resource.level} · {resource.time_commitment}</span>
</div>
""".strip(),
            unsafe_allow_html=True,
        )
        st.write(resource.summary)
        st.caption(f"Why it matters: {resource.why_it_matters}")
        st.caption(f"Certificate/credential: {resource.certificate}")
        st.caption(f"Recommended timing: {resource.recommended_when}")
        st.markdown("Tags: " + " ".join(f"`{tag}`" for tag in resource.tags))

        status_col, note_col = st.columns([0.8, 1.2])
        with status_col:
            new_status = st.selectbox(
                "Status",
                STATUS_OPTIONS,
                index=STATUS_OPTIONS.index(current_status),
                key=f"official_status_{resource.id}",
            )
            st.markdown(f"[Open official resource]({resource.url})")
        with note_col:
            note = st.text_area(
                "Private note",
                value=notes.get(resource.id, ""),
                key=f"official_note_{resource.id}",
                height=88,
                placeholder="Example: finish this after lesson 4, or add certificate link here.",
            )

        if st.button("Save this resource", key=f"save_official_{resource.id}"):
            record_official_ai_resource(progress_data, resource.id, new_status, note)
            save_progress(progress_data, progress_path)
            st.success("Official resource progress saved.")


def safe_json(data: dict) -> str:
    return json.dumps(data, indent=2, sort_keys=True)


apply_theme()

with st.sidebar:
    st.header("Your learning space")
    profile_name = st.text_input(
        "Learner profile",
        value=st.session_state.get("profile_name", "guest"),
        help="Use a name like your first name or study group name. It creates a separate progress file.",
    ).strip() or "guest"

    if st.session_state.get("active_profile") != profile_name:
        st.session_state.active_profile = profile_name
        st.session_state.profile_name = profile_name
        st.session_state.ai_messages = []
        st.session_state.selected_lesson_id = ""

    st.caption(f"Profile: `{profile_name}`")
    progress_path = progress_path_for_profile(profile_name)
    progress_data = load_progress(LESSON_IDS, progress_path, profile_name=profile_name)

    if (
        not st.session_state.get("selected_lesson_id")
        or st.session_state.selected_lesson_id not in LESSON_IDS
    ):
        st.session_state.selected_lesson_id = first_incomplete_lesson_id(progress_data)

    completed_count = len(progress_data.get("completed_lessons", []))
    completion = completion_percent(progress_data, len(LESSONS))

    st.subheader("Progress")
    st.progress(completion)
    st.write(f"{completed_count} of {len(LESSONS)} lessons complete")
    daily_completion = plan_completion_percent(progress_data)
    st.progress(daily_completion)
    st.write(f"{completed_daily_missions_count(progress_data)} of {len(DAILY_PLAN)} daily missions complete")

    labels = [f"{index + 1}. {lesson_item.title}" for index, lesson_item in enumerate(LESSONS)]
    label_by_id = {lesson_item.id: labels[index] for index, lesson_item in enumerate(LESSONS)}
    id_by_label = {label: lesson_item.id for label, lesson_item in zip(labels, LESSONS)}
    current_label = label_by_id.get(st.session_state.selected_lesson_id, labels[0])

    selected_label = st.selectbox(
        "Choose a lesson",
        labels,
        index=labels.index(current_label),
    )
    st.session_state.selected_lesson_id = id_by_label[selected_label]

    st.divider()
    st.subheader("Study mode")
    st.radio(
        "Session focus",
        ["Learn", "Practice", "Review", "Build"],
        horizontal=True,
        key="study_focus",
        help="This guides the dashboard and daily mission suggestions.",
    )

    st.divider()
    st.subheader("AI status")
    if ai_is_configured():
        st.success(f"Connected: {configured_model()}")
    else:
        st.warning("Not connected yet")
        st.caption("Set OPENAI_API_KEY to enable the AI tutor.")

    st.subheader("Code runner")
    if code_runner_enabled():
        st.warning("Enabled for local use")
    else:
        st.info("Off for safe sharing")
        st.caption("Keep ALLOW_CODE_RUNNER=false on public deployments.")

    st.divider()
    with st.expander("Progress tools"):
        st.download_button(
            "Download my progress",
            data=safe_json(progress_data),
            file_name=f"ai_code_tutor_progress_{profile_name}.json",
            mime="application/json",
        )
        uploaded_progress = st.file_uploader("Import progress JSON", type=["json"])
        if uploaded_progress is not None and st.button("Import progress"):
            try:
                imported = json.loads(uploaded_progress.getvalue().decode("utf-8"))
                imported["profile_name"] = profile_name
                save_progress(imported, progress_path)
                st.success("Progress imported.")
                st.rerun()
            except (UnicodeDecodeError, json.JSONDecodeError):
                st.error("That file was not valid JSON.")

        confirm_reset = st.checkbox("I understand this deletes this profile's progress")
        if confirm_reset and st.button("Reset this profile"):
            if progress_path.exists():
                progress_path.unlink()
            st.session_state.ai_messages = []
            st.rerun()

lesson = get_lesson_by_id(st.session_state.selected_lesson_id)
completed_lessons = set(progress_data.get("completed_lessons", []))
lesson_complete = lesson.id in completed_lessons
next_lesson = get_lesson_by_id(first_incomplete_lesson_id(progress_data))

st.markdown(
    f"""
<div class="hero">
    <h1>AI Code Tutor</h1>
    <p>A private, ADHD-friendly 30-minutes-a-day training app for learning Python, practicing prompts, building projects, and growing into AI workflows.</p>
</div>
""".strip(),
    unsafe_allow_html=True,
)

feature_cols = st.columns(5)
with feature_cols[0]:
    render_card("30-day plan", "Daily 30-minute missions with review days, tiny wins, and capstone prep.")
with feature_cols[1]:
    render_card("ADHD-friendly", "Tiny starts, parking lot, rescue mode, focus check-ins, streaks, XP, and badges.")
with feature_cols[2]:
    render_card("Prompt Lab", "Score prompts with a rubric and rewrite them for stronger AI results.")
with feature_cols[3]:
    render_card("Official AI track", "Claude, Gumloop, OpenAI, Google, Microsoft, AWS, Hugging Face, and NVIDIA resources.")
with feature_cols[4]:
    render_card("Private-ready", "GitHub-private workflow, Docker, CI tests, secrets examples, and safe sharing defaults.")

(
    today_tab,
    focus_tab,
    dashboard_tab,
    lesson_tab,
    quiz_tab,
    code_tab,
    projects_tab,
    prompt_tab,
    official_ai_tab,
    ai_tab,
    notes_tab,
    deploy_tab,
) = st.tabs(["Today", "Focus Coach", "Dashboard", "Learn", "Quiz", "Code Lab", "Projects", "Prompt Lab", "AI Certs", "AI Tutor", "Notes", "Deploy"])

with today_tab:
    mission = next_mission(progress_data)
    st.header("Today: 30-minute coding session")
    render_daily_mission_card(mission)

    xp = calculate_xp(progress_data)
    today_metrics = st.columns(4)
    today_metrics[0].metric("30-day plan", f"{completed_daily_missions_count(progress_data)}/{len(DAILY_PLAN)}")
    today_metrics[1].metric("Study streak", f"{progress_data.get('study_streak', 0)} days")
    today_metrics[2].metric("XP", xp)
    today_metrics[3].metric("Level", level_for_xp(xp).replace("Level ", "L"))

    left_today, right_today = st.columns([1.2, 1])
    with left_today:
        st.subheader("Your 30-minute recipe")
        render_time_blocks(mission.blocks)
        if mission.lesson_id:
            if st.button("Jump to today's lesson", type="primary"):
                st.session_state.selected_lesson_id = mission.lesson_id
                st.rerun()
        st.subheader("End-of-session check-in")
        status = st.selectbox("Mission status", ["Completed", "In progress", "Skipped"], key=f"mission_status_{mission.day}")
        mood = st.selectbox("How did it feel?", ["Easy", "Good", "Stuck but learning", "Hard", "Fun"], key=f"mission_mood_{mission.day}")
        reflection = st.text_area(
            "One sentence reflection",
            key=f"mission_reflection_{mission.day}",
            height=90,
            placeholder="Example: I finally understood why return is different from print.",
        )
        if st.button("Save today's mission"):
            record_daily_mission(progress_data, mission.day, status=status, mood=mood, reflection=reflection)
            save_progress(progress_data, progress_path)
            st.success("Daily mission saved. Nice work.")
            st.rerun()

    with right_today:
        st.subheader("ADHD-friendly setup")
        today_energy = st.selectbox("Energy", ENERGY_LEVELS, index=1, key=f"today_energy_{mission.day}")
        today_focus = st.selectbox("Focus", FOCUS_LEVELS, index=1, key=f"today_focus_{mission.day}")
        mode = recommended_focus_mode(today_energy, 30)
        st.info(f"Recommended mode: {mode.title}")
        with st.expander("Show focus recipe", expanded=True):
            render_focus_blocks(focus_blocks(mode.minutes, today_energy))

        quick_thought = st.text_input("Parking lot thought", key=f"today_parking_{mission.day}", placeholder="Example: I need to research laptops later")
        if st.button("Park thought", key=f"park_today_{mission.day}"):
            if add_parking_lot_item(progress_data, quick_thought, lesson_id=mission.lesson_id or lesson.id, source="Today"):
                save_progress(progress_data, progress_path)
                st.success("Parked. Back to the next tiny action.")
                st.rerun()
            else:
                st.warning("Write a thought first.")

        if st.button("Save quick focus check-in", key=f"focus_checkin_today_{mission.day}"):
            record_focus_checkin(progress_data, today_energy, today_focus, win=mission.proof)
            save_progress(progress_data, progress_path)
            st.success(f"Saved. Focus score: {focus_checkin_score(today_energy, today_focus)}/6.")

        st.subheader("Review queue")
        for lesson_id in review_queue(progress_data, LESSON_IDS):
            review_lesson = get_lesson_by_id(lesson_id)
            st.markdown(f"- **{review_lesson.title}**")
        st.caption("Review keeps old ideas alive while you add new ones.")

        if mission.official_resource_ids:
            st.subheader("Official AI side quest")
            for resource in resources_for_ids(mission.official_resource_ids):
                st.markdown(f"- [{resource.provider}: {resource.title}]({resource.url})")

        st.subheader("Badge shelf")
        render_badge_shelf(progress_data)


with focus_tab:
    st.header("Focus Coach: ADHD-friendly coding sessions")
    st.write(
        "This section turns coding into small, visible, low-pressure actions. "
        "It is not medical advice; it is a study-design layer for focus, memory, and momentum."
    )

    pref = progress_data.get("focus_preferences", {})
    pref_cols = st.columns(5)
    with pref_cols[0]:
        default_minutes = st.selectbox("Default session", [10, 30, 45], index=[10, 30, 45].index(int(pref.get("default_minutes", 30))), format_func=lambda x: f"{x} min")
    with pref_cols[1]:
        adhd_mode = st.checkbox("ADHD-friendly mode", value=bool(pref.get("adhd_friendly_mode", True)))
    with pref_cols[2]:
        low_stim = st.checkbox("Low-stimulation UI", value=bool(pref.get("low_stimulation_mode", False)))
    with pref_cols[3]:
        break_reminders = st.checkbox("Break reminders", value=bool(pref.get("break_reminders", True)))
    with pref_cols[4]:
        reward_style = st.selectbox("Reward style", ["Tiny wins", "Badges", "Quiet progress"], index=["Tiny wins", "Badges", "Quiet progress"].index(pref.get("reward_style", "Tiny wins") if pref.get("reward_style", "Tiny wins") in ["Tiny wins", "Badges", "Quiet progress"] else "Tiny wins"))

    if st.button("Save focus preferences"):
        save_focus_preferences(
            progress_data,
            {
                "default_minutes": default_minutes,
                "adhd_friendly_mode": adhd_mode,
                "low_stimulation_mode": low_stim,
                "break_reminders": break_reminders,
                "reward_style": reward_style,
            },
        )
        save_progress(progress_data, progress_path)
        st.success("Focus preferences saved.")

    coach_cols = st.columns([1.15, 1])
    with coach_cols[0]:
        st.subheader("Build your next session")
        energy = st.selectbox("Energy right now", ENERGY_LEVELS, index=1, key="focus_tab_energy")
        available_minutes = st.slider("Minutes available", 10, 45, int(pref.get("default_minutes", 30)), step=5)
        mode = recommended_focus_mode(energy, available_minutes)
        blocks = focus_blocks(mode.minutes, energy)
        st.info(f"Recommended: {mode.title} - {mode.summary}")
        st.caption(f"This plan totals {total_focus_minutes(blocks)} minutes.")
        render_focus_blocks(blocks)

        with st.expander("Body-double script"):
            for line in body_double_script(next_mission(progress_data).title):
                st.write(f"- {line}")

    with coach_cols[1]:
        st.subheader("Parking lot")
        st.caption("Put distracting ideas here so you do not have to chase them mid-session.")
        thought = st.text_input("Distracting thought or side quest", key="focus_parking_lot_input")
        if st.button("Park this thought"):
            if add_parking_lot_item(progress_data, thought, lesson_id=lesson.id, source="Focus Coach"):
                save_progress(progress_data, progress_path)
                st.success("Parked. Return to the next tiny action.")
                st.rerun()
            else:
                st.warning("Write a thought first, even a messy one.")

        open_items = open_parking_lot_items(progress_data)
        if not open_items:
            st.info("Parking lot is empty.")
        for index, item in open_items[-6:]:
            st.markdown(f"<div class='parking-item'>{item.get('thought', '')}</div>", unsafe_allow_html=True)
            if st.button("Close", key=f"close_parking_{index}"):
                close_parking_lot_item(progress_data, index)
                save_progress(progress_data, progress_path)
                st.rerun()

        st.subheader("Focus check-in")
        focus_level = st.selectbox("Focus level", FOCUS_LEVELS, index=1, key="focus_tab_level")
        blockers = st.text_area("What might pull you away?", height=80, key="focus_tab_blockers")
        win = st.text_area("What tiny win would count today?", height=80, key="focus_tab_win")
        if st.button("Save focus check-in"):
            record_focus_checkin(progress_data, energy, focus_level, blockers, win)
            save_progress(progress_data, progress_path)
            st.success(f"Check-in saved. Focus score: {focus_checkin_score(energy, focus_level)}/6.")

    st.subheader("Design rules used in this app")
    for principle in ADHD_DESIGN_PRINCIPLES:
        st.write(f"- {principle}")

with dashboard_tab:
    if completed_count == 0:
        st.success("Welcome. This profile is brand new, so start with Lesson 1 and use the checklist below.")

    with st.expander("Start here: your first 10 minutes", expanded=completed_count == 0):
        intro_cols = st.columns(4)
        with intro_cols[0]:
            render_step(1, "Read", "Open the Learn tab and read the current lesson once without memorizing.")
        with intro_cols[1]:
            render_step(2, "Check", "Take the quiz. Misses are useful because they tell you what to review.")
        with intro_cols[2]:
            render_step(3, "Practice", "Try Code Lab from the starter code before viewing the sample solution.")
        with intro_cols[3]:
            render_step(4, "Prompt", "Use Prompt Lab to ask for help with context, constraints, and verification.")

    official_stats = official_resource_stats(progress_data)
    metric_cols = st.columns(6)
    metric_cols[0].metric("Lessons complete", f"{completed_count}/{len(LESSONS)}")
    metric_cols[1].metric("Daily missions", f"{completed_daily_missions_count(progress_data)}/{len(DAILY_PLAN)}")
    metric_cols[2].metric("Study streak", f"{progress_data.get('study_streak', 0)} days")
    metric_cols[3].metric("Quiz average", f"{get_quiz_average(progress_data)}%")
    metric_cols[4].metric("Best prompt score", f"{get_best_prompt_score(progress_data)}/10")
    metric_cols[5].metric("AI resources done", f"{official_stats['completed']}/{official_stats['total']}")

    left, right = st.columns([1.25, 1])
    with left:
        st.subheader("Recommended next step")
        current_mission = next_mission(progress_data)
        render_card(
            f"Day {current_mission.day}: {current_mission.title}",
            f"30-minute mission. Focus: {current_mission.focus}. Proof: {current_mission.proof}",
            "success-soft" if current_mission.lesson_id == lesson.id else "",
        )
        render_card(
            next_lesson.title,
            f"Next incomplete lesson. Estimated lesson time: {next_lesson.time_minutes} minutes. Focus: {st.session_state.get('study_focus', 'Learn')}.",
        )
        if st.button("Jump to recommended lesson", type="primary"):
            st.session_state.selected_lesson_id = next_lesson.id
            st.rerun()

        st.subheader("Curriculum map")
        for index, item in enumerate(LESSONS, start=1):
            status = "✅ Complete" if item.id in completed_lessons else "⬜ Not complete"
            score = progress_data.get("quiz_scores", {}).get(item.id)
            score_text = f"Quiz: {score['percent']}%" if score else "Quiz: not taken"
            st.markdown(
                f"""
<div class="lesson-row">
    <strong>{index}. {item.title}</strong><br>
    <span class="small-muted">{item.level} · {item.time_minutes} min · {status} · {score_text}</span>
</div>
""".strip(),
                unsafe_allow_html=True,
            )

    with right:
        st.subheader("How to use this app")
        st.markdown(
            """
1. Start in the Today tab and follow the 30-minute mission.
2. Read, quiz, code, then reflect before moving on.
3. Use review days to revisit older lessons from memory.
4. Use Prompt Lab to ask AI for hints, tests, and examples.
5. Save a tiny win each day so the app becomes your learning journal.
""".strip()
        )
        st.subheader("Current level")
        xp = calculate_xp(progress_data)
        render_card(level_for_xp(xp), f"{xp} XP earned from lessons, quizzes, prompts, daily missions, and AI resources.")
        with st.expander("Unlocked badges", expanded=False):
            render_badge_shelf(progress_data)

        ai_stats = official_resource_stats(progress_data)
        st.subheader("Official AI track")
        render_card(
            "External learning progress",
            (
                f"{ai_stats['started']} started, {ai_stats['completed']} completed, "
                f"{ai_stats['certificate_options']} certificate/credential options across "
                f"{ai_stats['total']} curated official resources."
            ),
        )
        st.info("While the GitHub repo is private, you can still run tests through GitHub Actions. Do not add API keys to code files.")

with lesson_tab:
    st.header(lesson.title)
    render_status_pills(lesson.level, lesson.time_minutes, lesson_complete)
    st.info("30-minute habit tip: read for 10 minutes, code for 10 minutes, quiz or review for 5 minutes, then write a 5-minute reflection.")

    st.subheader("Objectives")
    for objective in lesson.objectives:
        st.write(f"- {objective}")

    st.subheader("Lesson")
    st.markdown(lesson.explanation)

    st.subheader("Key terms")
    st.write(" ".join(f"`{term}`" for term in lesson.key_terms))

    st.info(f"Prompt skill: {lesson.prompt_skill}")

    action_cols = st.columns([1, 1.2])
    with action_cols[0]:
        if lesson_complete:
            st.success("You marked this lesson complete.")
        elif st.button("Mark lesson complete", type="primary"):
            mark_lesson_complete(progress_data, lesson.id)
            save_progress(progress_data, progress_path)
            st.success("Lesson marked complete.")
            st.rerun()
    with action_cols[1]:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI to explain this lesson in simpler words",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            prompt = (
                f"Explain the lesson '{lesson.title}' in beginner-friendly language. "
                "Use a tiny Python example and one check-in question."
            )
            st.write(call_ai_tutor([{"role": "user", "content": prompt}], lesson.title, lesson.level))
        if not ai_ready:
            st.caption("AI buttons are disabled until OPENAI_API_KEY is configured. The rest of the app works without AI.")

with quiz_tab:
    st.header(f"Quiz: {lesson.title}")
    st.write("Answer all questions, then submit. You can retake quizzes anytime.")

    with st.form(key=f"quiz_form_{lesson.id}"):
        selected_answers = []
        for index, question in enumerate(lesson.quiz, start=1):
            selected = st.selectbox(
                f"{index}. {question.prompt}",
                ["Choose an answer"] + question.options,
                key=f"quiz_{lesson.id}_{index}",
            )
            selected_answers.append(selected)

        submitted = st.form_submit_button("Submit quiz")

    if submitted:
        if any(answer == "Choose an answer" for answer in selected_answers):
            st.warning("Please answer every question before submitting.")
        else:
            score = 0
            details = []
            for selected, question in zip(selected_answers, lesson.quiz):
                is_correct = selected == question.answer
                score += int(is_correct)
                details.append((question, selected, is_correct))

            record_quiz_score(progress_data, lesson.id, score, len(lesson.quiz))
            save_progress(progress_data, progress_path)
            render_score_badge(score, len(lesson.quiz))

            for question, selected, is_correct in details:
                if is_correct:
                    st.success(f"Correct: {question.prompt}")
                else:
                    st.error(f"Missed: {question.prompt}")
                    st.write(f"Your answer: {selected}")
                    st.write(f"Correct answer: {question.answer}")
                st.caption(question.explanation)

    existing_score = progress_data.get("quiz_scores", {}).get(lesson.id)
    if existing_score:
        st.divider()
        st.write(
            f"Last saved score for this lesson: **{existing_score['score']}/{existing_score['total']}** "
            f"({existing_score['percent']}%)."
        )

with code_tab:
    st.header(f"Code Lab: {lesson.title}")
    challenge = lesson.challenge
    st.write(challenge.prompt)
    st.caption("Try for 8-10 focused minutes before opening hints. The goal is practice, not perfection.")

    with st.expander("Hints"):
        for hint in challenge.hints:
            st.write(f"- {hint}")

    user_code = st.text_area(
        "Your code",
        value=challenge.starter_code,
        height=280,
        key=f"code_{lesson.id}",
    )

    with st.expander("View tests"):
        st.code(challenge.tests, language="python")

    runner_on = code_runner_enabled()
    if not runner_on:
        st.info(
            "The code runner is off. To run tests locally, start the app with "
            "ALLOW_CODE_RUNNER=true. Keep it off for public deployments."
        )
    else:
        st.warning(
            "Local runner is enabled. This is for your own machine only, not a secure public sandbox."
        )
        if st.button("Run lesson tests", type="primary"):
            result = run_python_with_tests(user_code, challenge.tests)
            if result.ok:
                st.success("Tests passed.")
            else:
                st.error("Tests failed.")
            if result.stdout:
                st.subheader("Output")
                st.code(result.stdout)
            if result.stderr:
                st.subheader("Errors")
                st.code(result.stderr)

    col_a, col_b = st.columns(2)
    with col_a:
        with st.expander("Show sample solution"):
            st.code(challenge.sample_solution, language="python")
    with col_b:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI for a hint on my code",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            prompt = (
                "Give me one helpful hint for this coding challenge without giving the full solution.\n\n"
                f"Challenge: {challenge.prompt}\n\n"
                f"My code:\n```python\n{user_code}\n```"
            )
            response = call_ai_tutor(
                [{"role": "user", "content": prompt}],
                lesson_title=lesson.title,
                lesson_level=lesson.level,
            )
            st.write(response)
        if not ai_ready:
            st.caption("Connect the AI tutor to get code hints. Until then, use the built-in hints and sample solution.")


with projects_tab:
    st.header("Projects & capstone checkpoints")
    st.write(
        "Projects make the lessons feel real. Each track is broken into tiny checkpoints so you can build without getting overwhelmed."
    )

    project_metric_cols = st.columns(4)
    project_metric_cols[0].metric("Project tracks", len(PROJECTS))
    project_metric_cols[1].metric("Milestones done", completed_project_milestones_count(progress_data))
    project_metric_cols[2].metric("Recommended", next(project.title for project in PROJECTS if project.id == recommended_project_id(progress_data)))
    project_metric_cols[3].metric("Capstone", f"{int(project_completion_percent(progress_data, 'personal_ai_code_tutor') * 100)}%")

    recommended = next(project for project in PROJECTS if project.id == recommended_project_id(progress_data))
    render_card(
        "Recommended project",
        f"{recommended.title}: {recommended.description} Next checkpoint: {next_project_milestone(progress_data, recommended.id).title}.",
        "success-soft",
    )

    project_labels = [f"{project.title} ({project.level})" for project in PROJECTS]
    selected_project_label = st.selectbox("Choose a project track", project_labels)
    selected_project = PROJECTS[project_labels.index(selected_project_label)]
    render_project_summary(selected_project, progress_data)
    st.progress(project_completion_percent(progress_data, selected_project.id))

    st.subheader("Milestones")
    saved_milestones = project_progress(progress_data, selected_project.id)
    for milestone in selected_project.milestones:
        with st.expander(f"{milestone.title} - {saved_milestones.get(milestone.id, {}).get('status', 'Not started')}", expanded=saved_milestones.get(milestone.id, {}).get("status") in {None, "Not started", "In progress"}):
            st.write(milestone.proof)
            current = saved_milestones.get(milestone.id, {})
            status_options = ["Not started", "In progress", "Completed", "Skipped"]
            current_status = current.get("status", "Not started") if current.get("status", "Not started") in status_options else "Not started"
            new_status = st.selectbox(
                "Status",
                status_options,
                index=status_options.index(current_status),
                key=f"project_status_{selected_project.id}_{milestone.id}",
            )
            new_note = st.text_area(
                "Proof note",
                value=current.get("note", ""),
                key=f"project_note_{selected_project.id}_{milestone.id}",
                height=80,
                placeholder="Example: I wrote the score function and tested 3/3 answers.",
            )
            if st.button("Save milestone", key=f"save_project_{selected_project.id}_{milestone.id}"):
                record_project_milestone(progress_data, selected_project.id, milestone.id, new_status, new_note)
                save_progress(progress_data, progress_path)
                st.success("Project milestone saved.")
                st.rerun()

    st.subheader("All project tracks")
    for project in PROJECTS:
        render_project_summary(project, progress_data)

with prompt_tab:
    st.header("Prompt Lab")
    st.write("Practice writing better prompts for coding, learning, debugging, and AI app building.")

    prompt_text = st.text_area(
        "Write or paste a prompt",
        value=improved_prompt_template("Python functions"),
        height=240,
        key="prompt_lab_text",
    )

    score_col, ai_col = st.columns(2)
    with score_col:
        if st.button("Score prompt", type="primary"):
            result = score_prompt(prompt_text)
            record_prompt_score(progress_data, result.score, prompt_text)
            save_progress(progress_data, progress_path)
            st.metric("Prompt score", f"{result.score}/{result.max_score}")
            st.progress(result.score / result.max_score)
            st.write(result.summary)
            for criterion in result.criteria:
                if criterion.passed:
                    st.success(f"{criterion.name}: +{criterion.points} - {criterion.feedback}")
                else:
                    st.warning(f"{criterion.name}: {criterion.feedback}")
    with ai_col:
        ai_ready = ai_is_configured()
        if st.button(
            "Ask AI to improve this prompt",
            disabled=not ai_ready,
            help="Add OPENAI_API_KEY to enable this." if not ai_ready else None,
        ):
            improved = improve_prompt_with_ai(prompt_text, lesson_title=lesson.title)
            st.subheader("AI feedback")
            st.write(improved)
        if not ai_ready:
            st.caption("The built-in rubric works offline. AI rewriting turns on after you add OPENAI_API_KEY.")

    with st.expander("Prompt formula"):
        st.markdown(
            """
Use this formula:

```text
Role: Who should the AI act as?
Task: What exact job should it do?
Context: What does it need to know about you, the code, or the situation?
Constraints: What should it avoid or follow?
Example/Input: What code, error, sample input, or desired output can you provide?
Output format: How should the answer be structured?
Verification: How can the answer be checked?
```
""".strip()
        )

with official_ai_tab:
    st.header("Official AI Learning & Certifications")
    st.write(
        "Use this hub to track official provider lessons, docs, cohorts, and certifications while you learn Python. "
        "The app links out to official pages and saves your status here; it does not copy or republish their course content."
    )
    st.caption(
        "Verify prices, exam requirements, dates, and availability on the official provider page before enrolling or paying."
    )

    stats = official_resource_stats(progress_data)
    counts = provider_counts()
    stat_cols = st.columns(4)
    stat_cols[0].metric("Official resources", stats["total"])
    stat_cols[1].metric("Started", stats["started"])
    stat_cols[2].metric("Completed", stats["completed"])
    stat_cols[3].metric("Cert/certificate options", stats["certificate_options"])

    next_resource = next_recommended_resource(progress_data)
    if next_resource:
        render_card(
            "Recommended next AI step",
            f"{next_resource.provider}: {next_resource.title}. {next_resource.recommended_when}",
        )
        st.markdown(f"[Open recommended official page]({next_resource.url})")
    else:
        render_card(
            "Official AI track complete",
            "All curated official AI resources are marked Completed or Skipped. Add a new target or revisit your notes.",
            "success-soft",
        )

    st.subheader("Best starter path")
    starter_ids = OFFICIAL_AI_STARTER_PATH
    starter_cols = st.columns(3)
    for col, resource in zip(starter_cols, resources_for_ids(starter_ids)):
        with col:
            render_official_resource_summary(resource)
            st.markdown(f"[Open official page]({resource.url})")

    with st.expander("Suggested milestone tracks", expanded=True):
        for milestone in OFFICIAL_AI_MILESTONES:
            st.markdown(
                f"""
<div class="track-card">
    <strong>{milestone['title']}</strong><br>
    <span class="small-muted">{milestone['goal']}</span>
</div>
""".strip(),
                unsafe_allow_html=True,
            )
            for resource in resources_for_ids(milestone["resource_ids"]):
                status = official_resource_status(progress_data, resource.id)
                st.write(f"- **{resource.provider}: {resource.title}** - {status}")

    st.subheader("Browse and track official resources")
    filter_cols = st.columns([1, 1, 1])
    with filter_cols[0]:
        provider_filter = st.selectbox("Provider", ["All"] + list(PROVIDER_ORDER))
    with filter_cols[1]:
        type_filter = st.selectbox("Resource type", ["All"] + list(RESOURCE_TYPES))
    with filter_cols[2]:
        credential_only = st.checkbox("Show cert/certificate options only")

    filtered_resources = []
    for resource in OFFICIAL_AI_RESOURCES:
        if provider_filter != "All" and resource.provider != provider_filter:
            continue
        if type_filter != "All" and resource.resource_type != type_filter:
            continue
        if credential_only and not resource_has_certificate(resource):
            continue
        filtered_resources.append(resource)

    st.caption(f"Showing {len(filtered_resources)} resources. Provider counts: " + ", ".join(
        f"{provider}: {count}" for provider, count in counts.items()
    ))

    for resource in filtered_resources:
        status = official_resource_status(progress_data, resource.id)
        note = official_resource_note(progress_data, resource.id)
        expanded = resource.provider == "Gumloop" or status in {"Queued", "In progress"}
        with st.expander(f"{resource.provider}: {resource.title} ({status})", expanded=expanded):
            render_official_resource_summary(resource)
            st.markdown("**Skills:** " + ", ".join(f"`{tag}`" for tag in resource.tags))
            st.markdown(f"**Why it matters:** {resource.why_it_matters}")
            st.markdown(f"[Open official page]({resource.url})")

            status_index = STATUS_OPTIONS.index(status) if status in STATUS_OPTIONS else 0
            new_status = st.selectbox(
                "Status",
                STATUS_OPTIONS,
                index=status_index,
                key=f"official_status_{resource.id}",
            )
            new_note = st.text_area(
                "Private note for this resource",
                value=note,
                height=90,
                key=f"official_note_{resource.id}",
                placeholder="Example: Finish lessons 1-2 this week, then build one Gumloop workflow.",
            )
            if st.button("Save resource progress", key=f"save_official_{resource.id}"):
                record_official_ai_resource(progress_data, resource.id, new_status, new_note)
                save_progress(progress_data, progress_path)
                st.success("Official AI resource progress saved.")

    with st.expander("Prompt template for course or certificate prep"):
        st.code(
            """Role: You are my AI certification study coach.
Goal: Help me prepare for [provider/resource] while I learn Python.
Context: I am a beginner. I have completed lesson [number] in my Python app.
Official resource: [paste the official lesson/certification link]
Task: Create a 7-day study plan with daily tasks, practice questions, and one mini-project.
Constraints: Do not invent exam rules. Tell me what I must verify on the official page.
Output format: table with Day, Focus, Practice, Proof of Understanding.""",
            language="text",
        )

with ai_tab:
    st.header("AI Tutor")
    st.write("Ask about the current lesson, your code, debugging, project ideas, or prompt quality.")

    ai_ready = ai_is_configured()
    if not ai_ready:
        st.info("AI is optional. Add OPENAI_API_KEY to enable live tutor responses. The chat input is disabled until then.")

    if st.button("Clear chat"):
        st.session_state.ai_messages = []
        st.rerun()

    if "ai_messages" not in st.session_state or not st.session_state.ai_messages:
        st.session_state.ai_messages = [
            {
                "role": "assistant",
                "content": (
                    f"Hi. I can help with {lesson.title}. Ask me for a hint, an explanation, "
                    "a practice question, or help improving a prompt."
                ),
            }
        ]

    for message in st.session_state.ai_messages:
        role = message.get("role", "assistant")
        with st.chat_message(role):
            st.write(message.get("content", ""))

    chat_prompt = st.chat_input("Ask your tutor", disabled=not ai_ready)
    if chat_prompt:
        st.session_state.ai_messages.append({"role": "user", "content": chat_prompt})
        tutor_response = call_ai_tutor(
            st.session_state.ai_messages,
            lesson_title=lesson.title,
            lesson_level=lesson.level,
        )
        st.session_state.ai_messages.append({"role": "assistant", "content": tutor_response})
        st.rerun()

with notes_tab:
    st.header(f"Notes: {lesson.title}")
    current_note = progress_data.get("notes", {}).get(lesson.id, "")
    note_text = st.text_area(
        "Write your own notes, questions, and reflections",
        value=current_note,
        height=320,
        key=f"notes_{lesson.id}",
    )
    if st.button("Save notes"):
        save_note(progress_data, lesson.id, note_text)
        save_progress(progress_data, progress_path)
        st.success("Notes saved.")

with deploy_tab:
    st.header("Make it shareable")
    st.write(
        "This package is set up for Streamlit Community Cloud, Docker-based hosting, and Render-style Python services."
    )

    render_card(
        "Public-safe default",
        "The code runner is off unless ALLOW_CODE_RUNNER=true. Keep it off when other people can use the app.",
        "warning-soft",
    )

    st.subheader("Private GitHub checklist")
    st.markdown(
        "Keep the repository visibility set to **Private** while you are building. "
        "Only deploy or make public after the app has authentication, safer progress storage, and a production code-runner plan."
    )
    st.code(
        """git init
git add .
git commit -m "Initial private AI Code Tutor app"
git branch -M main
git remote add origin git@github.com:YOUR-USERNAME/ai-code-tutor.git
git push -u origin main""",
        language="bash",
    )

    st.subheader("Deployment checklist")
    st.checkbox("Create the GitHub repository with visibility set to Private", value=False)
    st.checkbox("Add OPENAI_API_KEY as a platform secret, not inside code", value=False)
    st.checkbox("Set ALLOW_CODE_RUNNER=false for public deployments", value=True)
    st.checkbox("Review official AI resource links before sharing publicly", value=True)
    st.checkbox("Run pytest before sharing the link", value=True)
    st.checkbox("Complete the new-user 30-day flow smoke test after big changes", value=True)

    st.subheader("Useful commands")
    st.code(
        """# Local
pip install -r requirements.txt
streamlit run app.py

# Tests
pytest -q

# Docker
docker build -t ai-code-tutor .
docker run -p 8501:8501 --env-file .env ai-code-tutor""",
        language="bash",
    )

    st.subheader("Test on iPhone Simulator through Xcode")
    st.write(
        "Run the Streamlit app locally, open Xcode's iOS Simulator, and load the app in Simulator Safari. "
        "The package also includes a simple SwiftUI WKWebView wrapper in `ios_wrapper/`."
    )
    st.code(
        """streamlit run app.py --server.address 0.0.0.0 --server.port 8501
# Then open http://localhost:8501 in iOS Simulator Safari.""",
        language="bash",
    )
    st.info("See README_DEPLOY.md and XCODE_IOS_TESTING.md for the full step-by-step guides.")

st.divider()
st.caption(
    f"Progress for profile `{profile_name}` is saved at `{progress_path}`. "
    "For a serious multi-user app, replace file storage with a database and add authentication."
)
