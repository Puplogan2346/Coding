# Test Report

Date: 2026-05-28

## Automated tests

Command:

```bash
python -m pytest -q
```

Result:

```text
36 passed in 1.61s
```

Coverage areas:

- Curriculum structure and lesson IDs
- Quiz answer validity
- All sample coding challenge solutions against their tests
- Progress save/load roundtrip
- Progress migration when lesson IDs change
- Learner profile slug safety
- Prompt scoring rubric behavior
- Code runner success, failure, and timeout behavior
- AI tutor message sanitization
- Brand-new learner first-use journey
- Official AI resources catalog metadata
- Gumloop, Claude/Anthropic, OpenAI, Google/Gemini, Microsoft/Azure AI, AWS, Hugging Face, and NVIDIA inclusion checks
- Official AI milestone ID integrity
- Official AI starter path integrity
- Official AI resource status and note tracking
- Official AI credential-only filter behavior
- Recommended next official AI resource logic
- Static app checks for missing imports and duplicate dependency imports
- 30-day plan integrity: 30 missions, 30 minutes each, valid lesson IDs
- Daily mission progression, skip behavior, streak updates, review queue, XP, levels, and badges

## Compile check

Command:

```bash
python -m compileall -q .
```

Result: completed successfully.

## v6 optimization pass

- Added Today tab and 30-minute daily mission flow.
- Added 30-day plan in `study_plan.py`.
- Added streaks, longest streak, daily reflections, mission history, XP, levels, and badges.
- Added habit-oriented tests and documentation.

## Bugs fixed during earlier QA passes

- Fixed missing `provider_counts` import that could break the AI Certs tab at runtime.
- Fixed credential filtering so `No certificate listed` no longer counts as a certificate option.
- Removed a duplicate progress import from `app.py`.
- Updated official-resource URLs and Gumloop AI Fundamentals metadata.

See `BUG_FIXES_AND_IMPROVEMENTS.md` for details.

## New-user smoke test

A fresh profile called `New User QA` was simulated from zero progress through the first lesson loop.

Result:

```text
initial completion: 0.0
initial lessons remaining: 12
initial recommended ai: gumloop_ai_fundamentals
completion after one lesson: 0.083
lessons remaining after one lesson: 11
quiz percent: 100.0
code lab sample solution passed: True
prompt score: 10/10
ai resources started: 3
recommended ai after queuing starter: gumloop_ai_fundamentals
```

## Official AI tracker smoke test

A fresh profile called `AI Cert QA` was simulated through the starter AI resource path.

Result:

```text
catalog count: 21
credential count: 9
starter path: gumloop_ai_fundamentals, gumloop_getting_started, anthropic_academy
first recommendation: gumloop_ai_fundamentals
after starter complete: openai_prompting_guide
```

## Manual app launch note

A live Streamlit server smoke test could not be run in this container because `streamlit` is not installed here and package installation cannot reach PyPI. The app code was syntax-compiled, the learner/prompt/code/official-resource flows were tested directly, and static app tests were added to catch the kind of app-level import bug found in this pass.

## v7 finished training app pass

Additional coverage added:

- ADHD-friendly focus coach session blocks, rescue mode, deep-build mode, body-double scripts, and focus scoring.
- Focus preferences, focus check-ins, parking-lot capture, and parking-lot close behavior.
- Project catalog integrity, project recommendation, milestone progress, and capstone checkpoint logic.
- New-user journey now includes a focus check-in and first project milestone.
- Static app checks now confirm Focus Coach and Projects dependencies are imported and exposed.

Latest result:

```text
python -m compileall -q .
completed successfully

python -m pytest -q
47 passed in 1.68s
```

See `V7_FINISHED_TRAINING_APP_REPORT.md`, `ADHD_FRIENDLY_DESIGN.md`, and `XCODE_IOS_TESTING.md`.
