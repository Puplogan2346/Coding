from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable

PROGRESS_FILE = Path("user_progress.json")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_progress(lesson_ids: Iterable[str]) -> Dict[str, Any]:
    lesson_ids = list(lesson_ids)
    return {
        "created_at": _now(),
        "updated_at": _now(),
        "completed_lessons": [],
        "quiz_scores": {},
        "notes": {lesson_id: "" for lesson_id in lesson_ids},
        "prompt_scores": [],
    }


def load_progress(lesson_ids: Iterable[str], path: Path = PROGRESS_FILE) -> Dict[str, Any]:
    lesson_ids = list(lesson_ids)
    if not path.exists():
        return default_progress(lesson_ids)

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default_progress(lesson_ids)

    base = default_progress(lesson_ids)
    base.update(data)

    # Add notes slots for lessons added after the progress file was created.
    base.setdefault("notes", {})
    for lesson_id in lesson_ids:
        base["notes"].setdefault(lesson_id, "")

    base.setdefault("completed_lessons", [])
    base.setdefault("quiz_scores", {})
    base.setdefault("prompt_scores", [])
    return base


def save_progress(data: Dict[str, Any], path: Path = PROGRESS_FILE) -> None:
    data["updated_at"] = _now()
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def mark_lesson_complete(data: Dict[str, Any], lesson_id: str) -> None:
    completed = data.setdefault("completed_lessons", [])
    if lesson_id not in completed:
        completed.append(lesson_id)


def record_quiz_score(data: Dict[str, Any], lesson_id: str, score: int, total: int) -> None:
    data.setdefault("quiz_scores", {})[lesson_id] = {
        "score": score,
        "total": total,
        "percent": round((score / total) * 100, 1) if total else 0,
        "taken_at": _now(),
    }


def save_note(data: Dict[str, Any], lesson_id: str, note: str) -> None:
    data.setdefault("notes", {})[lesson_id] = note


def record_prompt_score(data: Dict[str, Any], score: int, prompt: str) -> None:
    data.setdefault("prompt_scores", []).append(
        {
            "score": score,
            "prompt_preview": prompt[:160],
            "created_at": _now(),
        }
    )


def completion_percent(data: Dict[str, Any], total_lessons: int) -> float:
    if total_lessons <= 0:
        return 0.0
    return round(len(data.get("completed_lessons", [])) / total_lessons, 3)
