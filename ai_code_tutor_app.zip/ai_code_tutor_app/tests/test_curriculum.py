from curriculum import LESSONS, get_lesson_by_id
from prompt_lab import score_prompt


def test_curriculum_has_lessons():
    assert len(LESSONS) >= 10
    assert all(lesson.id for lesson in LESSONS)
    assert all(lesson.quiz for lesson in LESSONS)
    assert all(lesson.challenge.tests for lesson in LESSONS)


def test_get_lesson_by_id():
    first = LESSONS[0]
    assert get_lesson_by_id(first.id).title == first.title


def test_prompt_score_stronger_prompt_scores_higher():
    weak = score_prompt("fix this")
    strong = score_prompt(
        "Role: Python tutor. Task: explain this loop error. Context: I am a beginner. "
        "Constraints: do not give the final answer. Output format: 3 bullet points and one test. "
        "Example code: for x in range(3): print(x). Verification: include an edge case."
    )
    assert strong.score > weak.score
