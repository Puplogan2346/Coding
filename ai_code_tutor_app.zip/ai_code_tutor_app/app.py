from __future__ import annotations

import os
from statistics import mean

import streamlit as st

from ai_tutor import ai_is_configured, call_ai_tutor, configured_model, improve_prompt_with_ai
from code_runner import code_runner_enabled, run_python_with_tests
from curriculum import LESSONS, get_lesson_by_id
from progress import (
    PROGRESS_FILE,
    completion_percent,
    load_progress,
    mark_lesson_complete,
    record_prompt_score,
    record_quiz_score,
    save_note,
    save_progress,
)
from prompt_lab import improved_prompt_template, score_prompt


st.set_page_config(
    page_title="AI Code Tutor",
    page_icon="python",
    layout="wide",
)

LESSON_IDS = [lesson.id for lesson in LESSONS]


def first_incomplete_lesson_id(progress_data: dict) -> str:
    completed = set(progress_data.get("completed_lessons", []))
    for lesson in LESSONS:
        if lesson.id not in completed:
            return lesson.id
    return LESSONS[-1].id


def get_quiz_average(progress_data: dict) -> float:
    scores = progress_data.get("quiz_scores", {}).values()
    percentages = [item.get("percent", 0) for item in scores]
    return round(mean(percentages), 1) if percentages else 0.0


def render_score_badge(score: int, total: int) -> None:
    percent = round((score / total) * 100) if total else 0
    if percent >= 80:
        st.success(f"Score: {score}/{total} ({percent}%). Strong work.")
    elif percent >= 60:
        st.warning(f"Score: {score}/{total} ({percent}%). Review the misses and try again.")
    else:
        st.error(f"Score: {score}/{total} ({percent}%). Revisit the lesson, then retake it.")


progress_data = load_progress(LESSON_IDS)

if "selected_lesson_id" not in st.session_state:
    st.session_state.selected_lesson_id = first_incomplete_lesson_id(progress_data)

if "ai_messages" not in st.session_state:
    st.session_state.ai_messages = []

st.title("AI Code Tutor")
st.caption("Learn Python, practice code, improve prompts, and use AI as a study partner.")

completed_count = len(progress_data.get("completed_lessons", []))
completion = completion_percent(progress_data, len(LESSONS))

with st.sidebar:
    st.header("Study path")
    st.progress(completion)
    st.write(f"{completed_count} of {len(LESSONS)} lessons complete")

    labels = [f"{index + 1}. {lesson.title}" for index, lesson in enumerate(LESSONS)]
    label_by_id = {lesson.id: labels[index] for index, lesson in enumerate(LESSONS)}
    id_by_label = {label: lesson.id for label, lesson in zip(labels, LESSONS)}
    current_label = label_by_id.get(st.session_state.selected_lesson_id, labels[0])

    selected_label = st.selectbox(
        "Choose a lesson",
        labels,
        index=labels.index(current_label),
    )
    st.session_state.selected_lesson_id = id_by_label[selected_label]

    lesson = get_lesson_by_id(st.session_state.selected_lesson_id)

    st.divider()
    st.subheader("AI status")
    if ai_is_configured():
        st.success(f"Connected: {configured_model()}")
    else:
        st.warning("Not connected yet")
        st.caption("Set OPENAI_API_KEY to enable the AI tutor.")

    st.subheader("Code runner")
    if code_runner_enabled():
        st.warning("Enabled for local use")
    else:
        st.info("Disabled by default")
        st.caption("Set ALLOW_CODE_RUNNER=true to run lesson tests locally.")

    with st.expander("Reset local progress"):
        confirm_reset = st.checkbox("I understand this deletes local progress")
        if confirm_reset and st.button("Reset progress file"):
            if PROGRESS_FILE.exists():
                PROGRESS_FILE.unlink()
            st.session_state.ai_messages = []
            st.rerun()

lesson = get_lesson_by_id(st.session_state.selected_lesson_id)
completed_lessons = set(progress_data.get("completed_lessons", []))

(
    dashboard_tab,
    lesson_tab,
    quiz_tab,
    code_tab,
    prompt_tab,
    ai_tab,
    notes_tab,
) = st.tabs(["Dashboard", "Lesson", "Quiz", "Code Lab", "Prompt Lab", "AI Tutor", "Notes"])

with dashboard_tab:
    col1, col2, col3 = st.columns(3)
    col1.metric("Lessons complete", f"{completed_count}/{len(LESSONS)}")
    col2.metric("Quiz average", f"{get_quiz_average(progress_data)}%")
    col3.metric("Prompt attempts", len(progress_data.get("prompt_scores", [])))

    st.subheader("Recommended next step")
    next_lesson = get_lesson_by_id(first_incomplete_lesson_id(progress_data))
    st.write(f"Continue with: **{next_lesson.title}**")
    st.write(f"Estimated time: {next_lesson.time_minutes} minutes")

    st.subheader("Curriculum map")
    for index, item in enumerate(LESSONS, start=1):
        status = "Complete" if item.id in completed_lessons else "Not complete"
        score = progress_data.get("quiz_scores", {}).get(item.id)
        score_text = f"Quiz: {score['percent']}%" if score else "Quiz: not taken"
        st.write(f"{index}. **{item.title}** - {item.level} - {status} - {score_text}")

with lesson_tab:
    st.header(lesson.title)
    st.caption(f"Level: {lesson.level} | Estimated time: {lesson.time_minutes} minutes")

    st.subheader("Objectives")
    for objective in lesson.objectives:
        st.write(f"- {objective}")

    st.subheader("Lesson")
    st.markdown(lesson.explanation)

    st.subheader("Key terms")
    st.write(", ".join(f"`{term}`" for term in lesson.key_terms))

    st.info(f"Prompt skill: {lesson.prompt_skill}")

    if lesson.id in completed_lessons:
        st.success("You marked this lesson complete.")
    else:
        if st.button("Mark lesson complete", type="primary"):
            mark_lesson_complete(progress_data, lesson.id)
            save_progress(progress_data)
            st.success("Lesson marked complete.")
            st.rerun()

with quiz_tab:
    st.header(f"Quiz: {lesson.title}")
    st.write("Answer all questions, then submit. You can retake quizzes anytime.")

    with st.form(key=f"quiz_form_{lesson.id}"):
        selected_answers = []
        for index, question in enumerate(lesson.quiz, start=1):
            selected = st.selectbox(
                f"{index}. {question.prompt}",
                ["Choose an answer"] + question.options,
                key=f"quiz_{lesson.id}_{index}",
            )
            selected_answers.append(selected)

        submitted = st.form_submit_button("Submit quiz")

    if submitted:
        if any(answer == "Choose an answer" for answer in selected_answers):
            st.warning("Please answer every question before submitting.")
        else:
            score = 0
            details = []
            for selected, question in zip(selected_answers, lesson.quiz):
                is_correct = selected == question.answer
                score += int(is_correct)
                details.append((question, selected, is_correct))

            record_quiz_score(progress_data, lesson.id, score, len(lesson.quiz))
            save_progress(progress_data)
            render_score_badge(score, len(lesson.quiz))

            for question, selected, is_correct in details:
                if is_correct:
                    st.success(f"Correct: {question.prompt}")
                else:
                    st.error(f"Missed: {question.prompt}")
                    st.write(f"Your answer: {selected}")
                    st.write(f"Correct answer: {question.answer}")
                st.caption(question.explanation)

    existing_score = progress_data.get("quiz_scores", {}).get(lesson.id)
    if existing_score:
        st.divider()
        st.write(
            f"Last saved score for this lesson: **{existing_score['score']}/{existing_score['total']}** "
            f"({existing_score['percent']}%)."
        )

with code_tab:
    st.header(f"Code Lab: {lesson.title}")
    challenge = lesson.challenge
    st.write(challenge.prompt)

    with st.expander("Hints"):
        for hint in challenge.hints:
            st.write(f"- {hint}")

    user_code = st.text_area(
        "Your code",
        value=challenge.starter_code,
        height=280,
        key=f"code_{lesson.id}",
    )

    with st.expander("View tests"):
        st.code(challenge.tests, language="python")

    runner_on = code_runner_enabled()
    if not runner_on:
        st.info(
            "The code runner is off. To run tests locally, start the app with "
            "ALLOW_CODE_RUNNER=true. Keep it off for public deployments."
        )
    else:
        st.warning(
            "Local runner is enabled. This is for your own machine only, not a secure public sandbox."
        )
        if st.button("Run lesson tests", type="primary"):
            result = run_python_with_tests(user_code, challenge.tests)
            if result.ok:
                st.success("Tests passed.")
            else:
                st.error("Tests failed.")
            if result.stdout:
                st.subheader("Output")
                st.code(result.stdout)
            if result.stderr:
                st.subheader("Errors")
                st.code(result.stderr)

    col_a, col_b = st.columns(2)
    with col_a:
        with st.expander("Show sample solution"):
            st.code(challenge.sample_solution, language="python")
    with col_b:
        if st.button("Ask AI for a hint on my code"):
            prompt = (
                "Give me one helpful hint for this coding challenge without giving the full solution.\n\n"
                f"Challenge: {challenge.prompt}\n\n"
                f"My code:\n```python\n{user_code}\n```"
            )
            response = call_ai_tutor(
                [{"role": "user", "content": prompt}],
                lesson_title=lesson.title,
                lesson_level=lesson.level,
            )
            st.write(response)

with prompt_tab:
    st.header("Prompt Lab")
    st.write("Practice writing better prompts for coding, learning, debugging, and AI app building.")

    prompt_text = st.text_area(
        "Write or paste a prompt",
        value=improved_prompt_template("Python functions"),
        height=240,
        key="prompt_lab_text",
    )

    if st.button("Score prompt", type="primary"):
        result = score_prompt(prompt_text)
        record_prompt_score(progress_data, result.score, prompt_text)
        save_progress(progress_data)
        st.metric("Prompt score", f"{result.score}/{result.max_score}")
        st.progress(result.score / result.max_score)
        st.write(result.summary)
        for criterion in result.criteria:
            if criterion.passed:
                st.success(f"{criterion.name}: +{criterion.points} - {criterion.feedback}")
            else:
                st.warning(f"{criterion.name}: {criterion.feedback}")

    if st.button("Ask AI to improve this prompt"):
        improved = improve_prompt_with_ai(prompt_text, lesson_title=lesson.title)
        st.subheader("AI feedback")
        st.write(improved)

    with st.expander("Prompt formula"):
        st.markdown(
            """
Use this formula:

```text
Role: Who should the AI act as?
Task: What exact job should it do?
Context: What does it need to know about you, the code, or the situation?
Constraints: What should it avoid or follow?
Example/Input: What code, error, sample input, or desired output can you provide?
Output format: How should the answer be structured?
Verification: How can the answer be checked?
```
""".strip()
        )

with ai_tab:
    st.header("AI Tutor")
    st.write("Ask about the current lesson, your code, debugging, project ideas, or prompt quality.")

    if not ai_is_configured():
        st.info("AI is optional. Add OPENAI_API_KEY to enable live tutor responses.")

    if st.button("Clear chat"):
        st.session_state.ai_messages = []
        st.rerun()

    if not st.session_state.ai_messages:
        st.session_state.ai_messages.append(
            {
                "role": "assistant",
                "content": (
                    f"Hi. I can help with {lesson.title}. Ask me for a hint, an explanation, "
                    "a practice question, or help improving a prompt."
                ),
            }
        )

    for message in st.session_state.ai_messages:
        role = message.get("role", "assistant")
        with st.chat_message(role):
            st.write(message.get("content", ""))

    chat_prompt = st.chat_input("Ask your tutor")
    if chat_prompt:
        st.session_state.ai_messages.append({"role": "user", "content": chat_prompt})
        tutor_response = call_ai_tutor(
            st.session_state.ai_messages,
            lesson_title=lesson.title,
            lesson_level=lesson.level,
        )
        st.session_state.ai_messages.append({"role": "assistant", "content": tutor_response})
        st.rerun()

with notes_tab:
    st.header(f"Notes: {lesson.title}")
    current_note = progress_data.get("notes", {}).get(lesson.id, "")
    note_text = st.text_area(
        "Write your own notes, questions, and reflections",
        value=current_note,
        height=320,
        key=f"notes_{lesson.id}",
    )
    if st.button("Save notes"):
        save_note(progress_data, lesson.id, note_text)
        save_progress(progress_data)
        st.success("Notes saved.")

st.divider()
st.caption(
    "Local MVP: progress is saved to user_progress.json in this project folder. "
    "For multiple users, upgrade this to a database and add authentication."
)
