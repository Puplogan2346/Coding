# AI Code Tutor

A beginner-to-intermediate Python learning app built with Streamlit.

It includes:

- A 12-lesson Python curriculum
- Quizzes with saved scores
- Coding challenges with starter code, hints, tests, and sample solutions
- A Prompt Lab that scores prompt quality
- Optional AI tutor powered by the OpenAI API
- Local progress saved to `user_progress.json`

## 1. Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

On Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

## 2. Enable the AI tutor

The app works without AI. To enable live AI help, set an API key.

Option A: environment variables

```bash
export OPENAI_API_KEY="your_api_key_here"
export OPENAI_MODEL="gpt-5.5"
streamlit run app.py
```

Option B: Streamlit secrets

```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Then edit `.streamlit/secrets.toml` and add your real key.

Never commit `.streamlit/secrets.toml` or `.env`.

## 3. Enable local code tests

By default, the app does not execute user-submitted code. For your own local machine, you can enable the lesson test runner:

```bash
ALLOW_CODE_RUNNER=true streamlit run app.py
```

Important: the included runner is not a secure public sandbox. Keep it disabled if deploying the app for other people.

## 4. Project structure

```text
app.py                  Main Streamlit app
curriculum.py           Lessons, quizzes, coding challenges
ai_tutor.py             OpenAI API helper functions
prompt_lab.py           Prompt scoring rubric
progress.py             Local JSON progress tracking
code_runner.py          Optional local code runner
requirements.txt        Python dependencies
.streamlit/             Example Streamlit secrets file
```

## 5. Good next upgrades

1. Replace `user_progress.json` with SQLite or Postgres.
2. Add user accounts and authentication.
3. Add spaced repetition review cards.
4. Generate custom quizzes from missed questions.
5. Add a lesson editor for creating new curriculum items.
6. Add safe code execution through containers or a hosted sandbox.
7. Deploy on Streamlit Community Cloud, Render, Railway, Fly.io, or a VPS.

## 6. Suggested build philosophy

Build the smallest useful version first:

1. Lessons show correctly.
2. Quizzes save scores.
3. Code challenges have tests.
4. Prompt Lab gives feedback.
5. AI tutor works only after the key is configured.

Once those work, improve the curriculum, design, and database layer.
